#ifndef MAPS_VERSION 
#define MAPS_VERSION "3.09"
#endif
