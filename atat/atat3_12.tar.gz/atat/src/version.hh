#ifndef MAPS_VERSION 
#define MAPS_VERSION "3.12"
#endif
