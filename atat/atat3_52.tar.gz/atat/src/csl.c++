#include <fstream.h>
#include <sys/stat.h>
#include "array.h"
#include "getvalue.h"
#include "xtalutil.h"
#include "parse.h"
#include "version.h"

struct PointOpTrans
{
  rMatrix3d point_op;
  rVector3d trans;
  bool inversion;
};

struct CutPoint
{
  rVector3d cutpos, i, j, k, cutpos_t, k_t, transvec;
  int d1,d2,d3;
  PointOpTrans symop;
};

struct CutCell
{
  Structure str;
  rVector3d cutpos;
};

struct CutCells
{
  Structure origstr;
  Array<rVector3d> ifaces;
  rVector3d i,j,k;
  rMatrix3d A,axes,dsc;
  Real area,strain;
};

struct SymCutCell
{
  Structure str,origstr,cutstr,symcutstr;
  rVector3d cutpos,cutpos_t,k,k_t;
  int nbatom;
  Real volume;
  PointOpTrans symop;
  Array<int> ifacepos_o,ifacepos_t;
};

struct ShiftedCell
{
  SymCutCell cutcell;
  rVector3d d1shift, d2shift;
};

struct CombinedCell
{
  Structure str,grain1,grain2;
  rVector3d d1shift, d2shift;
  Real criterion, gap;
};

struct Parsed
{
  Structure lat;
  ArrayArrayint labellookup;
  Array<AutoString> label;
  Structure str;
  rMatrix3d axes,cell;
};

struct ParsedCutCells
{
  Structure lat;
  ArrayArrayint labellookup;
  Array<AutoString> label;
  Array<CutCells> cutcells;
};

struct CSLCell
{
  rVector3d i,j,k;
  rMatrix3d dsc,A;
};

struct CSL
{
  Array<CSLCell> cs;
  rMatrix3d A;
  Real strain;
  Real area;
};

class EqModCell {
  rMatrix3d icell;
public:
  EqModCell(rMatrix3d cell): icell() {icell=!cell;}
  int operator() (const Array<rVector3d> &a, const Array<rVector3d> &b)
    const {
    return equivalent_mod_cell(a,b,icell);
  }
};

Real angle(const rVector3d &a, const rVector3d &b)
{
  Real c = a*b/(norm(a)*norm(b));
  if(near_zero(abs(c) - 1))
    {
      if(c > 0)
        {
          return(0);
        }
      else
        {
          return(M_PI);
        }
    }
  else
    {
    return(acos(c));
    }
}

Real volume(const Structure &str)
{
  rVector3d i = str.cell.get_column(0);
  rVector3d j = str.cell.get_column(1);
  rVector3d k = str.cell.get_column(2);
  return(abs(i * (j ^ k)));
}

int add_if_nonequiv(LinkedList<Array<rVector3d> > *pclist, const Array<rVector3d> &cells, const Array<rMatrix3d> &point_op1, const Array<rMatrix3d> &point_op2)
{
  LinkedListIterator<Array<rVector3d> > i(*pclist);
  for ( ; i; i++)
    {
      int same1=0;
      for (int op1=0; op1<point_op1.get_size(); op1++)
	{
	  if (near_zero(norm((*i)(0)-point_op1(op1)*cells(0))) && near_zero(norm((*i)(1)-point_op1(op1)*cells(1))))
	    {
	      same1=1;
	      break;
	    }
	}
      int same2=0;
      for (int op2=0; op2<point_op2.get_size(); op2++)
	{
	  if (near_zero(norm((*i)(2)-point_op2(op2)*cells(2))) && near_zero(norm((*i)(3)-point_op2(op2)*cells(3))))
	    {
	      same2=1;
	      break;
	    }
	}
      if (same1 && same2) break;
    }
  if (!i)
    {
      (*pclist) << new Array<rVector3d>(cells);
      return 1;
    }
  else
    {
      return 0;
    }
}

Real get_2d_strain(const rMatrix2d &s)
{
  Real d=det(s);
  Real t=trace(s);
  return (fabs(t)+sqrt(t*t-4*d))/2.;
}

void parse_files(Parsed *parsed, const char* latfilename, const char* cellfilename)
{
  ifstream latfile(latfilename);
  ifstream strfile(cellfilename);

  string laterror="Unable to open lattice file " + string(latfilename);
  string cellerror="Unable to open cell file " + string(cellfilename);

  if (!latfile) ERRORQUIT(laterror);
  if (!strfile) ERRORQUIT(cellerror);

  parse_lattice_file(&(parsed->lat.cell), &(parsed->lat.atom_pos), &(parsed->lat.atom_type), &(parsed->labellookup), &(parsed->label), latfile, &(parsed->axes));
  wrap_inside_cell(&(parsed->lat.atom_pos),parsed->lat.atom_pos,parsed->lat.cell);

  parse_structure_file(&(parsed->str.cell), &(parsed->str.atom_pos), &(parsed->str.atom_type), parsed->label, strfile, NULL);
  wrap_inside_cell(&(parsed->str.atom_pos),parsed->str.atom_pos,parsed->str.cell);
  parsed->cell = parsed->str.cell;
}

void find_equal_length_vectors(LinkedList<Array<rVector3d> > *vlist, const rMatrix3d &cell1, const rMatrix3d &cell2, const Real &rmax, const Real &eps)
{
  LatticePointIterator a1(cell1,1);

  for (; norm(a1)<=rmax; a1++)
    {
      Real r1=norm(a1);
      Real rmax1=r1*(1+eps);
      LatticePointIterator a2(cell2,1);
      for (; norm(a2)<=rmax1; a2++)
	{
	  if (fabs(norm(a2)-r1)/r1 <= 2.*eps)
	    {
	      Array<rVector3d> *pv=new Array<rVector3d>(2);
	      (*pv)(0)=a1;
	      (*pv)(1)=a2;
	      (*vlist) << pv;
	    }
	}
    }
}

void find_csl_vectors(LinkedList<CSL> *cs, const LinkedList<Array<rVector3d> > &vlist, const rMatrix3d &iaxes1, const rMatrix3d &iaxes2, const Array<rMatrix3d> &point_op1, const Array<rMatrix3d> &point_op2, const Real &eps)
{
  LinkedList<Array<rVector3d> > clist;
  LinkedListIterator<Array<rVector3d> > i(vlist);
  rMatrix2d id;
  id.identity();

  for ( ; i; i++)
    {
      Real r1=norm((*i)(0));
      LinkedListIterator<Array<rVector3d> > j(vlist);
      for ( ; j && norm((*j)(0))<=r1+zero_tolerance; j++)
	{
	  Real p=((*j)(0)*(*i)(0))/((*i)(0)*(*i)(0));
	  if (fabs(p)<=0.5)
	    {
	      Real ang1=angle((*j)(0),(*i)(0));
	      Real ang2=angle((*j)(1),(*i)(1));
	      if (!near_zero(ang1) && !near_zero(ang1-M_PI)
		  &&
		  !near_zero(ang2) && !near_zero(ang2-M_PI)
		  &&
                  near_zero(abs(ang1 - ang2))
                  &&
		  (!near_zero(norm((*i)(0) - (*i)(1)))
		   ||
		   !near_zero(norm((*j)(0) - (*j)(1)))))
		{
		  Real i0norm = norm((*i)(0));
		  Real j0norm = norm((*j)(0));
		  Real i1norm = norm((*i)(1));
		  Real j1norm = norm((*j)(1));
		  rMatrix2d supcell1(i0norm * cos(ang1/2), j0norm * cos(ang1/2),
				     i0norm * sin(ang1/2),-j0norm * sin(ang1/2));
		  rMatrix2d supcell2(i1norm * cos(ang2/2), j1norm * cos(ang2/2),
				     i1norm * sin(ang2/2),-j1norm * sin(ang2/2));
		  Real strain=get_2d_strain((!supcell2)*supcell1-id);
		  if (strain<=eps)
		    {
		      Array<rVector3d> lats(4);
		      lats(0)=(*i)(0);
		      lats(1)=(*j)(0);
		      lats(2)=(*i)(1);
		      lats(3)=(*j)(1);
		      if (add_if_nonequiv(&clist,lats,point_op1,point_op2))
			{
			  rVector3d i0,j0,k0,i1,j1,k1;
			  CSL *tmp = new CSL;
			  CSLCell cell1,cell2;
			  Array<CSLCell> cells(2);
			  rMatrix3d c1,c2,A;
			  i0 = (*i)(0); i1 = (*i)(1);
			  j0 = (*j)(0); j1 = (*j)(1);
			  k0 = i0^j0; k1 = i1^j1;
			  k0 = k0 / norm(k0); k1 = k1 / norm(k1);

                          c1.set_column(0,i0);
                          c1.set_column(1,j0);
                          c1.set_column(2,k0);
                          c2.set_column(0,i1);
                          c2.set_column(1,j1);
                          c2.set_column(2,k1);
                          A = c2 * !c1;

                          cell1.i = i0; cell1.j = j0; cell1.k = k0;
                          cell2.i = i1; cell2.j = j1; cell2.k = k1;

                          cell1.dsc = !c1; cell1.A = ~c1 * iaxes1;
                          cell2.dsc = !c2; cell2.A = ~c2 * iaxes2;

                          cells[0] = cell1;
                          cells[1] = cell2;

                          tmp->cs = cells;
                          tmp->A = A;
                          tmp->strain = strain;
                          tmp->area = norm((*i)(0)^(*j)(0));

                          (*cs) << tmp;
			}
		    }
		}
	    }
	}
    }
}

void sort_csls(Array<CSL> *sorted, const Array<CSL> &csls, const Real &amax)
{
  LinkedList<CSL> lt, eq, gt, tmp;
  Array<CSL> ret;
  CSL pivot = csls(0);
  for(int i = 0; i < csls(); i++)
    {
      if(csls(i).area < amax)
        {
          if(csls(i).area < pivot.area)
            {
              lt << new CSL(csls(i));
            }
          else if(csls(i).area == pivot.area)
            {
              eq << new CSL(csls(i));
            }
          else
            {
              gt << new CSL(csls(i));
            }
        }
    }

  Array<CSL> ltarr, eqarr, gtarr;
  LinkedList_to_Array(&ltarr,lt);
  LinkedList_to_Array(&eqarr,eq);
  LinkedList_to_Array(&gtarr,gt);
  if(ltarr() != 0)
    {
      sort_csls(&ltarr,Array<CSL>(ltarr),amax);
    }
  if(gtarr() != 0)
    {
      sort_csls(&gtarr,Array<CSL>(gtarr),amax);
    }

  for(int ii = 0; ii < ltarr(); ii++)
    {
      tmp << new CSL(ltarr(ii));
    }
  for(int ii = 0; ii < eqarr(); ii++)
    {
      tmp << new CSL(eqarr(ii));
    }
  for(int ii = 0; ii < gtarr(); ii++)
    {
      tmp << new CSL(gtarr(ii));
    }
  LinkedList_to_Array(sorted,tmp);
}

void cut_cell(CutCell *c, const Structure &str, const rVector3d &pos, const rVector3d &k)
{
  Structure tmp;
  tmp.cell = str.cell;
  LinkedList<rVector3d> tmppos;
  LinkedList<int> tmptype;
  LinkedList<int> ifaceposll;
  Array<int> ifacepos;
  for(int j = 0; j < str.atom_pos(); j++)
    {
      if((-k * (str.atom_pos(j) - pos)) >= -zero_tolerance)
	{
	  tmppos << new rVector3d(str.atom_pos(j));
	  tmptype << new int(str.atom_type(j));
	}
    }
  LinkedList_to_Array(&tmp.atom_pos, tmppos);
  LinkedList_to_Array(&tmp.atom_type, tmptype);
  c->str = tmp;
  c->cutpos = pos;
}

Structure rotate_cell(Structure str, rMatrix3d A)
{
  Structure strrot(str);
  strrot.cell = A * str.cell;
  for(int i = 0; i < strrot.atom_pos(); i++)
    {
      strrot.atom_pos(i) = A * strrot.atom_pos(i);
    }
  return(strrot);
}

void find_interface_atoms(Array<int> *ifacepos, const Structure &str, const rVector3d &pos, const rVector3d &k)
{
  LinkedList<int> ifaceposll;
  for(int j = 0; j < str.atom_pos(); j++)
    {
      if(near_zero(k * (str.atom_pos(j) - pos)))
        ifaceposll << new int(j);
    }
  LinkedList_to_Array(ifacepos, ifaceposll);
}

void generate_interfaces(Array<rVector3d> *ifaces, const Structure &str)
{
  LinkedList<rVector3d> ifacestmp;
  for(int i = 0; i < str.atom_pos(); i++)
    {
      ifacestmp << new rVector3d(str.atom_pos(i));
    }
  LinkedList_to_Array(ifaces,ifacestmp);
}

void generate_cutcells(Array<Array<CutCells> > *cutcells, const Array<CSL> &csls, const Array<Structure> &strs, const Array<rMatrix3d> &axess)
{
  for(int i = 0; i < csls(); i++)
    {
      CSLCell c1 = csls(i).cs[0];
      CSLCell c2 = csls(i).cs[1];
      Array<rVector3d> tmp1, tmp2;
      generate_interfaces(&tmp1,strs[0]);
      generate_interfaces(&tmp2,strs[1]);

      CutCells add1, add2;
      add1.ifaces = tmp1;
      add1.i = c1.i; add1.j = c1.j; add1.k = add1.i^add1.j; add1.k=add1.k/norm(add1.k);
      add1.A = c1.A;
      add1.axes = axess[0];
      add1.dsc = c1.dsc;
      add1.area = csls(i).area;
      add1.strain = csls(i).strain;
      add1.origstr = strs[0];

      add2.ifaces = tmp2;
      add2.i = c2.i; add2.j = c2.j; add2.k = add2.i^add2.j; add2.k = add2.k/norm(add2.k);
      add2.A = c2.A;
      add2.axes = axess[1];
      add2.dsc = c2.dsc;
      add2.area = csls(i).area;
      add2.strain = csls(i).strain;
      add2.origstr = strs[1];

      Array<CutCells> add(2);
      add[0] = add1;
      add[1] = add2;
      (*cutcells)[i] = add;
    }
}

void get_symops_for_csl(Array<PointOpTrans> *ret, const Structure &str, const rVector3d &k)
{
  LinkedList<PointOpTrans> res;
  SpaceGroup sg;
  sg.cell = str.cell;

  find_spacegroup(&sg.point_op,&sg.trans,str.cell,str.atom_pos,str.atom_type);
  for(int i = 0; i < sg.point_op(); i++)
    {
      PointOpTrans *p = new PointOpTrans;
      p->point_op = sg.point_op(i);
      p->trans = sg.trans(i);
      p->inversion = true;
      if(near_zero(angle(k,sg.point_op(i) * k) - M_PI))
        res << p;
    }
  if(res.getSize() == 0)
    {
      cerr << "Warning: no inversion symmetry operations found! Finding identity symmetry operations instead." << endl;
      for(int i = 0; i < sg.point_op(); i++)
        {
          PointOpTrans *p = new PointOpTrans;
          p->point_op = sg.point_op(i);
          p->trans = sg.trans(i);
          p->inversion = false;
          if(near_zero(angle(k,sg.point_op(i) * k)))
            res << p;
        }
    }
  else
    {
      cerr << "Inversion symmetry operations found!" << endl;
    }
  LinkedList_to_Array(ret,res);
}

void check_inversions(Array<bool> *ret, const Array<Array<CutCells> > &cutcells)
{
  (*ret)[0] = true;
  (*ret)[1] = true;
  for(int i = 0; i < cutcells(); i++)
    {
      for(int j = 0; j < cutcells(i)(); j++)
        {
          Array<PointOpTrans> tmp;
          cerr << "Checking symmetry operations for cell " << j << " in CSL " << i << endl;
          get_symops_for_csl(&tmp, cutcells(i)(j).origstr, cutcells(i)(j).k);
          if(!tmp[0].inversion)
            (*ret)[j] = false;
        }
    }
  cerr << endl;
}

void print_cutcells(Array<CutCells> cutcells, int cellno)
{
  cout << "----------CSL " << cellno << "----------" << endl << endl;
  for(int i = 0; i < cutcells(); i++)
    {
      cout << "----------CELL " << i << "----------" << endl << endl;
      cout << "Area: " << cutcells(i).area << endl;
      cout << "Cell: " << endl << cutcells(i).origstr.cell << endl << cutcells(i).origstr.atom_pos << endl;
      cout << "Axes: " << endl << cutcells(i).axes;
      cout << "!Axes * Cell: " << endl << !cutcells(i).axes * cutcells(i).origstr.cell;
      cout << "Lattice mismatch: " << cutcells(i).strain << endl;
      cout << "CSL vectors: " << endl << cutcells(i).i << endl << cutcells(i).j << endl << cutcells(i).k << endl;
      cout << "Misorientation: " << endl << cutcells(i).A;
      cout << "Interface positions:" << endl << cutcells(i).ifaces << endl;
      cout << "----------CELL " << i << "----------" << endl << endl;
    }
  cout << "----------CSL " << cellno << "----------" << endl << endl;
}

void print_cutcells(Array<Array<CutCells> > cutcells)
{
  for(int i = 0; i < cutcells(); i++)
    {
      print_cutcells(cutcells[i],i);
    }
}

void write_csl(Array<CutCells> cutcells, int cslno, Array<Structure> lats, Array<ArrayArrayint> labellookups, Array<Array<AutoString> > labels)
{
  mkdir(("csl"+to_string(cslno)).c_str(),S_IRWXU | S_IRWXG | S_IRWXO);
  if(chdir(("csl"+to_string(cslno)).c_str())==0)
    {
      for(int i = 0; i < cutcells(); i++)
        {
          mkdir(("cell"+to_string(i)).c_str(),S_IRWXU | S_IRWXG | S_IRWXO);
          if(chdir(("cell"+to_string(i)).c_str())==0)
            {
              int sigdig=6;

              ofstream ifposf("ifpos.out");
              ifposf.setf(ios::fixed);
              ifposf.precision(sigdig);

              ofstream cslf("csl.out");
              cslf.setf(ios::fixed);
              cslf.precision(sigdig);

              ofstream dscf("dsc.out");
              dscf.setf(ios::fixed);
              dscf.precision(sigdig);

              ofstream misorientf("misorient.out");
              misorientf.setf(ios::fixed);
              misorientf.precision(sigdig);

              ofstream axesf("axes.out");
              axesf.setf(ios::fixed);
              axesf.precision(sigdig);

              ofstream areaf("area.out");
              areaf.setf(ios::fixed);
              areaf.precision(sigdig);

              ofstream strainf("strain.out");
              strainf.setf(ios::fixed);
              strainf.precision(sigdig);

              ofstream latf("lat.in");
              latf.setf(ios::fixed);
              latf.precision(sigdig);

              ofstream strf("str.out");
              strf.setf(ios::fixed);
              strf.precision(sigdig);

              ifposf << cutcells(i).ifaces << endl;
              cslf << cutcells(i).i << endl << cutcells(i).j << endl << cutcells(i).k << endl;
              dscf << cutcells(i).dsc;
              misorientf << cutcells(i).A;
              axesf << cutcells(i).axes;
              areaf << cutcells(i).area << endl;
              strainf << cutcells(i).strain << endl;
              write_lattice(lats(i),labellookups(i),labels(i),cutcells(i).axes,latf);
              write_structure(cutcells(i).origstr,labels(i),cutcells(i).axes, strf);

              chdir("..");
            }
        }
      chdir("..");
    }
}

void write_csls(Array<Array<CutCells> > cutcellss, Array<Structure> lats, Array<ArrayArrayint> labellookups, Array<Array<AutoString> > labels)
{
  for(int i = 0; i < cutcellss(); i++)
    {
      write_csl(cutcellss(i), i, lats, labellookups, labels);
    }
}

void read_cutcells(ParsedCutCells *ret, const string csldir)
{
  int sigdig = 6;
  ret->cutcells = Array<CutCells>(1);

  string ifposp = csldir + (string) "/ifpos.out";
  string cslp = csldir + (string) "/csl.out";
  string dscp = csldir + (string) "/dsc.out";
  string misorientp = csldir + (string) "/misorient.out";
  string axesp = csldir + (string) "/axes.out";
  string areap = csldir + (string) "/area.out";
  string strainp = csldir + (string) "/strain.out";
  string latp = csldir + (string) "/lat.in";
  string strp = csldir + (string) "/str.out";

  ifstream ifposf(ifposp.c_str());
  ifposf.setf(ios::fixed);
  ifposf.precision(sigdig);

  ifstream cslf(cslp.c_str());
  cslf.setf(ios::fixed);
  cslf.precision(sigdig);

  ifstream dscf(dscp.c_str());
  dscf.setf(ios::fixed);
  dscf.precision(sigdig);

  ifstream misorientf(misorientp.c_str());
  misorientf.setf(ios::fixed);
  misorientf.precision(sigdig);

  ifstream axesf(axesp.c_str());
  axesf.setf(ios::fixed);
  axesf.precision(sigdig);

  ifstream areaf(areap.c_str());
  areaf.setf(ios::fixed);
  areaf.precision(sigdig);

  ifstream strainf(strainp.c_str());
  strainf.setf(ios::fixed);
  strainf.precision(sigdig);

  ifstream latf(latp.c_str());
  latf.setf(ios::fixed);
  latf.precision(sigdig);

  ifstream strf(strp.c_str());
  strf.setf(ios::fixed);
  strf.precision(sigdig);

  string ifposerr="Unable to open interface position file " + ifposp;
  string cslerr="Unable to open CSL file " + cslp;
  string dscerr="Unable to open DSC file " + dscp;
  string misorienterr="Unable to open misorientation file " + misorientp;
  string axeserr="Unable to open axes file " + axesp;
  string areaerr="Unable to open area file " + areap;
  string strainerr="Unable to open strain file " + strainp;
  string laterr="Unable to open lattice file " + latp;
  string strerr="Unable to open structure file " + strp;

  if (!ifposf) ERRORQUIT(ifposerr);
  if (!cslf) ERRORQUIT(cslerr);
  if (!dscf) ERRORQUIT(dscerr);
  if (!misorientf) ERRORQUIT(misorienterr);
  if (!axesf) ERRORQUIT(axeserr);
  if (!areaf) ERRORQUIT(areaerr);
  if (!strainf) ERRORQUIT(strainerr);
  if (!latf) ERRORQUIT(laterr);
  if (!strf) ERRORQUIT(strerr);

  int ncutpos = 0;

  ifposf >> ncutpos;

  ret->cutcells[0].ifaces = Array<rVector3d>(ncutpos);

  for(int n = 0; n < ncutpos; n++)
    {
      ifposf >> ret->cutcells[0].ifaces[n];
    }

  cslf >> ret->cutcells[0].i >> ret->cutcells[0].j >> ret->cutcells[0].k;
  dscf >> ret->cutcells[0].dsc;
  misorientf >> ret->cutcells[0].A;
  axesf >> ret->cutcells[0].axes;
  areaf >> ret->cutcells[0].area;
  strainf >> ret->cutcells[0].strain;
  parse_lattice_file(&(ret->lat.cell), &(ret->lat.atom_pos), &(ret->lat.atom_type), &ret->labellookup, &ret->label, latf, &(ret->cutcells[0].axes));
  wrap_inside_cell(&(ret->lat.atom_pos),ret->lat.atom_pos,ret->lat.cell);
  parse_structure_file(&(ret->cutcells[0].origstr.cell), &(ret->cutcells[0].origstr.atom_pos), &(ret->cutcells[0].origstr.atom_type), ret->label, strf, NULL);
  wrap_inside_cell(&(ret->cutcells[0].origstr.atom_pos),ret->cutcells[0].origstr.atom_pos,ret->cutcells[0].origstr.cell);
}

void read_cutcells(Array<ParsedCutCells> *ret, const string csldir1, const string csldir2)
{
  read_cutcells(&(*ret)[0],csldir1);
  read_cutcells(&(*ret)[1],csldir2);
}

void gen_supercell(Structure *supcell, const Structure &str, const rMatrix3d &p, const rMatrix3d &A)
{
  Structure strdup(str);

  supcell->cell = supcell->cell * p;

  *supcell = rotate_cell(*supcell,A);
  strdup = rotate_cell(str,A);

  find_all_atom_in_supercell(&(supcell->atom_pos),&(supcell->atom_type),strdup.atom_pos,strdup.atom_type,strdup.cell,supcell->cell);
}

Real min_nonzero(const Real &a, const Real &b)
{
  if(near_zero(a))
    {
      return(b);
    }
  else if(near_zero(b))
    {
      return(a);
    }
  else
    {
      return(min(a,b));
    }
}

void find_csl_supercell(rMatrix3d *ret, const Structure &str, const rVector3d &i, const rVector3d &j, const rVector3d &k)
{
  rMatrix3d tmp,iter;
  iter.set_column(0,i);
  iter.set_column(0,j);

  LatticePointIterator a1(str.cell,1);

  rVector3d newk;

  for(;; a1++)
    {
      rVector3d tmpvec(a1);
      Real tdi = angle(tmpvec,i);
      Real tdj = angle(tmpvec,j);
      Real tdk = angle(tmpvec,k);
      iter.set_column(2,tmpvec);
      if(tdi > zero_tolerance && tdj > zero_tolerance && abs(tdi - M_PI) > zero_tolerance && abs(tdj - M_PI) > zero_tolerance && i * (j ^ tmpvec) > zero_tolerance)
        {
          newk = tmpvec;
          break;
        }
    }

  tmp.set_column(0,i);
  tmp.set_column(1,j);
  tmp.set_column(2,newk);

  *ret = !str.cell * tmp;
}

void find_cutpoints_supercell(Array<CutPoint> *cutpoints, const Array<PointOpTrans> &symops, const Structure &str, const rMatrix3d &rotmat, const rVector3d &cutpos, const rVector3d &i, const rVector3d &j, const rVector3d &k, const Real &tmin)
{
  LinkedList<CutPoint> retlist;
  rVector3d t1 = str.cell.get_column(0);
  rVector3d t2 = str.cell.get_column(1);
  rVector3d t3 = str.cell.get_column(2);
  for(int ii = 0; ii < symops(); ii++)
    {
      rVector3d cutpos_o = rotmat*cutpos;
      PointOpTrans symop = symops(ii);
      rVector3d k_t = symop.inversion ? symop.point_op * k : -symop.point_op * k;
      rVector3d transvec = -t3;
      if(transvec * k_t / (norm(k_t) * norm(transvec)) < -zero_tolerance)
        {
          transvec = -transvec;
        }
      rVector3d cutpos_t = symop.point_op * cutpos_o + symop.trans;
      int n1 = 1; int n2 = 1; int n3 = 1;
      CutPoint *cp = new CutPoint;
      rMatrix3d id3;
      id3.identity();
      while((k_t * (cutpos_t - cutpos_o)) / norm(k_t) < tmin)
        {
          cutpos_t = cutpos_t + transvec;
          symop.trans = symop.trans + transvec;
        }
      rVector3d fcutpos_o = !str.cell * cutpos_o;
      rVector3d fcutpos_t = !str.cell * cutpos_t;
      while(fcutpos_o(0) <= zero_tolerance || fcutpos_t(0) <= zero_tolerance)
        {
          fcutpos_o(0)+=1;
          fcutpos_t(0)+=1;
        }
      while(fcutpos_o(1) <= zero_tolerance || fcutpos_t(1) <= zero_tolerance)
        {
          fcutpos_o(1)+=1;
          fcutpos_t(1)+=1;
        }
      while(fcutpos_o(2) <= zero_tolerance || fcutpos_t(2) <= zero_tolerance)
        {
          fcutpos_o(2)+=1;
          fcutpos_t(2)+=1;
        }
      symop.trans = symop.trans - symop.point_op * (str.cell * fcutpos_o - cutpos_o) + str.cell * fcutpos_o - cutpos_o;

      if(fcutpos_t(0) >= fcutpos_o(0))
        {
          while((fcutpos_t(0) - fcutpos_o(0)) >= 1)
            {
              fcutpos_t(0) -= 1;
              symop.trans -= t1;
            }
        }
      else
        {
          while((fcutpos_t(0) - fcutpos_o(0)) <= -1)
            {
              fcutpos_t(0) += 1;
              symop.trans += t1;
            }
        }
      if(fcutpos_t(1) >= fcutpos_o(1))
        {
          while((fcutpos_t(1) - fcutpos_o(1)) >= 1)
            {
              fcutpos_t(1) -= 1;
              symop.trans -= t2;
            }
        }
      else
        {
          while((fcutpos_t(1) - fcutpos_o(1)) <= -1)
            {
              fcutpos_t(1) += 1;
              symop.trans += t2;
            }
        }

      n1 = ceil(max(fcutpos_o(0),fcutpos_t(0)));
      n2 = ceil(max(fcutpos_o(1),fcutpos_t(1)));
      n3 = ceil(max(fcutpos_o(2),fcutpos_t(2)));

      cp->cutpos = str.cell * fcutpos_o;
      cp->i = i;
      cp->j = j;
      cp->k = k;
      cp->cutpos_t = str.cell * fcutpos_t;
      cp->k_t = k_t;
      cp->d1 = n1;
      cp->d2 = n2;
      cp->d3 = n3;
      cp->transvec = transvec;
      cp->symop = symop;
      retlist << cp;
    }
  LinkedList_to_Array(cutpoints,retlist);
}

int nbonds(const Structure &supstr, const int rmax)
{
  LinkedList<Array<rVector3d> > bond_list;
  Array<Array<rVector3d> > bond_list_arr;
  EqModCell eqmodcell(supstr.cell);
  for (int at=0; at<supstr.atom_pos.get_size(); at++) {
    Real d1nn=(rmax==0. ? find_1nn_radius(supstr,at) : rmax);
    AtomPairIterator ibond(supstr.cell,supstr.atom_pos(at),supstr.atom_pos);
    for (; ibond.length()<d1nn+zero_tolerance; ibond++) {
      add_unique(&bond_list,(Array<rVector3d>)ibond,eqmodcell);
    }
  }
  LinkedList_to_Array(&bond_list_arr, bond_list);
  return(bond_list.getSize());
}

void cut_at_cutpoints_supercell(Array<SymCutCell> *symcutcells, const Array<CutPoint> &cutpoints, const Structure &str, const rMatrix3d &axes, const int &sizex, const int &sizey)
{
  LinkedList<SymCutCell> retlist;
  rMatrix3d id3;
  id3.identity();

  for(int i = 0; i < cutpoints(); i++)
    {
      rMatrix3d p;
      p.set_diagonal(sizex,sizey,cutpoints(i).d3);

      Structure supcell(str);
      gen_supercell(&supcell,str, p, id3);
      rVector3d cutpos = cutpoints(i).cutpos;
      rVector3d cutpos_t = cutpoints(i).cutpos_t;
      rVector3d transvec = cutpoints(i).transvec;
      CutCell tmp;
      cut_cell(&tmp,supcell, cutpos, cutpoints(i).k);
      CutCell tmp2;
      cut_cell(&tmp2,tmp.str, cutpos_t, cutpoints(i).k_t);
      SymCutCell symcutcell;
      symcutcell.origstr = supcell;
      symcutcell.cutstr = tmp.str;
      symcutcell.symcutstr = tmp2.str;
      symcutcell.str = tmp2.str;
      Array<int> ifacepos_o,ifacepos_t;
      find_interface_atoms(&ifacepos_o, symcutcell.str, cutpos, cutpoints(i).k);
      find_interface_atoms(&ifacepos_t, symcutcell.str, cutpos_t, cutpoints(i).k_t);
      rVector3d kold = symcutcell.str.cell.get_column(2);
      rVector3d zhat = kold / norm(kold);
      rVector3d khat = cutpoints(i).k / norm(cutpoints(i).k);
      rVector3d cutpos_proj = ((cutpos * khat) / (zhat * khat)) * zhat;
      rVector3d knew = (((cutpos_t - cutpos) * khat) / (zhat * khat)) * zhat;
      symcutcell.str.cell.set_column(2, knew);
      for(int p = 0; p < symcutcell.str.atom_pos(); p++)
        {
          symcutcell.str.atom_pos(p) = symcutcell.str.atom_pos(p) - cutpos_proj;
        }

      PointOpTrans symop(cutpoints(i).symop);
      symop.trans = symop.trans + symop.point_op * cutpos_proj - cutpos_proj;

      symcutcell.cutpos = cutpos - cutpos_proj;
      symcutcell.cutpos_t = cutpos_t - cutpos_proj;
      symcutcell.ifacepos_o = ifacepos_o;
      symcutcell.ifacepos_t = ifacepos_t;
      symcutcell.k = cutpoints(i).k;
      symcutcell.k_t = cutpoints(i).k_t;
      symcutcell.nbatom = symcutcell.str.atom_pos();
      symcutcell.volume = volume(symcutcell.str);
      symcutcell.symop = symop;
      retlist << new SymCutCell(symcutcell);
    }
  LinkedList_to_Array(symcutcells, retlist);
}

void get_rotation_matrix(rMatrix3d *rotmat, const Structure &cell1, const Structure &cell2)
{
  rVector3d t1 = cell1.cell.get_column(0);
  rVector3d t2 = cell1.cell.get_column(1);
  rVector3d t3 = t1^t2;
  t3.normalize();
  rVector3d u1 = cell2.cell.get_column(0);
  rVector3d u2 = cell2.cell.get_column(1);
  rVector3d u3 = u1^u2;
  u3.normalize();

  rMatrix3d u,v;
  v = cell1.cell;
  u = cell2.cell;
  v.set_column(2,t3);
  u.set_column(2,u3);

  *rotmat = v * !u;
}

Structure align_cell(Structure cell1, Structure cell2)
{
  rMatrix3d rotmat;
  get_rotation_matrix(&rotmat,cell1,cell2);
  Structure ret = rotate_cell(cell2, rotmat);
  return(ret);
}

void calc_in_plane_size(int *sfx, int *sfy, const Array<CutPoint> &cell1s, const Array<CutPoint> &cell2s, Real &sxmax, Real &symax)
{
  int sizexi = ceil(2*sxmax);
  int sizeyi = ceil(2*symax);

  int sx = sizexi;
  int sy = sizeyi;

  for(int i = 0; i < cell1s(); i++)
    {
      if(cell1s(i).d1 >= sx)
        sx =cell1s(i).d1;
      if(cell1s(i).d2 >= sy)
        sy =cell1s(i).d2;
    }
  for(int i = 0; i < cell2s(); i++)
    {
      if(cell2s(i).d1 >= sx)
        sx =cell2s(i).d1;
      if(cell2s(i).d2 >= sy)
        sy =cell2s(i).d2;
    }
  *sfx = sx;
  *sfy = sy;
}

SymCutCell invert_cell(const SymCutCell symcutcell,const bool invert)
{
  rMatrix3d cell = symcutcell.str.cell;
  Array<int> ifacepos_o = symcutcell.ifacepos_o;
  Array<int> ifacepos_t = symcutcell.ifacepos_t;
  SymCutCell ret(symcutcell);

  if(invert)
    {
      if((!cell * symcutcell.str.atom_pos(ifacepos_o(0)))(2) < (!cell * symcutcell.str.atom_pos(ifacepos_t(0)))(2))
        {
          for(int i = 0; i < ret.str.atom_pos(); i++)
            {
              rVector3d fatom_pos = !cell * ret.str.atom_pos(i);
              fatom_pos(2) = 1-fatom_pos(2);
              ret.str.atom_pos(i) = rVector3d(cell * fatom_pos);
            }
        }
    }
  else
    {
      if((!cell * symcutcell.str.atom_pos(ifacepos_t(0)))(2) < (!cell * symcutcell.str.atom_pos(ifacepos_o(0)))(2))
        {
          for(int i = 0; i < ret.str.atom_pos(); i++)
            {
              rVector3d fatom_pos = !cell * ret.str.atom_pos(i);
              fatom_pos(2) = 1-fatom_pos(2);
              ret.str.atom_pos(i) = rVector3d(cell * fatom_pos);
            }
        }
    }
  return(ret);
}

void shift_cell(Array<ShiftedCell> *shiftedcells, const SymCutCell &cutcell, const Real &sxmax, const Real &symax, const Real &nxs, const Real &nys, const rMatrix3d &dsc)
{
  LinkedList<ShiftedCell> shifted;
  rVector3d d1,d2;

  d1 = dsc.get_column(0);
  d2 = dsc.get_column(1);

  for(int x = -nxs; x <= nxs; x++)
    {
      for(int y = -nys; y <= nys; y++)
        {
          ShiftedCell *tmp = new ShiftedCell;
          SymCutCell tmpstr = SymCutCell(cutcell);
          for(int k = 0; k < tmpstr.str.atom_pos(); k++)
            {
              tmpstr.str.atom_pos(k) = tmpstr.str.atom_pos(k) + double(x)/double(nxs) * sxmax * d1 + double(y)/double(nys) * symax * d2;
            }
          tmp->cutcell = tmpstr;
          tmp->d1shift = rVector3d(double(x)/double(nxs) * sxmax * d1);
          tmp->d2shift = rVector3d(double(y)/double(nys) * symax * d2);
          shifted << tmp;
        }
    }
  LinkedList_to_Array(shiftedcells, shifted);
}

void combine_cells(Array<CombinedCell> *combined_cells, const Array<SymCutCell> &cell1s, const Array<SymCutCell> &cell2s, const int nbatomp1, const int nbatomp2, const int nbbonds1, const int nbbonds2, const Real &vol1, const Real &vol2, const Real &sxmax, const Real &symax, const Real &nxs, const Real &nys, const rMatrix3d &dsc, const Real &gap)
{
  LinkedList<CombinedCell> retlist;

  Real g;
  Real d1 = nbatomp1 / vol1;
  Real d2 = nbatomp2 / vol2;

  for(int i = 0; i < cell1s(); i++)
    {
      SymCutCell cell1 = invert_cell(cell1s(i),true);
      int nbatom1 = cell1.nbatom;
      PointOpTrans symop1 = cell1.symop;
      rVector3d cutpos_o1 = cell1.cutpos;
      rVector3d cutpos_t1 = cell1.cutpos_t;
      rVector3d x1 = cell1.str.cell.get_column(0);
      rVector3d y1 = cell1.str.cell.get_column(1);
      rVector3d z1 = cell1.str.cell.get_column(2);
      rVector3d z1hat = z1/norm(z1);
      rVector3d k1 = x1 ^ y1;
      rVector3d k1hat = k1/norm(k1);
      Real area = norm(k1);

      for(int j = 0; j < cell2s(); j++)
        {
          SymCutCell cell2 = invert_cell(cell2s(j),false);
          int nbatom2 = cell2.nbatom;
          PointOpTrans symop2 = cell2.symop;
          rVector3d cutpos_o2 = cell2.cutpos;
          rVector3d cutpos_t2 = cell2.cutpos_t;
          rVector3d x2 = cell2.str.cell.get_column(0);
          rVector3d y2 = cell2.str.cell.get_column(1);
          rVector3d z2 = cell2.str.cell.get_column(2);
          rVector3d z2hat = z2/norm(z2);

          int nbatom = nbatom1 + nbatom2;

          Real g = 0;

          if(gap == -1)
            {
              Real d = (nbatom1*1./nbatom)*d1 + (nbatom2*1./nbatom)*d2;
              Real v1 = cell1.volume;
              Real v2 = cell2.volume;
              g = (nbatom/d - (v1 + v2))/(2*area);
              g = g < 0 ? 0 : g;
              cerr << "Automatic gap : " << g << endl;
            }
          else
            {
              cerr << "Manual gap : " << g << endl;
              g = gap;
            }

          if(z1hat*z2hat <= -zero_tolerance)
            {
              cerr << "Aligning third lattice vectors" << endl;
              for(int k = 0; k < cell2.str.atom_pos(); k++)
                {
                  rVector3d fatom_pos = !cell2.str.cell * cell2.str.atom_pos(k);
                  fatom_pos(2) = -fatom_pos(2);
                  cell2.str.atom_pos(k) = rVector3d(cell2.str.cell * fatom_pos);
                }
              cell2.str.cell.set_column(2,-z2);
              z2 = -z2;
              z2hat = -z2hat;
              rVector3d fcutpos_o2 = !cell2.str.cell * cutpos_o2;
              fcutpos_o2(2) = -fcutpos_o2(2);
              cutpos_o2 = rVector3d(cell2.str.cell * fcutpos_o2);
            }
          if(z1hat*k1hat <= -zero_tolerance)
            {
              cerr << "Aligning out-of-plane vector" << endl;
              k1 = -k1;
              k1hat = -k1hat;
            }

          Array<ShiftedCell> cell2_shifted;
          shift_cell(&cell2_shifted, cell2, sxmax, symax, nxs, nys, dsc);

          for(int jj = 0; jj < cell2_shifted(); jj++)
            {
              SymCutCell c1(cell1);
              ShiftedCell c2(cell2_shifted(jj));
              Structure s1(c1.str);
              Structure s2(c2.cutcell.str);
              rVector3d d = c2.d1shift + c2.d2shift;
              rVector3d z1pg = z1 + (g/(k1hat * z1hat))*z1hat;
              rVector3d z2pg = z2 + (g/(k1hat * z2hat))*z2hat;
              rVector3d znew = z1pg + d + z2pg + d;
              LinkedList<rVector3d> combinedpos,s1pos,s2pos;
              LinkedList<int> combinedtype,s1type,s2type;

              for(int k = 0; k < s1.atom_pos(); k++)
                {
                  combinedpos << new rVector3d(s1.atom_pos(k) + ((g/2)/(k1hat * z1hat))*z1hat);
                  s1pos << new rVector3d(s1.atom_pos(k) + ((g/2)/(k1hat * z1hat))*z1hat);
                  combinedtype << new int(s1.atom_type(k));
                  s1type << new int(s1.atom_type(k));
                }
              for(int k = 0; k < s2.atom_pos(); k++)
                {
                  combinedpos << new rVector3d(s2.atom_pos(k) + z1 + (g/(k1hat*z1hat))*z1hat + ((g/2)/(k1hat*z2hat))*z2hat);
                  s2pos << new rVector3d(s2.atom_pos(k) + z1 + (g/(k1hat*z1hat))*z1hat + ((g/2)/(k1hat*z2hat))*z2hat);
                  combinedtype << new int(s2.atom_type(k));
                  s2type << new int(s2.atom_type(k));
                }

              rVector3d combined_cutpos_o1 = cutpos_o1 + ((g/2)/(k1hat * z1hat))*z1hat;
              rVector3d combined_cutpos_t1 = cutpos_t1 + ((g/2)/(k1hat * z1hat))*z1hat;
              rVector3d combined_cutpos_o2 = cutpos_o2 + z1 + (g/(k1hat*z1hat))*z1hat + ((g/2)/(k1hat*z2hat))*z2hat + d;
              rVector3d combined_cutpos_t2 = cutpos_t2 + z1 + (g/(k1hat*z1hat))*z1hat + ((g/2)/(k1hat*z2hat))*z2hat + d;
              PointOpTrans combined_symop1(symop1),combined_symop2(symop2);
              combined_symop1.trans = combined_symop1.trans - combined_symop1.point_op * (((g/2)/(k1hat * z1hat))*z1hat) + ((g/2)/(k1hat * z1hat))*z1hat;
              combined_symop2.trans = combined_symop2.trans - combined_symop2.point_op * (z1 + (g/(k1hat*z1hat))*z1hat + ((g/2)/(k1hat*z2hat))*z2hat + d) + z1 + (g/(k1hat*z1hat))*z1hat + ((g/2)/(k1hat*z2hat))*z2hat + d;

              // cout << combined_symop1.point_op * combined_cutpos_o1 + combined_symop1.trans << ":" << combined_cutpos_t1 << endl
              //      << combined_symop2.point_op * combined_cutpos_o2 + combined_symop2.trans << ":" << combined_cutpos_t2 << endl;

              // cout << d << ":" << combined_symop1.point_op * d << "," << combined_symop2.point_op * d << endl
              //      << combined_symop1.trans << ":" << angle(combined_symop1.trans,znew) << "," << combined_symop2.trans << ":" << angle(combined_symop2.trans,znew) << endl << endl;

              CombinedCell combined;
              Structure combinedstr;
              combinedstr.cell = s1.cell;
              combinedstr.cell.set_column(2,znew);
              s1.cell.set_column(2,znew);
              s2.cell.set_column(2,znew);
              LinkedList_to_Array(&combinedstr.atom_pos, combinedpos);
              LinkedList_to_Array(&combinedstr.atom_type, combinedtype);
              LinkedList_to_Array(&s1.atom_pos, s1pos);
              LinkedList_to_Array(&s1.atom_type, s1type);
              LinkedList_to_Array(&s2.atom_pos, s2pos);
              LinkedList_to_Array(&s2.atom_type, s2type);
              wrap_inside_cell(&(s1.atom_pos),s1.atom_pos,s1.cell);
              wrap_inside_cell(&(s2.atom_pos),s2.atom_pos,s2.cell);
              wrap_inside_cell(&(combinedstr.atom_pos),combinedstr.atom_pos,combinedstr.cell);

              int nbbonds = nbonds(combinedstr, 0);
              Real criterion = (nbbonds*1. - nbbonds1*(nbatom1*1./nbatomp1) - nbbonds2*(nbatom2*1./nbatomp2))/area;

              combined.str = combinedstr;
              combined.grain1 = s1;
              combined.grain2 = s2;
              combined.d1shift = rVector3d(c2.d1shift);
              combined.d2shift = rVector3d(c2.d2shift);
              combined.criterion = criterion;
              combined.gap = g;

              retlist << new CombinedCell(combined);
            }
        }
    }
  LinkedList_to_Array(combined_cells, retlist);
}

int main(int argc, char *argv[])
{
  char *latfilename1="";
  char *latfilename2="";
  char *cellfilename1="";
  char *cellfilename2="";
  char *csldir="";
  char *csloutdir=".";
  Real rmax=0;
  Real amax=0;
  Real sizex=0;
  Real sizey=0;
  Real sxmax=1;
  Real symax=1;
  Real nxs=0;
  Real nys=0;
  Real tmin=0;
  Real gap=-1;
  Real eps=zero_tolerance;
  int listonly=0;
  AskStruct options[]=
    {
     {"","Coincidence Site Lattice " MAPS_VERSION ", by Chiraag Nataraj and Axel van de Walle",TITLEVAL,NULL},
     {"-l1","Input file defining the first lattice",STRINGVAL,&latfilename1},
     {"-l2","Input file defining the second lattice",STRINGVAL,&latfilename2},
     {"-s1","Input file defining the first structure",STRINGVAL,&cellfilename1},
     {"-s2","Input file defining the second structure",STRINGVAL,&cellfilename2},
     {"-ma","maximum lattice parameter",REALVAL,&rmax},
     {"-ms","maximum in-plane area of CSL unit cell",REALVAL,&amax},
     {"-e","maximum strain",REALVAL,&eps},
     {"-listonly","list CSLs without writing to disk",BOOLVAL,&listonly},
     {"-csl","Directory containing CSL",STRINGVAL,&csldir},
     {"-co","Directory to output combined grain ",STRINGVAL,&csloutdir},
     {"-sx","Size of grain in t1 direction ",REALVAL,&sizex},
     {"-sy","Size of grain in t2 direction ",REALVAL,&sizey},
     {"-t","Minimum thickness of grain perpendicular to the interface ",REALVAL,&tmin},
     {"-nsx","number of DSC shifts in t1 direction ",REALVAL,&nxs},
     {"-nsy","number of DSC shifts in t2 direction ",REALVAL,&nys},
     {"-g","gap between grains",REALVAL,&gap}
    };

  if (!get_values(argc,argv,countof(options),options))
    {
      display_help(countof(options),options);
      return 1;
    }

  if(latfilename1 != ""
     &&
     latfilename2 != ""
     &&
     cellfilename1 != ""
     &&
     cellfilename2 != ""
     &&
     latfilename1 != ""
     &&
     latfilename2 != "")
    {
      rMatrix3d cell1,cell2;
      rMatrix3d axes1,axes2;
      Structure str1,str2;
      Structure lat1,lat2;
      ArrayArrayint labellookup1,labellookup2;
      Array<AutoString> label1,label2;

      Parsed parsed1;
      Parsed parsed2;

      parse_files(&parsed1,latfilename1,cellfilename1);
      parse_files(&parsed2,latfilename2,cellfilename2);

      lat1 = parsed1.lat; labellookup1 = parsed1.labellookup; label1 = parsed1.label;
      axes1 = parsed1.axes; str1 = parsed1.str; cell1 = parsed1.cell;

      lat2 = parsed2.lat; labellookup2 = parsed2.labellookup; label2 = parsed2.label;
      axes2 = parsed2.axes; str2 = parsed2.str; cell2 = parsed2.cell;

      Array<rMatrix3d> point_op1,point_op2;

      find_pointgroup(&point_op1, cell1);
      find_pointgroup(&point_op2, cell2);

      cerr << "Found pointgroups" << endl;

      LinkedList<Array<rVector3d> > vlist;

      find_equal_length_vectors(&vlist, cell1, cell2, rmax, eps);

      cerr << "Found equal-length vectors: " << vlist.getSize() << endl;

      cerr.setf(ios::fixed);
      cerr.precision(6);

      LinkedList<CSL> cs;

      find_csl_vectors(&cs, vlist, !axes1, !axes2, point_op1, point_op2, eps);

      cerr << "Found CSL vectors: " << cs.getSize() << endl;

      if(cs.getSize() != 0)
        {
          rMatrix3d id3;
          id3.identity();

          Array<Structure> strs(2);
          Array<rMatrix3d> axess(2);
          Array<Structure> lats(2);
          Array<ArrayArrayint> labellookups(2);
          Array<Array<AutoString> > labels(2);

          strs[0] = str1; strs[1] = str2;
          axess[0] = axes1; axess[1] = axes2;
          lats[0] = lat1; lats[1] = lat2;
          labellookups[0] = labellookup1; labellookups[1] = labellookup2;
          labels[0] = label1; labels[1] = label2;

          Array<CSL> csarr;
          LinkedList_to_Array(&csarr,cs);

          Array<CSL> cs_sorted;
          sort_csls(&cs_sorted,csarr,amax);
          Array<Array<CutCells> > cutcells(cs_sorted());
          generate_cutcells(&cutcells,cs_sorted,strs,axess);
          Array<bool> inversions(2);
          check_inversions(&inversions, cutcells);
          if(inversions[0] && inversions[1])
            {
              cerr << "Inversion symmetries found for both cells" << endl;
            }
          else
            {
              if(!inversions[0])
                cerr << "Warning: Inversion symmetry not present in first cell." << endl;
              if(!inversions[1])
                cerr << "Warning: Inversion symmetry not present in second cell." << endl;
            }
          print_cutcells(cutcells);
          if(!listonly)
            {
              write_csls(cutcells,lats,labellookups,labels);
            }
        }
    }
  else
    if(csldir != "" && sizex != 0 && sizey != 0 && nxs != 0 && nys != 0)
      {
        Array<ParsedCutCells> parsedcutcells(2);
        string csldir1 = (string) csldir + "/cell0";
        string csldir2 = (string) csldir + "/cell1";
        read_cutcells(&parsedcutcells,csldir1,csldir2);
        ParsedCutCells pc1s = parsedcutcells[0];
        ParsedCutCells pc2s = parsedcutcells[1];
        rMatrix3d id3;
        id3.identity();

        cerr << "Generating supercells" << endl;

        rMatrix3d supcellmat1,supcellmat2;
        find_csl_supercell(&supcellmat1,pc1s.cutcells[0].origstr, pc1s.cutcells[0].i, pc1s.cutcells[0].j, pc1s.cutcells[0].k);
        find_csl_supercell(&supcellmat2,pc2s.cutcells[0].origstr, pc2s.cutcells[0].i, pc2s.cutcells[0].j, pc2s.cutcells[0].k);
        Structure supcell1(pc1s.cutcells[0].origstr);
        gen_supercell(&supcell1,pc1s.cutcells[0].origstr,supcellmat1,id3);
        Structure tmp(pc2s.cutcells[0].origstr);
        gen_supercell(&tmp,pc2s.cutcells[0].origstr,supcellmat2,id3);
        Structure supcell2 = align_cell(supcell1,tmp);
        rMatrix3d rotmat;
        get_rotation_matrix(&rotmat,supcell1,tmp);
        int nbbonds1 = nbonds(supcell1,0);
        int nbbonds2 = nbonds(supcell2,0);
        int nbatomp1 = supcell1.atom_pos();
        int nbatomp2 = supcell2.atom_pos();
        Real vol1 = volume(supcell1);
        Real vol2 = volume(supcell2);

        cerr << "Finding symmetry operations" << endl;

        Array<PointOpTrans> syms1,syms2;
        get_symops_for_csl(&syms1,pc1s.cutcells[0].origstr, pc1s.cutcells[0].k);
        get_symops_for_csl(&syms2,pc2s.cutcells[0].origstr, rotmat*pc2s.cutcells[0].k);

        cerr << "Found " << syms1() << "," << syms2() << " symmetry operations" << endl;

        for(int i1 = 0; i1 < pc1s.cutcells[0].ifaces(); i1++)
          {
            for(int i2 = 0; i2 < pc2s.cutcells[0].ifaces(); i2++)
              {
                cerr << "iface1 : " << pc1s.cutcells[0].ifaces[i1] << endl;
                cerr << "iface2 : " << pc2s.cutcells[0].ifaces[i2] << endl;
                cerr << "Finding cutpoints" << endl;
                Array<CutPoint> supcutpoints1, supcutpoints2;
                find_cutpoints_supercell(&supcutpoints1, syms1, supcell1, id3, pc1s.cutcells[0].ifaces[i1], pc1s.cutcells[0].i, pc1s.cutcells[0].j, pc1s.cutcells[0].k, tmin);
                find_cutpoints_supercell(&supcutpoints2, syms2, supcell2, rotmat, pc2s.cutcells[0].ifaces[i2], pc1s.cutcells[0].i, pc1s.cutcells[0].j, -pc1s.cutcells[0].k, tmin);

                // Calculate in-plane size based on n1 and n2 from each grain and sizex and sizey

                int sx, sy;
                calc_in_plane_size(&sx,&sy,supcutpoints1,supcutpoints2,sxmax,symax);

                cerr << "Final cell size : " << sx << "x" << sy << endl;

                cerr << "Cutting at cutpoints" << endl;

                Array<SymCutCell> symcutsupcells1, symcutsupcells2;
                cut_at_cutpoints_supercell(&symcutsupcells1, supcutpoints1, supcell1, pc1s.cutcells[0].axes, sx, sy);
                cut_at_cutpoints_supercell(&symcutsupcells2, supcutpoints2, supcell2, pc2s.cutcells[0].axes, sx, sy);

                cerr << "Assembling grains" << endl;

                Array<CombinedCell> combined;
                combine_cells(&combined,symcutsupcells1, symcutsupcells2, nbatomp1, nbatomp2, nbbonds1, nbbonds2, vol1, vol2, sxmax, symax, nxs, nys, pc2s.cutcells[0].dsc, gap);

                string outdir = csloutdir + (string) "_" + to_string(pc1s.cutcells[0].ifaces[i1][0]) + "," + to_string(pc1s.cutcells[0].ifaces[i1][1]) + "," + to_string(pc1s.cutcells[0].ifaces[i1][2]) + (string) "_" + to_string(pc2s.cutcells[0].ifaces[i2][0]) + "," + to_string(pc2s.cutcells[0].ifaces[i2][1]) + "," + to_string(pc2s.cutcells[0].ifaces[i2][2]);

                mkdir(outdir.c_str(),S_IRWXU | S_IRWXG | S_IRWXO);

                ofstream criterionout(outdir + (string) "/criterion.out");
                ofstream gapout(outdir + (string) "/gaps.out");

                ofstream supcellout1(outdir + (string) "/supcell1.out");
                ofstream supcellout2(outdir + (string) "/supcell2.out");
                write_structure(supcell1, pc1s.label, pc1s.cutcells[0].axes, supcellout1);
                write_structure(supcell2, pc2s.label, pc2s.cutcells[0].axes, supcellout2);

                for(int i = 0; i < symcutsupcells1(); i++)
                  {
                    ofstream out(outdir + (string) "/symcutsupcell1_" + to_string(i) + ".out");
                    write_structure(symcutsupcells1(i).str,pc1s.label,pc1s.cutcells[0].axes,out);
                    ofstream origout(outdir + (string) "/symcutsupcell1_orig_" + to_string(i) + ".out");
                    write_structure(symcutsupcells1(i).origstr,pc1s.label,pc1s.cutcells[0].axes,origout);
                    ofstream tmpout(outdir + (string) "/symcutsupcell1_tmp_" + to_string(i) + ".out");
                    write_structure(symcutsupcells1(i).cutstr,pc1s.label,pc1s.cutcells[0].axes,tmpout);
                    ofstream tmp2out(outdir + (string) "/symcutsupcell1_tmp2_" + to_string(i) + ".out");
                    write_structure(symcutsupcells1(i).symcutstr,pc1s.label,pc1s.cutcells[0].axes,tmp2out);
                  }

                for(int i = 0; i < symcutsupcells2(); i++)
                  {
                    ofstream out(outdir + (string) "/symcutsupcell2_" + to_string(i) + ".out");
                    write_structure(symcutsupcells2(i).str,pc2s.label,pc2s.cutcells[0].axes,out);
                    ofstream origout(outdir + (string) "/symcutsupcell2_orig_" + to_string(i) + ".out");
                    write_structure(symcutsupcells2(i).origstr,pc2s.label,pc2s.cutcells[0].axes,origout);
                    ofstream tmpout(outdir + (string) "/symcutsupcell2_tmp_" + to_string(i) + ".out");
                    write_structure(symcutsupcells2(i).cutstr,pc2s.label,pc2s.cutcells[0].axes,tmpout);
                    ofstream tmp2out(outdir + (string) "/symcutsupcell2_tmp2_" + to_string(i) + ".out");
                    write_structure(symcutsupcells2(i).symcutstr,pc2s.label,pc2s.cutcells[0].axes,tmp2out);
                  }

                for(int i = 0; i < combined(); i++)
                  {
                    rVector3d d1 = combined(i).d1shift;
                    rVector3d d2 = combined(i).d2shift;
                    string outfile = (string) "combined_" + to_string(i) + "_" + to_string(d1[0]) + "," + to_string(d1[1]) + "," + to_string(d1[2]) + "_" + to_string(d2[0]) + "," + to_string(d2[1]) + "," + to_string(d2[2]) + ".out";
                    string grain1file = (string) "grain1_" + outfile;
                    string grain2file = (string) "grain2_" + outfile;
                    ofstream out(outdir + (string) "/" + outfile);
                    ofstream g1out(outdir + (string) "/" + grain1file);
                    ofstream g2out(outdir + (string) "/" + grain2file);
                    write_structure(combined(i).str,pc1s.label,pc1s.cutcells[0].axes,out);
                    write_structure(combined(i).grain1,pc1s.label,pc1s.cutcells[0].axes,g1out);
                    write_structure(combined(i).grain2,pc2s.label,pc2s.cutcells[0].axes,g2out);
                    criterionout << outfile << " " << combined(i).criterion << endl;
                    gapout << outfile << " " << combined(i).gap << endl;
                  }
              }
          }
      }
    else
      {
        display_help(countof(options),options);
        return 1;
      }

}
