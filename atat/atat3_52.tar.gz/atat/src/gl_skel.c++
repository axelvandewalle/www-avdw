#include <GL/glut.h>
#include <iostream>
#include <fstream>
#include "arraylist.h"
#include "linalg.h"
#include "meshcalc.h"
#include "meshutil.h"
#include "getvalue.h"

#define PASTETWO(A,B) A##B

#define MEMBER_CALLBACK(RETTYPE,MEMBER,ARGTYPE,ARGNAME)			\
  static RETTYPE PASTETWO(static_,MEMBER) ARGTYPE {			\
    return pcurrent_instance-> MEMBER ARGNAME;				\
  }									\
  RETTYPE MEMBER ARGTYPE

#define VOID_MEMBER_CALLBACK(MEMBER,ARGTYPE,ARGNAME)			\
  static void PASTETWO(static_,MEMBER) ARGTYPE {			\
    pcurrent_instance-> MEMBER ARGNAME;					\
  }									\
  void MEMBER ARGTYPE

class BlockViewer {
public:
  static BlockViewer *pcurrent_instance;
  LinkedList<int> keysdown;
  int modif;
public:
public:
  BlockViewer(void): icolor(),color() {
    pcurrent_instance=this;
  }
  VOID_MEMBER_CALLBACK(process_normal_keys,(unsigned char key, int x, int y),(key,x,y)) {
    key;
  }
  VOID_MEMBER_CALLBACK(press_key,(int key, int x, int y),(key,x,y)) {
    if (!is_in_list(keysdown,key)) {
      keysdown << new int(key);
    }
    modif=glutGetModifiers();
  }
  VOID_MEMBER_CALLBACK(release_key,(int key, int x, int y),(key,x,y)) {
    LinkedListIterator<int> i(keysdown);
    for (; i; i++) {
      if (*i==key) break;
    }
    if (i) {
      delete keysdown.detach(i);
    }
    modif=glutGetModifiers();
  }
  VOID_MEMBER_CALLBACK(change_size,(int w, int h),(w,h)) {
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glViewport(0, 0, w, h);
    gluPerspective(45.0f, (Real)w/(Real)max(1,h), 0.1f, 100.0f);
    glMatrixMode(GL_MODELVIEW);
  }
  VOID_MEMBER_CALLBACK(render_scene,(void),()) {

    /*    
	  GLUT_ACTIVE_ALT
	  GLUT_ACTIVE_CTRL
	  GLUT_ACTIVE_SHIFT
	  GLUT_KEY_UP
	  GLUT_KEY_DOWN
	  GLUT_KEY_LEFT
	  GLUT_KEY_RIGHT
	  GLUT_KEY_PAGE_UP
	  GLUT_KEY_PAGE_DOWN
    */

    
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    glLoadIdentity();
    gluLookAt(	0.0f, 0.0f, zeye,
		0.0f, 0.0f, 0.0f,
		0.0f, 1.0f,  0.0f);
    
    glEnable(GL_LIGHTING);
    glEnable(GL_LIGHT0);
    GLfloat lightpos[] = {0.5f, 1.0f, 2.0f, 0.0f};
    glLightfv(GL_LIGHT0, GL_POSITION, lightpos);

    glEnable(GL_CULL_FACE);
    glEnable(GL_DEPTH_TEST);
    
    glEnable (GL_BLEND);
    glBlendFunc (GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

    glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);

        calc_normal(&perp,cutpts,*ipoly);
    glNormal3d(perp(0),perp(1),perp(2));
    
    GLfloat curcol[4];
    curcol[3]=1.;
    int imod=icol % cutcolors.get_size();
    for (int i=0; i<min(cutcolors(imod).get_size(),4); i++) {
      curcol[i]=cutcolors(imod)(i)/255.;
    }
    glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT_AND_DIFFUSE, curcol);
    
    for (int j=0; j<3; j++) {
      glVertex3f(cutpts((*ipoly)(j))(0),cutpts((*ipoly)(j))(1),cutpts((*ipoly)(j))(2));
    }

  }

  void init(void) {
    // init GLUT and create window
    glutInitDisplayMode(GLUT_DEPTH | GLUT_DOUBLE | GLUT_RGBA);
    glutInitWindowPosition(20,20);
    glutInitWindowSize(1000,1000);
    glutCreateWindow("BlockViewer");

    glutIgnoreKeyRepeat(1);
    glutDisplayFunc(  &BlockViewer::static_render_scene);
    glutIdleFunc(     &BlockViewer::static_render_scene);
    glutReshapeFunc(  &BlockViewer::static_change_size);
    glutKeyboardFunc( &BlockViewer::static_process_normal_keys);
    glutSpecialFunc(  &BlockViewer::static_press_key);
    glutSpecialUpFunc(&BlockViewer::static_release_key);
  }

};

BlockViewer *BlockViewer::pcurrent_instance=NULL;

int main(int argc, char *argv[]) {
  glutInit(&argc, argv);
  BlockViewer blockviewer;
  viewerdata.init();
  glutMainLoop();
  return 0;
}
