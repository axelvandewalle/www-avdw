#include <GL/glut.h>
#include <iostream>
#include <fstream>
#include <bits/stdc++.h>

#include "arraylist.h"
#include "linalg.h"
#include "meshcalc.h"
#include "meshutil.h"
#include "getvalue.h"

#define PASTETWO(A,B) A##B

#define MEMBER_CALLBACK(RETTYPE,MEMBER,ARGTYPE,ARGNAME)			\
  static RETTYPE PASTETWO(static_,MEMBER) ARGTYPE {			\
    return pcurrent_instance-> MEMBER ARGNAME;				\
  }									\
  RETTYPE MEMBER ARGTYPE

#define VOID_MEMBER_CALLBACK(MEMBER,ARGTYPE,ARGNAME)			\
  static void PASTETWO(static_,MEMBER) ARGTYPE {			\
    pcurrent_instance-> MEMBER ARGNAME;					\
  }									\
  void MEMBER ARGTYPE

istream& operator >> (istream &file, AutoString &str) {
	static char buf[MAX_LINE_LEN];
	file.getline(buf,MAX_LINE_LEN-1);
	str.set(buf);
	return file;
}

template<class T>
void mygl_plot_poly(const Array<T> &cutpts, const LinkedList<Array<int> > &cutpolys, const Array<Array<Real> > &cutcolors) {
  glBegin(GL_TRIANGLES);
  LinkedListIterator<Array<int> > ipoly(cutpolys);
  int icol=0;
  for (; ipoly; ipoly++,icol++) {
    rVector3d perp;
    calc_normal(&perp,cutpts,*ipoly);
    glNormal3d(perp(0),perp(1),perp(2));
    
    GLfloat curcol[4];
    curcol[3]=1.;
    int imod=icol % cutcolors.get_size();
    for (int i=0; i<min(cutcolors(imod).get_size(),4); i++) {
      curcol[i]=cutcolors(imod)(i)/255.;
    }
    glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT_AND_DIFFUSE, curcol);
    
    for (int j=0; j<3; j++) {
      glVertex3f(cutpts((*ipoly)(j))(0),cutpts((*ipoly)(j))(1),cutpts((*ipoly)(j))(2));
    }
    
    glNormal3d(-perp(0),-perp(1),-perp(2));
    for (int j=2; j>=0; j--) {
      glVertex3f(cutpts((*ipoly)(j))(0),cutpts((*ipoly)(j))(1),cutpts((*ipoly)(j))(2));
    }
    
  }
  glEnd();
}

template<class A, class B>
class ClassPair {
public:
  A a;
  B b;
  ClassPair(void): a(), b() {}
  ClassPair(const ClassPair &c): a(c.a), b(c.b) {}
  ClassPair(const A &_a, const B &_b): a(_a), b(_b) {}
};

Real calc_poly_dist(const Array<int> &poly, const Array<Array<Real> > &pts, const Array<Real> &eye) {
  Array<Real> avg(pts(poly(0)));
  for (int p=1; p<poly.get_size(); p++) {
    sum(&avg,avg,pts(poly(p)));
  }
  product(&avg,avg,1./(Real)(poly.get_size()));
  diff(&avg,avg,eye);
  return norm(avg);
}

bool comp_dist(const ClassPair<Real,int> &a, const ClassPair<Real,int> &b) {
  return (a.a>b.a);
}

template<class T>
void mygl_plot_poly(const Array<T> &cutpts, const LinkedList<Array<int> > &cutpolys, const Array<Array<Real> > &cutcolors, const T &eye) {
  Array<Array<int> * > ppoly(cutpolys.get_size());
  Array<ClassPair<Real,int> > distpoly(cutpolys.get_size());
  LinkedListIterator<Array<int> > ipoly(cutpolys);
  for (int i=0; ipoly; ipoly++, i++) {
    ppoly(i)=&(*ipoly);
    int imod=i % cutcolors.get_size();
    Real penal=0;
    if (cutcolors(imod).get_size()>=4 && cutcolors(imod)(3)<255.) {penal=100.;}
    distpoly(i)=ClassPair<Real,int>(calc_poly_dist(*ipoly,cutpts,eye)-penal,i);
  }
  sort(distpoly.get_buf(),distpoly.get_buf()+distpoly.get_size(),comp_dist);
  /*
  cerr << "===\n";
  for (int i=0; i<distpoly.get_size(); i++) {
    cerr << distpoly(i).a << endl;
  }
  */
  glBegin(GL_TRIANGLES);
  for (int icol=0; icol<distpoly.get_size(); icol++) {
    Array<int> &poly=*ppoly(distpoly(icol).b);
    rVector3d perp;
    calc_normal(&perp,cutpts,poly);
    glNormal3d(perp(0),perp(1),perp(2));
    
    GLfloat curcol[4];
    curcol[3]=1.;
    int imod=distpoly(icol).b % cutcolors.get_size();
    for (int i=0; i<min(cutcolors(imod).get_size(),4); i++) {
      curcol[i]=cutcolors(imod)(i)/255.;
    }
    glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT_AND_DIFFUSE, curcol);
    
    for (int j=0; j<3; j++) {
      glVertex3f(cutpts(poly(j))(0),cutpts(poly(j))(1),cutpts(poly(j))(2));
    }
    
    glNormal3d(-perp(0),-perp(1),-perp(2));
    for (int j=2; j>=0; j--) {
      glVertex3f(cutpts(poly(j))(0),cutpts(poly(j))(1),cutpts(poly(j))(2));
    }
    
  }
  glEnd();
}

class ViewerData {
public:
  static ViewerData *pcurrent_instance;
  LinkedList<int> keysdown;
  int firstdown;
  int modif;
  char lastkey;
public:
  int dim;
  Array<Array<Real> > pts;
  LinkedList<Array<int> > polys;
  Array<Array<Real> > colors;
  Array2d<Real> rotation;
  Array<Real> center;
  Array<Real> cutpt;
  Array<Array<Real> > old_trans_pts;
  int otheraxis;
  Real rotanglemag;
  Real movemag;
  Real zeye;
  int writefile;
  int fileindex;
  int displaylabels;
  Array2d<Real> truecoor_t;
  Array<Real> truecoor_s;
  Array<Array<Real> > truecoor_labparam;
  Array<AutoString> truecoor_lab;
  PolyFont3D font;
  Real fontsz;
public:
  ViewerData(void): dim(0),pts(),polys(),rotation(),center(),keysdown(),old_trans_pts(),truecoor_t(),truecoor_s(),truecoor_labparam(),truecoor_lab(),font() {
    pcurrent_instance=this;
    modif=0;
    lastkey=0;
    firstdown=0;
    rotanglemag=M_PI/32;
    movemag=0.02;
    zeye=2.0;
    writefile=0;
    fileindex=0;
    displaylabels=1;
    fontsz=0.025;
  }
  VOID_MEMBER_CALLBACK(process_normal_keys,(unsigned char key, int x, int y),(key,x,y)) {
    lastkey=key;
  }
  VOID_MEMBER_CALLBACK(press_key,(int key, int x, int y),(key,x,y)) {
    if (!is_in_list(keysdown,key)) {
      keysdown << new int(key);
    }
    modif=glutGetModifiers();
    firstdown=1;
  }
  VOID_MEMBER_CALLBACK(release_key,(int key, int x, int y),(key,x,y)) {
    LinkedListIterator<int> i(keysdown);
    for (; i; i++) {
      if (*i==key) break;
    }
    if (i) {
      delete keysdown.detach(i);
    }
    modif=glutGetModifiers();
    firstdown=0;
  }
  VOID_MEMBER_CALLBACK(change_size,(int w, int h),(w,h)) {
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glViewport(0, 0, w, h);
    gluPerspective(45.0f, (Real)w/(Real)max(1,h), 0.1f, 5.0f);
    glMatrixMode(GL_MODELVIEW);
  }
  VOID_MEMBER_CALLBACK(render_scene,(void),()) {
    int axis1=0;
    int axis2=1;
    Real rotangle=0.;
    Real movedist=0.;

    int num=lastkey-'1';
    if (num>=3 && num<dim) {
      otheraxis=num;
    }

    if (lastkey=='f') {
      rotanglemag*=2.;
      movemag*=2.;
    }
    if (lastkey=='s') {
      rotanglemag/=2.;
      movemag/=2.;
    }
    if (lastkey=='r') {
      identity_matrix(&(rotation));
      cutpt=center;
      zeye=2.0;
    }
    if (lastkey=='w') {
      writefile=1-writefile;
    }

    Real currotanglemag=rotanglemag;

    if (modif&GLUT_ACTIVE_SHIFT) {
      if (is_in_list(keysdown,GLUT_KEY_PAGE_UP)) {zeye+=movemag;}
      else if (is_in_list(keysdown,GLUT_KEY_PAGE_DOWN)) {zeye-=movemag;}
      else {
	currotanglemag=M_PI/2.;
      }
    }

    if (modif&GLUT_ACTIVE_ALT) {
      if (is_in_list(keysdown,GLUT_KEY_UP))   {movedist=movemag;}
      if (is_in_list(keysdown,GLUT_KEY_DOWN)) {movedist=-movemag;}
    }
    else {
      if (is_in_list(keysdown,GLUT_KEY_LEFT) || is_in_list(keysdown,GLUT_KEY_DOWN) || is_in_list(keysdown,GLUT_KEY_PAGE_UP))  {rotangle=-currotanglemag;}
      if (is_in_list(keysdown,GLUT_KEY_RIGHT) || is_in_list(keysdown,GLUT_KEY_UP) || is_in_list(keysdown,GLUT_KEY_PAGE_DOWN))  {rotangle=currotanglemag;}
      if (is_in_list(keysdown,GLUT_KEY_LEFT)  || is_in_list(keysdown,GLUT_KEY_RIGHT)) {
	if (modif&GLUT_ACTIVE_CTRL) {axis1=0; axis2=otheraxis;}
	else  {axis1=0; axis2=2;}
      }
      if (is_in_list(keysdown,GLUT_KEY_UP)      || is_in_list(keysdown,GLUT_KEY_DOWN)) {
	if (modif&GLUT_ACTIVE_CTRL) { axis1=1; axis2=otheraxis;}
	else  { axis1=1; axis2=2;}
      }
      if (is_in_list(keysdown,GLUT_KEY_PAGE_UP) || is_in_list(keysdown,GLUT_KEY_PAGE_DOWN)) {
	if (modif&GLUT_ACTIVE_CTRL) { axis1=2; axis2=otheraxis;}
	else { axis1=0; axis2=1;}
      }
    }
    
    Array2d<Real> drotation(dim,dim);
    identity_matrix(&drotation);
    if (!(modif&GLUT_ACTIVE_SHIFT) || firstdown==1) {
      drotation(axis1,axis1)=cos(rotangle);
      drotation(axis2,axis2)=cos(rotangle);
      drotation(axis1,axis2)=-sin(rotangle);
      drotation(axis2,axis1)=sin(rotangle);
    }

    Array2d<Real> tmprot(rotation);
    product(&rotation,drotation,tmprot);

    Array<Real> dcutpt;
    {
      Array<Real> farv(dim);
      zero_array(&farv);
      farv(otheraxis)=movedist;
      inner_product(&dcutpt,rotation,farv);
    }
    sum(&cutpt,cutpt,dcutpt);

    // cerr << rotation << endl;
    
    Array<Real> shift;
    product(&shift,rotation,cutpt);
    product(&shift,shift,-1.);
    sum(&shift,shift,cutpt);

    // cerr << shift << endl;
    
    Array<Array<Real> > trans_pts(pts.get_size());
    for (int i=0; i<trans_pts.get_size(); i++) {
      product(&(trans_pts(i)),rotation,pts(i));
      sum(&trans_pts(i),trans_pts(i),shift);
    }

    Array<Array<Real> > cutpts;
    LinkedList<Array<int> > cutpolys;
    Array<Array<Real> > cutcolors;
    /*
    Array<Array<Real> > cutaxes(3);
    for (int i=0; i<cutaxes.get_size(); i++) {
      cutaxes(i).resize(dim);
      zero_array(&cutaxes(i));
      cutaxes(i)(i)=1.;
    }
    cerr << "begin cut" << endl;
    cross_section_simplexes(&cutpts,&cutpolys,&cutcolors, cutaxes,cutpt,trans_pts,polys,colors);
    */
    Array<int> cutaxes(3);
    for (int i=0; i<cutaxes.get_size(); i++) {
      cutaxes(i)=i;
    }
    // cerr << "begin cut" << endl;
    simple_cross_section_simplexes(&cutpts,&cutpolys,&cutcolors, cutaxes,cutpt,trans_pts,polys,colors);

    //cerr << "pts=" << cutpts.get_size() << " poly=" << cutpolys.get_size() << endl;
    if (lastkey=='d') {
      /*
      cout << "diff" << endl;
      for (int i=0; i<old_trans_pts.get_size(); i++) {
	Array<Real> tmp;
	diff(&tmp,old_trans_pts(i),trans_pts(i));
	cout << tmp << endl;
      }
      cout << "pre-CS\n";
      cout << cutpt << endl;
      cout << cutaxes << endl;
      cout << trans_pts<< endl;
      cout << polys << endl;
      cout << "CS\n";
      old_trans_pts=trans_pts;
      */
      cout << cutpts << endl << cutpolys << endl;
    }
    if (lastkey=='l') {displaylabels=1-displaylabels;}
    if (lastkey=='P') {fontsz+=0.005;}
    if (lastkey=='p') {fontsz-=0.005;}

    Array<Real> midcutpts;
    {
      BoundingHypercube<Array<Real> > box;
      for (int i=0; i<cutpts.get_size(); i++) {
	box.update(cutpts(i));
      }
      sum(&(midcutpts),box.min,box.max);
      product(&(midcutpts),midcutpts,0.5);
      if (midcutpts.get_size()==0) {
	midcutpts.resize(3);
	zero_array(&midcutpts);
      }
    }
    for (int i=0; i<cutpts.get_size(); i++) {
      diff(&cutpts(i),cutpts(i),midcutpts);
    }
    
    Array2d<Real> unrotate(dim,3);
    Array<Real> unshift;
    {
      Array2d<Real> inv_rotation;
      invert_matrix(&inv_rotation,rotation);
      for (int i=0; i<dim; i++) {
	for (int j=0; j<3; j++) {
	  unrotate(i,j)=inv_rotation(i,j);
	}
      }
      product(&unshift,unrotate,midcutpts);
      sum(&unshift,unshift,cutpt);
      //cerr << unshift << endl;
    }
    Array<int> labelled(cutpts.get_size());
    zero_array(&labelled);
    Array<Array<rVector3d> > normal_lab(cutpts.get_size());
    Array<int> nb_normal_lab(cutpts.get_size());
    {
      LinkedListIterator<Array<int> > ipoly(cutpolys);
      for (int icol=0; ipoly; ipoly++,icol++) {
	rVector3d perp;
	calc_normal(&perp,cutpts,*ipoly);
	int imod=icol % cutcolors.get_size();
	if (cutcolors(imod).get_size()==5) {
	  for (int j=0; j<ipoly->get_size(); j++) {
	    int curpt=(*ipoly)(j);
	    labelled(curpt)=1;
	    if (normal_lab(curpt).get_size()==0) {
	      normal_lab(curpt).resize(3);
	      fill_array(&(normal_lab(curpt)),rVector3d(0.,0.,0.));
	      nb_normal_lab(curpt)=0;
	    }
	    int oldp=0;
	    for (; oldp<nb_normal_lab(curpt); oldp++) {
	      if (norm(normal_lab(curpt)(oldp)^perp)<zero_tolerance) {break;}
	    }
	    if (oldp==nb_normal_lab(curpt)) {
	      if (oldp<2) {
		normal_lab(curpt)(nb_normal_lab(curpt))=perp;
		nb_normal_lab(curpt)++;
	      }
	      else {
		if (fabs((normal_lab(curpt)(0) ^ normal_lab(curpt)(1)) * perp)>zero_tolerance ) {
		  normal_lab(curpt)(2)=perp;
		  nb_normal_lab(curpt)=3;
		}
	      }
	    }
	  }
	}
      }
    }
    //cout << "beg\n";
    for (int curpt=0; curpt<labelled.get_size(); curpt++) {
      if (labelled(curpt)) {
	//cout << nb_normal_lab(curpt) << endl;
	if (nb_normal_lab(curpt)<3) {labelled(curpt)=0;}
      }
    }
    
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    glLoadIdentity();
    gluLookAt(	0.0f, 0.0f, zeye,
		0.0f, 0.0f, 0.0f,
		0.0f, 1.0f,  0.0f);
    
    glEnable(GL_LIGHTING);
    glEnable(GL_LIGHT0);
    GLfloat lightpos[] = {0.5f, 1.0f, 2.0f, 0.0f};
    glLightfv(GL_LIGHT0, GL_POSITION, lightpos);

    glEnable(GL_CULL_FACE);
    glEnable(GL_DEPTH_TEST);
    
    glEnable (GL_BLEND);
    glBlendFunc (GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

    glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);

    Array<Real> eye(3);
    eye(0)=0.; eye(1)=0.; eye(2)=zeye;

    if (displaylabels) {
      rVector3d textup(0.,fontsz,0.);
      rVector3d textright(fontsz,0.,0.);
      Array<Array<Real> > labcolors(1);
      labcolors(0).resize(4);
      labcolors(0)(0)=255.0; labcolors(0)(1)=0.0; labcolors(0)(2)=0.0; labcolors(0)(3)=255.0;
      for (int i=0; i<cutpts.get_size(); i++) {
	if (labelled(i)) {
	  Array<Real> coord;
	  product(&coord,unrotate,cutpts(i));
	  sum(&coord,coord,unshift);
	  Array<Real> truecoor;
	  product(&truecoor,truecoor_t,coord);
	  sum(&truecoor,truecoor,truecoor_s);
	  for (int i=0; i<truecoor.get_size(); i++) {
	    truecoor(i)=min(max(truecoor(i),truecoor_labparam(0)(i)),truecoor_labparam(1)(i));
	  }
	  ostrstream strstr;
	  for (int i=0; i<truecoor.get_size(); i++) {
	    strstr << truecoor_lab(i) << setprecision((int)truecoor_labparam(3)(i));
	    if (truecoor_labparam(4)(i)>0.) {strstr << fixed;}
	    strstr << truecoor(i)*truecoor_labparam(2)(i);
	  }
	  for (int i=truecoor.get_size(); i<truecoor_lab.get_size(); i++) {
	    strstr << truecoor_lab(i);
	  }
	  AutoString label;
	  label.set(strstr.str());
	  //cout << label << endl;
	  LinkedList<rVector3d> labptslist;
	  LinkedList<Array<int> > labpoly;
	  rVector3d cutpts3;
	  Array_to_FixedVector(&cutpts3,cutpts(i));
	  Real lenlab=font.get_length(label,0);
	  font.write(&labptslist,&labpoly,cutpts3-textright*(cutpts3(0)<0 ? lenlab:0.)+textup*(cutpts3(1)<0 ? -1.0:0.5),textright,textup,label);
	  Array<rVector3d> labpts;
	  LinkedList_to_Array(&labpts,labptslist);
	  mygl_plot_poly(labpts,labpoly,labcolors);
	}
      }
    }

    mygl_plot_poly(cutpts,cutpolys,cutcolors,eye);
    //mygl_plot_poly(cutpts,cutpolys,cutcolors);


    if (writefile) {
      cerr << "Writing frame" << endl;
      int width=glutGet(GLUT_WINDOW_WIDTH);
      int height=glutGet(GLUT_WINDOW_HEIGHT);
      int bufsize=3 * width * height;
      int stepy=3*width;
      GLubyte *data = new GLubyte[bufsize];
      if( data ) {
	glReadPixels(0, 0, width, height, GL_RGB, GL_UNSIGNED_BYTE, data);
      }
      ostrstream filename;
      filename << "dumpndviewer" << setfill('0') << setw(4) << fileindex << ".pam" << "\0";
      {
	ofstream dumpfile(filename.str());
	dumpfile << "P7" << endl;
	dumpfile << "WIDTH " << width << endl;
	dumpfile << "HEIGHT " << height << endl;
	dumpfile << "DEPTH 3" << endl;
	dumpfile << "MAXVAL 255" << endl;
	dumpfile << "TUPLTYPE RGB" << endl;
	dumpfile << "ENDHDR" << endl;
	//dumpfile.write((char *)data,bufsize);
	for (int y=1; y<=height; y++) {
	  dumpfile.write((char *)data+bufsize-y*stepy,stepy);
	}
      }
      delete data;
      fileindex++;
      cerr << "Done writing frame" << endl;
    }
    glutSwapBuffers();
    lastkey=0;
    firstdown=0;
  }

  void init(const char *filename) {
    {
      LinkedList<Array<Real> > ptslist;
      LinkedList<Array<Real> > colorslist;
      ifstream file(filename);
      if (!file) { ERRORQUIT("Unable to open input file");}
      while (1) {
	Array<Array<Real> > curpts;
	LinkedList<Array<int> > curpolys;
	Array<Array<Real> > curcolors;
	cerr << "reading\n";
	file >> curpts;
	if (curpts.get_size()==0) break;
	file >> curpolys;
	file >> curcolors;
	cerr << "nb pts= " << curpts.get_size() << " nb poly= " << curpolys.get_size() << endl;
	combine_mesh(&ptslist,&polys,curpts,curpolys);
	cerr << "done combining\n";
	LinkedListIterator<Array<int> > ip(curpolys);
	for (int i=0; ip; ip++, i++) {
	  colorslist << new Array<Real>(curcolors(i % curcolors.get_size()));
	}
	cerr << "done colors\n";
      }
      LinkedList_to_Array(&pts,ptslist);
      LinkedList_to_Array(&colors,colorslist);
    }
    cerr << "reading done\n";

    {
      ifstream axesfile("ndaxes.in");
      if (axesfile) {
	axesfile >> truecoor_t;
	axesfile >> truecoor_s;
	axesfile >> truecoor_labparam;
	// min, max, scale, prec, fixed;
	axesfile >> truecoor_lab;
      }
      else {
	int dim=pts(0).get_size();
	set_identity(&truecoor_t,dim);
	truecoor_s.resize(dim);
	zero_array(&truecoor_s);
	truecoor_labparam.resize(5);
	for (int i=0; i<truecoor_labparam.get_size(); i++) {truecoor_labparam(i).resize(dim);}
	fill_array(&(truecoor_labparam(0)),(Real)(-MAXFLOAT));
	fill_array(&(truecoor_labparam(1)),(Real)(MAXFLOAT));
	fill_array(&(truecoor_labparam(2)),1.);
	fill_array(&(truecoor_labparam(3)),2.);
	fill_array(&(truecoor_labparam(4)),0.);
	truecoor_lab.resize(dim);
	fill_array(&truecoor_lab,AutoString(" "));
      }
    }
    {
      AutoString fontfilename("");
      if (fontfilename.len()==0) {
	get_atat_root(&fontfilename);
	fontfilename+="/data/font.dat";
      }
      ifstream fontfile(fontfilename);
      if (!fontfile) ERRORQUIT("Unable to open font file.");
      font.init(fontfile);
    }

    BoundingHypercube<Array<Real> > box;
    for (int i=0; i<pts.get_size(); i++) {
      box.update(pts(i));
    }
    sum(&(center),box.min,box.max);
    product(&(center),center,0.5);
    // cout << center << endl;
    dim=center.get_size();
    cutpt=center;
    rotation.resize(iVector2d(dim,dim));
    identity_matrix(&(rotation));

    otheraxis=min(3,dim-1);
    cerr << "setup done\n";
    // init GLUT and create window
    glutInitDisplayMode(GLUT_DEPTH | GLUT_DOUBLE | GLUT_RGBA);
    glutInitWindowPosition(20,20);
    glutInitWindowSize(1000,1000);
    glutCreateWindow("ndviewer");

    glutIgnoreKeyRepeat(1);
    glutDisplayFunc(  &ViewerData::static_render_scene);
    glutIdleFunc(     &ViewerData::static_render_scene);
    glutReshapeFunc(  &ViewerData::static_change_size);
    glutKeyboardFunc( &ViewerData::static_process_normal_keys);
    glutSpecialFunc(  &ViewerData::static_press_key);
    glutSpecialUpFunc(&ViewerData::static_release_key);
    cerr << "glut init done\n";

  }

};

ViewerData *ViewerData::pcurrent_instance=NULL;

int main(int argc, char *argv[]) {
  /*
  {
    ifstream file("test.in");
    Array<Array<Real> > pts;
    Array<int> poly;
    file >> pts;
    LinkedList<Array<int> > polys;
    mesh_convex_planar(&polys,pts);
    cerr << polys;
  }
  exit(0);
  */
  char *infilename="mesh.nd";
  AskStruct options[]={
    {"","N-Dimensional VIEWER " MAPS_VERSION ", by Axel van de Walle",TITLEVAL,NULL},
    {"-if","Input table file",STRINGVAL,&infilename}
  };
  if (!get_values(argc,argv,countof(options),options)) {
    display_help(countof(options),options);
    return 1;
  }
  /*
  { //debug;
    Array<Array<Real> > pts;
    ifstream file("pt2.tmp");
    file >> pts;
    LinkedList<Array<int> > polys;
    create_mesh(&polys, pts,0,MAXFLOAT);
    cout << polys;
    return 1;
  }
  */
  /*  
  { //debug;
    Array<Array<Real> > pts;
    ifstream file("pt.in");
    file >> pts;
    Array<Array<Real> > pts3(3);
    pts3(0)=pts(0);
    pts3(1)=pts(1);
    pts3(2)=pts(3);
    Array<Real> center;
    Real radius2;
    calc_circumsphere(&center, &radius2,pts3);
    cout << center << endl;
    cout << radius2 << endl;
    LinkedList<Array<int> > polys;
    create_mesh(&polys, pts,0,MAXFLOAT);
    cout << polys;
    return 1;
  }
  */
  crash_if_singular=0;
  glutInit(&argc, argv);
  ViewerData viewerdata;
  viewerdata.init(infilename);
  cerr << "Starting main loop\n";
  glutMainLoop();

  /*
  Array<Real> cutpt;
  Array<Array<Real> > cutaxes;
  Array<Array<Real> > pts;
  LinkedList<Array<int> > polys;
  cin >> cutpt;
  cin >> cutaxes;
  cin >> pts;
  cin >> polys;
  Array<Array<Real> > cutpts;
  LinkedList<Array<int> > cutpolys;
  cross_section_simplexes(&cutpts,&cutpolys, cutaxes,cutpt,pts,polys);
  cout << cutpts << endl;
  cout << cutpolys << endl;
  return 1;
  */
  
  return 0;
}
