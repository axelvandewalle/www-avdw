#include "meshutil.h"

class LDrawMeshExporter: public MeshExporter {
  virtual void write(ostream &file, const Array<rVector3d> &pts, const LinkedList<Array<int> > &poly, const Array<Array<Real> > &ptsdata);
};

SpecificPlugIn<MeshExporter,LDrawMeshExporter> LDrawPlugIn("ldr");

void LDrawMeshExporter::write(ostream &file, const Array<rVector3d> &pts, const LinkedList<Array<int> > &poly, const Array<Array<Real> > &ptsdata) {
  if (pts.get_size()==0 || poly.get_size()==0) return;
  file << "0 // LDraw file" << endl;
  LinkedListIterator<Array<int> > t(poly);
  for (; t; t++) {
    file << t->get_size() << " 16" ;
    for (int i=0; i<t->get_size(); i++) {
      file << " " << pts((*t)(i));
    }
    file << endl;
  }
}
