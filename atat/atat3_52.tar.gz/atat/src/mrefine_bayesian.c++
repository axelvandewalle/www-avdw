#include <fstream.h>
#include <strstream.h>
#include <iostream>
#include "mrefine.h"
#include "getvalue.h"
#include "mpiinterf.h"
using namespace std;

class bayesian_ClusterExpansion: public ClusterExpansion {
 protected:
  Array<int> choice_test; // newly added test ECI number;
  Array<Real> width_independent; // newly added the later part in weight that doesn't depend on A,b
  Array<Real> width_dependent; //adjust section of the prior
  Array<Real> width_use; // newly added width matrix in 1D (contains W^(-1/2)) or 1/wa on diagonal
  Array<int> cluster_size; // newly added int matrix to store the size of all clusters
  Array<Real> parameter_fit; // newly added A,b needed to fit
  int minimal_structure; //minimal number of structure for cluster expansion
  int atom_type_number; //numer of type of atoms in lat.in file
  Real current_cluster_size; //radius of current biggest cluster;
  Real parameter_fixed;     // peroviskite parameter with default value of 4.0

 public:
  int parameter_k; //k parameter used for prior calculation
  int output_corr; //output corrlation file
  
  bayesian_ClusterExpansion(const Structure &_parent_lattice,
		      const Array<Arrayint> &_site_type_list,
		      const Array<AutoString> &_atom_label,
		      const SpaceGroup &_spacegroup, CorrFuncTable *_pcorrfunc);
  ~bayesian_ClusterExpansion(void);
  // uncomment if want to override and add function definitio below;
  // Add clusters to the cluster expansion
  void add_clusters(int number_of_structure);
  // generate random number
  Real random_num(void);
  Real random_num(double p,double q);
  // utility functions usd to compute CV score, ECI and variance
  Real calc_perfect_fit_cv(const Array2d<Real> &R, const Array<Real> &E, const Array<Real> &W);
  void calc_eci(Array<Real> *J, const Array<Real> &E, const Array2d<Real> &R, const Array<Real> &W);
  void calc_eci2(Array<Real> *J,const Array<Real> &E, const Array2d<Real> &R, const Array<Real> &Whalf);
  void compute_width_matrix(const Array<Real> &parameter);
  Real compute_width_matrix_edit(const Array<rVector3d> &c,const Array<Real> &parameter);
  Real compute_variance_bayesian(const Array2d<Real> &R,const Array<Real> sigma);
  Real compute_max_variance_reduction(const Array2d<Real> &R,const Array<Real> sigma);

  // the following 5 routines are overridden in derived class to enable new fitting algorithms;

  // Main routine calling the cluster enumeration and crossvalidation routines;
  // Initialize *pfitinfo with results (see class CEFitInfo above);
  void find_best_cluster_choice(CEFitInfo *pfitinfo);
  // Main routine calling the structure enumeration routines and the variance calculation codes.;
  // Return pointer to structure found (or NULL upon failure);
  StructureInfo * find_best_structure(void);
  // Finds the first few structures needed to initiate the refinement process.;
  // Return pointer to structure found (or NULL upon failure);
  StructureInfo * find_initial_structures(void);
  // Returns the least computationally intensive structure still marked as unknown.
  // Return pointer to structure (never NULL);
  StructureInfo * find_first_unknown_structure(void);
  void parse_extension_parameter(const char *extension_parameter);
  // Return pointer to structure (always NULL as this function is skipped);
};

// register plug-in name;
SpecificPlugIn<ClusterExpansionCreator, CustomClusterExpansionCreator<bayesian_ClusterExpansion> > Bayesian_ClusterExpansionPlugIn("bayesian");

bayesian_ClusterExpansion::bayesian_ClusterExpansion(const Structure &_parent_lattice,
  const Array<Arrayint> &_site_type_list,
  const Array<AutoString> &_atom_label,
  const SpaceGroup &_spacegroup, CorrFuncTable *_pcorrfunc):ClusterExpansion(_parent_lattice,_site_type_list,_atom_label,_spacegroup,_pcorrfunc){
     cerr << "using bayesian cluster expansion algorithm" << endl;
     cerr << "initialize clusters" << endl;
     pcorrfunc=_pcorrfunc;
     max_multiplet=4;
     parameter_fixed=4.0;
     complexity_exp=3.;
     high_energy=MAXFLOAT;
     predictor_labels="";
     ignore_gs=0;
     parameter_k=2;
     atom_type_number=atom_label.get_size();
     minimal_structure=5+5*atom_type_number*(atom_type_number+1)/2; 
     int number_of_correlation=100+50*atom_type_number*(atom_type_number-1)/2;   //more atom types->more ECIs
     //output_corr=1;
     user_max_vol=10;//largest cell possible;     
     // initialize lattice_only;
     int nbsite=0;
     for (nbsite=0; nbsite<parent_lattice.atom_pos.get_size(); nbsite++) {
       if (site_type_list(parent_lattice.atom_type(nbsite)).get_size()==1) break;
     }
     lattice_only.cell=parent_lattice.cell;
     lattice_only.atom_pos.resize(nbsite);
     lattice_only.atom_type.resize(nbsite);
     for (int i=0; i<lattice_only.atom_pos.get_size(); i++) {
       lattice_only.atom_pos(i) =parent_lattice.atom_pos(i);
       lattice_only.atom_type(i)=site_type_list(parent_lattice.atom_type(i)).get_size();
     }
     
     int max_multi=0;
     for (int i=0; i<site_type_list.get_size(); i++) {
       max_multi=MAX(max_multi,site_type_list(i).get_size());
     }
     pcorrfunc->init(max_multi);

     pclusters.resize(max_multiplet);
     // initialize point clusters;
     pclusters(0)=new MultiClusterBank(lattice_only,1,spacegroup);
     int npoint=pclusters(0)->get_cluster_list().get_size();
     choice_test.resize(max_multiplet+2);
     choice_test(0)=npoint;
     for (int i=0; i<npoint; i++) {
       (*pclusters(0))++;
     }
     // initialize clusters;
     radius_1nn=find_1nn_radius(lattice_only)+zero_tolerance;
     for(int i=1;i<max_multiplet;i++){
       pclusters(i)=new MultiClusterBank(lattice_only,i+1,spacegroup);
     }
     int nb_include=npoint+1;
     int step_number=0;
     double step_size=0.1;
     while (nb_include<number_of_correlation){
       for (int size=1;size<max_multiplet;size++){
         while(pclusters(size)->get_current_length()<radius_1nn*(1+step_number*step_size)*(0.25+1/(size+1))){
           current_cluster_size=pclusters(size)->get_current_length();
           (*pclusters(size))++;
           nb_include++;
         }
         if (nb_include>=number_of_correlation) break;
       }
       step_number++;
     }
     for (int size=1;size<max_multiplet;size++){
       choice_test(size)=pclusters(size)->get_current_index();
     }
     for (int size=max_multiplet;size<max_multiplet+2;size++){
       choice_test(size)=1;        //add the smallest large cluster to the fit
     }
     //cerr << choice_test << endl;

     printf("number of cluster used is %d\n",nb_include+2);
     nb_clusters=nb_include+2;

     equiv_cluster.resize(max_multiplet);
     //equiv_cluster.resize(max_multiplet);
     for (int i=0; i<pclusters.get_size(); i++) {
       equiv_cluster(i)=new LinkedList<Array<MultiCluster> >;
       LinkedListIterator<MultiCluster> c(pclusters(i)->get_cluster_list());
       for ( ; c; c++) {
         Array<MultiCluster> *parraycluster=new Array<MultiCluster>;
         find_equivalent_clusters(parraycluster,*c,spacegroup.cell,spacegroup.point_op,spacegroup.trans);
         (*equiv_cluster(i)) << parraycluster;
       }
     }

  reset_cluster_choice();
  set_cluster_choice(choice_test);
  Array2d<Real> un_corr,raw_un_corr;
     
  calc_regression_matrices(&raw_un_corr,NULL, StructureInfo::anystatus);

  calc_corr_to_conc(&corr_to_fullconc,parent_lattice,site_type_list,spacegroup,*pcorrfunc);
  extract_nonredundant(&corr_to_conc,&conc_to_fullconc,&conc_to_fullconc_c, corr_to_fullconc);

  down_e.resize(corr_to_conc.get_size()(0)+1);
  zero_array(&down_e);
  down_e(down_e.get_size()-1)=-1.;

  update_correlations(StructureInfo::anystatus);
  calc_regression_matrices(&raw_un_corr,NULL, StructureInfo::anystatus);

}

void bayesian_ClusterExpansion::add_clusters(int number_of_structure){
  int npoint=pclusters(0)->get_cluster_list().get_size();
  for(int i=1;i<max_multiplet;i++){
    pclusters(i)=new MultiClusterBank(lattice_only,i+1,spacegroup);
  }
  int nb_include=npoint+1;
  int number_of_correlation=number_of_structure+20;
  int step_number=0;
  double step_size=0.1;
  int add=0;
  while(!add){
  while (nb_include<number_of_correlation){
    for (int size=1;size<max_multiplet;size++){
      while(pclusters(size)->get_current_length()<radius_1nn*(1+step_number*step_size)*(0.25+1/(size+1))){
        current_cluster_size=pclusters(size)->get_current_length();
        (*pclusters(size))++;
        nb_include++;
      }
        if (nb_include>=number_of_correlation) break;
      }
      step_number++;
    }
    if(nb_include>nb_clusters){
      add=1;
    }
    else{
      number_of_correlation=number_of_correlation+20;
      }
    }
    for (int size=1;size<max_multiplet;size++){
      choice_test(size)=pclusters(size)->get_current_index();
    }
    cerr << choice_test << endl;

    printf("number of cluster used is %d\n",nb_include);
    nb_clusters=nb_include;

    equiv_cluster.resize(max_multiplet);
    for (int i=0; i<pclusters.get_size(); i++) {
      equiv_cluster(i)=new LinkedList<Array<MultiCluster> >;
      LinkedListIterator<MultiCluster> c(pclusters(i)->get_cluster_list());
      for ( ; c; c++) {
        Array<MultiCluster> *parraycluster=new Array<MultiCluster>;
        find_equivalent_clusters(parraycluster,*c,spacegroup.cell,spacegroup.point_op,spacegroup.trans);
        (*equiv_cluster(i)) << parraycluster;
      }
    }
    
  reset_cluster_choice();
  set_cluster_choice(choice_test);
}

void bayesian_ClusterExpansion::compute_width_matrix(const Array<Real> &parameter){
  //Compute the width matrix part that doesn't depend on A,b
  width_use.resize(nb_clusters);
  int count=1;
  width_use(0)=1.0;
  for (int i=0;i<pclusters.get_size();i++){
    pclusters(i)->reset();
    while (pclusters(i)->get_current_index()<choice_test(i)){
      width_use(count)=compute_width_matrix_edit(((*pclusters(i))->clus),parameter);
      count++;
      (*pclusters(i))++;
    }
  }
}

//flexable function used to compute prior
Real bayesian_ClusterExpansion::compute_width_matrix_edit(const Array<rVector3d> &c,const Array<Real> &parameter){
  double result=1.0;
  int size=c.get_size();
  //version 1
  for (int i=0; i<size; i++) {
    for (int j=i+1; j<size; j++) {
      Real r=norm(c(i)-c(j));
      if (r+parameter(2)>parameter(1)){
        result=result*pow((parameter(1)/(r+parameter(2))),parameter_k);
      }
    }
  }
  result=result*pow(parameter(0),size); 
  return result;
}

int check_converge(Array2d<Real> parameterbank,int size_of_simplex,int number_of_parameters){
  Array<Real> average(number_of_parameters);
  double standard_dev=0.0;
  double cv_dev=0.0;
  double cv_average=0.0;
  zero_array(&average);
  cerr << "check converge" << endl;
  for (int i=0;i<size_of_simplex;i++) cv_average+=parameterbank(i,number_of_parameters)/number_of_parameters;
  for (int i=0;i<size_of_simplex;i++) cv_dev+=pow((parameterbank(i,number_of_parameters)-cv_average),2)/number_of_parameters;
  for (int i=0;i<number_of_parameters;i++){
    for (int j=0;j<size_of_simplex;j++){
      average(i)+=parameterbank(j,i)/size_of_simplex;
    }
  }
  for (int i=0;i<number_of_parameters;i++){
    for (int j=0;j<size_of_simplex;j++){
      standard_dev+=pow(parameterbank(j,i)-average(i),2)/(size_of_simplex*number_of_parameters);
    }
  }
  if (sqrt(standard_dev)<0.03 && sqrt(cv_dev)<0.01){
    cerr << "precision is reached" << endl;
    return 0;    //exit loop
  }
  else{
    return 1;
  }
}

// uncomment if needed. You may copy in the code from the corresponding function in mrefine.c++ as a startiung point;
void bayesian_ClusterExpansion::find_best_cluster_choice(CEFitInfo *pfitinfo) {
  Array2d<Real> corr_matrix,corr_matrix2;
  Array<Real> energy,formation_energy,formation_energy_diff,predictor_energy,dependent_list;
  Array<Array<Real> > concentration;
  Real volume=(Real)(lattice_only.atom_pos.get_size());
  /*output_corr=1;        //this section is just for testing
  if (output_corr){
    ofstream corrfile("corrfile");
    calc_regression_matrices(&corr_matrix2,NULL,StructureInfo::anystatus);
    for (int i=0;i<corr_matrix2.get_size()(0);i++){
      for (int j=0;j<corr_matrix2.get_size()(1);j++){
        corrfile << corr_matrix2(i,j) << " ";
      }
      corrfile << " " << endl;
    }
    cerr << "finish output correlation" << endl;
  }*/
  init_predictors();
  calc_regression_matrices(&corr_matrix,&energy,StructureInfo::calculated);
  if (energy.get_size()==0) return;
  //The following section is only used for double cross validation
  if (corr_matrix.get_size()(0)>=corr_matrix.get_size()(1)){
    add_clusters(corr_matrix.get_size()(0));
    calc_regression_matrices(&corr_matrix,&energy,StructureInfo::calculated);
  }  

  pfitinfo->pstr.resize(energy.get_size());
  LinkedListIterator<StructureInfo> s(structures.get_structure_list());
  for (int j=0; j<pfitinfo->pstr.get_size(); s++) {
    if (s->status==StructureInfo::calculated) {
        pfitinfo->pstr(j)=s;
        j++;
      }
    }
  //Remove linear dependence once a time until all linear dependence are removed
  if (rank_matrix(corr_matrix)<corr_matrix.get_size()(0)){
    cerr << "linear dependence detected" << endl;
    detect_linear_dependence(&dependent_list,corr_matrix);
    cerr << "finish detection" << endl;
    LinkedList<PolytopeFace> hull;
    Array<Array<Real> > conc_e;
    calc_concentration(&concentration,corr_matrix);
    paste_col_vector(&conc_e,concentration,energy);
    calc_convex_hull(&hull, conc_e, down_e);
    clip_hull(&hull,conc_e,conc_range);
    update_normals(&hull,conc_e);
    //cerr << dependent_list << endl;
    LinkedList<int> true_gs;
    LinkedListIterator<PolytopeFace> i_face(hull);
    for (; i_face; i_face++) {
      for (int i=0; i<i_face->pts.get_size(); i++) {
        add_unique(&true_gs,i_face->pts(i),TrivEqual<int>());
      }
    }
    LinkedList_to_Array(&(pfitinfo->gs_list),true_gs);
    cerr << pfitinfo->gs_list.get_size() << endl;
    for (int i=corr_matrix.get_size()(0)-1;i>-1;i--){
      int isgroundstate=0;
      for (int j=0; j<pfitinfo->gs_list.get_size(); j++){
        int gs=pfitinfo->gs_list(j);
        //cerr << gs << endl;
        if(dependent_list(i)==1 && i==gs){     //the line is linearly dependent and not in ground state list
          isgroundstate=1;
        }
      }
      if(!isgroundstate && dependent_list(i)==1){         //the line is linearly dependent and not in ground state list
        //label the structure as error
        
        chdir(pfitinfo->pstr(i)->label);
        //remove("energy");
        ofstream errorfile("error");            //flag the new structure as error
        errorfile << "structure is linearly dependent with other structures" << endl;
        cerr << " remove structure " << pfitinfo->pstr(i)->label << " end loop" << endl;
        chdir("..");
        return;
      }
    }
    ERRORQUIT("All linearly dependent structures are ground states");
  }

  calc_concentration(&concentration,corr_matrix);
  printf("\nthe number of reference is %d ",energy.get_size());
  
  //add here energy line
           
    pfitinfo->pure_energy.resize(0);
    if (MyMPIobj.is_root()) {
      ifstream pure_file("ref_energy.in");
      if (pure_file) {
        pfitinfo->pure_energy.resize(atom_label.get_size());
        for (int i=0; i<atom_label.get_size(); i++) {
          pure_file >> pfitinfo->pure_energy(i);
          pfitinfo->pure_energy(i)*=volume;
        }
      }
      else{
        int finished=1;
        reset_structure();
        for (int i=0; i<atom_label.get_size(); i++){
          if (structures.get_current_structure().status != StructureInfo::calculated){
            finished=0;
            cerr << "ERROR! not all pure element structures are calculated" << endl;
            return;
          }
          find_next_structure();
        }
        if (finished){
          cerr << "write ref_energy.in file" << endl;
          ofstream pure_file2("ref_energy.in");
          pfitinfo->pure_energy.resize(atom_label.get_size());
          for (int i=0; i<atom_label.get_size(); i++) {
            pure_file2 << energy(i) << endl;
            pfitinfo->pure_energy(i)=energy(i)/volume;
          }
        }
      }
    }
    reset_structure();
    MyMPI_BcastStream(&(pfitinfo->pure_energy));
    // consider formation energies;
    Array<Array<Real> > full_conc(concentration.get_size());
    for (int i=0; i<concentration.get_size(); i++) {
      product(&(full_conc(i)),conc_to_fullconc,concentration(i));
      sum(&(full_conc(i)),full_conc(i),conc_to_fullconc_c);
    }
    calc_formation(&energy,&(pfitinfo->pure_energy),full_conc,energy);
    calc_predictor_energy(&predictor_energy);
    diff(&energy,energy,predictor_energy);
  
  if (energy.get_size()>-1){ 
    printf("the number of correlation is %d\n",corr_matrix.get_size()(1));
    //The following section is only used for double cross validation
    if (output_corr){
      ofstream energyfile("energyfile");
      for (int i=0;i<corr_matrix.get_size()(0);i++){
      energyfile << energy(i) << endl;
      }
    }
  }
  // ECI fitting section
  Array2d<Real> parameterbank;       //stores parameter, cv score and rank
  Array<Real> centeroid;
  Array<Real> cvbank;
  int size_of_simplex=3;
  int number_of_parameters=3;
  parameterbank.resize(size_of_simplex,number_of_parameters+2);
  parameter_fit.resize(number_of_parameters);
  centeroid.resize(number_of_parameters);
  int maxstep=10;
  int cv_best_position=0;
  int cv_worst_position=1;
  int second_worst_position=2;
  double cv_best,cv_secondworst,cv_worst;
  int converge=1;
  int count=0;
  Array2d<Real> parameter_range;
  parameter_range.resize(number_of_parameters,2);
  //temperory range
  parameter_range(0,0)=0.0;
  parameter_range(0,1)=1.0;
  parameter_range(1,0)=2.5;
  parameter_range(1,1)=6.0;
  parameter_range(2,0)=-1.0;
  parameter_range(2,1)=1.0;
  cerr << "start generating simplex" << endl;
  for (int i=0;i<size_of_simplex;i++){
    for (int j=0;j<number_of_parameters;j++){
      parameterbank(i,j)=random_num(parameter_range(j,0),parameter_range(j,1));
    }
    parameterbank(0,0)=0.512535;
    parameterbank(0,1)=4.83703;
    parameterbank(0,2)=0.0632129;
    Array<Real> parameter_use;
    parameter_use.resize(number_of_parameters);
    for (int j=0;j<number_of_parameters;j++){
      parameter_use(j)=parameterbank(i,j);
    }
    compute_width_matrix(parameter_use);
    parameterbank(i,number_of_parameters)=calc_perfect_fit_cv(corr_matrix,energy,width_use);
  }
  cerr << "start optimizing loop" << endl;
  while(converge & count<maxstep){
    //rank simplex first
    for (int i=0;i<size_of_simplex;i++){
      parameterbank(i,number_of_parameters+1)=0;
      for (int j=0;j<size_of_simplex;j++){
        if (parameterbank(i,number_of_parameters)>=parameterbank(j,number_of_parameters)){
          parameterbank(i,number_of_parameters+1)++;
        }
      }
      if (parameterbank(i,number_of_parameters+1)==1){
        cv_best=parameterbank(i,number_of_parameters);
        cv_best_position=i;
      }
      else if(parameterbank(i,number_of_parameters+1)==size_of_simplex-1){
        cv_secondworst=parameterbank(i,number_of_parameters);
      }
      else if(parameterbank(i,number_of_parameters+1)==size_of_simplex){
        cv_worst=parameterbank(i,number_of_parameters);
        cv_worst_position=i;
      }
    }
    Array<Real> centeroid;
    centeroid.resize(number_of_parameters);
    for (int j=0;j<number_of_parameters;j++){
      centeroid(j)=0;
      for (int i=0;i<size_of_simplex;i++){
        centeroid(j)+=parameterbank(i,j)/size_of_simplex;
      }
      centeroid(j)-=parameterbank(cv_worst_position,j)/size_of_simplex;
    }
    //Reflection
    cerr << "Reflection" << endl;
    Array<Real> parameter_reflection;
    parameter_reflection.resize(number_of_parameters);
    for(int i=0;i<number_of_parameters;i++){
      parameter_reflection(i)=centeroid(i)+1.0*(centeroid(i)-parameterbank(cv_worst_position,i));  //parameter alpha=1.0
      if (parameter_reflection(i)<=parameter_range(i,0)){
        parameter_reflection(i)=parameter_range(i,0)+0.01*random_num();
      }
      if (parameter_reflection(i)>=parameter_range(i,1)){
        parameter_reflection(i)=parameter_range(i,1)-0.01*random_num();
      }
    }
    compute_width_matrix(parameter_reflection);
    double cv_reflection=calc_perfect_fit_cv(corr_matrix,energy,width_use);
    if (cv_reflection>cv_best && cv_reflection<cv_secondworst){
      for (int i=0;i<number_of_parameters;i++){
        parameterbank(cv_worst_position,i)=parameter_reflection(i);
      }
      parameterbank(cv_worst_position,number_of_parameters)=cv_reflection;
    }
    //Expansion
    else if (cv_reflection<=cv_best){
      cerr << "expansion" << endl;
      Array<Real> parameter_expansion;
      parameter_expansion.resize(number_of_parameters);
      for(int i=0;i<number_of_parameters;i++){
        parameter_expansion(i)=centeroid(i)+2.0*(parameter_reflection(i)-centeroid(i));
        if (parameter_expansion(i)<=parameter_range(i,0)){
          parameter_expansion(i)=parameter_range(i,0)+0.01*random_num();
        }
        if (parameter_expansion(i)>=parameter_range(i,1)){
          parameter_expansion(i)=parameter_range(i,1)-0.01*random_num();
        }
      }
      compute_width_matrix(parameter_expansion);
      double cv_expansion=calc_perfect_fit_cv(corr_matrix,energy,width_use);
      if (cv_expansion<cv_reflection){
        for (int i=0;i<number_of_parameters;i++){
          parameterbank(cv_worst_position,i)=parameter_expansion(i);
      }
        parameterbank(cv_worst_position,number_of_parameters)=cv_expansion;
      }
      else {
        for (int i=0;i<number_of_parameters;i++){
          parameterbank(cv_worst_position,i)=parameter_reflection(i);
      }
        parameterbank(cv_worst_position,number_of_parameters)=cv_reflection;
      }
    }
    //Contraction
    else{
      cerr << "contraction" << endl;
      Array<Real> parameter_contraction;
      parameter_contraction.resize(number_of_parameters);
      for(int i=0;i<number_of_parameters;i++){
        parameter_contraction(i)=centeroid(i)+0.5*(parameterbank(cv_worst_position,i)-centeroid(i));
        if (parameter_contraction(i)<=parameter_range(i,0)){
          parameter_contraction(i)=parameter_range(i,0)+0.01*random_num();
        }
        if (parameter_contraction(i)>=parameter_range(i,1)){
          parameter_contraction(i)=parameter_range(i,1)-0.01*random_num();
        }
      }
      compute_width_matrix(parameter_contraction);
      double cv_contraction=calc_perfect_fit_cv(corr_matrix,energy,width_use);
      if(cv_contraction<cv_worst){
        for (int i=0;i<number_of_parameters;i++){
          parameterbank(cv_worst_position,i)=parameter_contraction(i);
      }
        parameterbank(cv_worst_position,number_of_parameters)=cv_contraction;
      }
      //Shrink
      else{
        cerr << "shrink" << endl;
        for (int i=0;i<size_of_simplex;i++){
          Array<Real> parameter_update;
          parameter_update.resize(number_of_parameters);
          for (int j=0;j<number_of_parameters;j++){
            parameter_update(j)=0.5*(parameterbank(i,j)+parameterbank(cv_best_position,j));
            parameterbank(i,j)=parameter_update(j);
          }
          compute_width_matrix(parameter_update);
          parameterbank(i,number_of_parameters)=calc_perfect_fit_cv(corr_matrix,energy,width_use);
        }
      }
    }
    printf("at step %d cv score for simplex are ",count);
    for (int i=0;i<size_of_simplex;i++){
      printf("%f  ",parameterbank(i,number_of_parameters));
    }
    printf("\ncorresponding parameters are \n");
    for (int i=0;i<size_of_simplex;i++){
      for (int j=0;j<number_of_parameters;j++){
        printf("%8f  ",parameterbank(i,j));   
      }
    }
    printf("\n");
    converge=check_converge(parameterbank,size_of_simplex,number_of_parameters); 
    count++;
  }
  cv_best_position=0;
  Real best_cv=MAXFLOAT;
  for (int i=0;i<size_of_simplex;i++){
    if (parameterbank(i,number_of_parameters)<best_cv){
      cv_best_position=i;
      best_cv=parameterbank(i,number_of_parameters);
    }
  }
  for (int i=0;i<number_of_parameters;i++){
    parameter_fit(i)=parameterbank(cv_best_position,i);
  }
  pfitinfo->cv=parameterbank(cv_best_position,number_of_parameters);
  printf("the final parameter is %f %f %f test\n",parameter_fit(0),parameter_fit(1),parameter_fit(2));
  compute_width_matrix(parameter_fit);
  Array<Real> W;
  W.resize(nb_clusters);
  ofstream wfile("wfile");
  for (int i=0;i<nb_clusters;i++){
    W(i)=pow(width_use(i),1);
    wfile << W(i) << endl;
  }
  if(energy.get_size()>0){
    calc_eci2(&(pfitinfo->eci),energy,corr_matrix,W);        //compute the ECI using simplified version (basicallly same)
  }
  else{
    printf("skip eci\n");
    pfitinfo->eci.resize(nb_clusters);
    for(int i=0;i<nb_clusters;i++){
      pfitinfo->eci(i)=0;
    }
  }
  //output section, hull first
  { 
    Array<Real>weight;
    weight.resize(concentration.get_size());
    one_array(&weight);
    pfitinfo->weight=weight;
    sum(&(pfitinfo->energy), energy,predictor_energy);
    product(&(pfitinfo->fitted_energy),corr_matrix,pfitinfo->eci);
    sum(&(pfitinfo->fitted_energy), pfitinfo->fitted_energy,predictor_energy);
    pfitinfo->pstr.resize(energy.get_size());
    LinkedListIterator<StructureInfo> s(structures.get_structure_list());
    for (int i=0; i<pfitinfo->pstr.get_size(); s++) {
      if (s->status==StructureInfo::calculated) {
        pfitinfo->pstr(i)=s;
        i++;
      }
    }
    reset_structure();
     
    pfitinfo->concentration=full_conc;
    LinkedList<PolytopeFace> hull;
    Array<Array<Real> > conc_e;
    paste_col_vector(&conc_e,concentration,energy);
    if (!ignore_gs) {
      calc_convex_hull(&hull, conc_e, down_e);
      }
    clip_hull(&hull,conc_e,conc_range);
    update_normals(&hull,conc_e);

    Array2d<Real> all_corr;
    Array<Real> all_fitted_energy;
    Array<Real> all_predictor_energy;
    
    calc_regression_matrices(&all_corr,NULL, (StructureInfo::Status) (StructureInfo::unknown | StructureInfo::busy | StructureInfo::error));
    calc_predictor_energy(&all_predictor_energy, (StructureInfo::Status) (StructureInfo::unknown | StructureInfo::busy | StructureInfo::error));
    product(&all_fitted_energy, all_corr,pfitinfo->eci);
    sum(&all_fitted_energy, all_fitted_energy,all_predictor_energy);
    product(&all_fitted_energy, all_fitted_energy,1./volume);
    // find concentration of all generated structures;
    Array<Array<Real> > all_concentration;
    Array<Array<Real> > all_conc_e;
    calc_concentration(&all_concentration,all_corr);
    paste_col_vector(&all_conc_e,all_concentration,all_fitted_energy);
    // check for structures breaking the hull;
    Array<int> problem;
    if (flag_outside_hull(&problem, &hull, all_conc_e,0)) {
      pfitinfo->status = (CEFitInfo::Status)(pfitinfo->status | CEFitInfo::new_gs);
    }
    
    LinkedList<int> true_gs;
    LinkedListIterator<PolytopeFace> i_face(hull);
    for (; i_face; i_face++) {
      for (int i=0; i<i_face->pts.get_size(); i++) {
        add_unique(&true_gs,i_face->pts(i),TrivEqual<int>());
      }
    }
    LinkedList_to_Array(&(pfitinfo->gs_list),true_gs);
    transfer_list(&(pfitinfo->hull),&hull);
    pfitinfo->corr_to_fullconc=corr_to_fullconc;
    pfitinfo->conc_to_fullconc=conc_to_fullconc;
    pfitinfo->conc_to_fullconc_c=conc_to_fullconc_c;
    pfitinfo->corr_to_conc=corr_to_conc;
    if (MyMPIobj.is_root()) {
      LinkedListIterator<StructureInfo> s(structures.get_structure_list());
      ofstream allstr("predstr.out");
	    allstr.setf(ios::fixed);
	    allstr.precision(6);
      for (int i=0; i<all_fitted_energy.get_size(); i++) {
	      while (!(s->status & (StructureInfo::Status) (StructureInfo::unknown | StructureInfo::busy | StructureInfo::error))) {s++;}
	      const char *slabel=s->label;
        Array<Real> cur_conc;
        product(&cur_conc,conc_to_fullconc,all_concentration(i));
        sum(&cur_conc,cur_conc,conc_to_fullconc_c);
        for (int j=0; j<cur_conc.get_size(); j++) {
            allstr << cur_conc(j) << " ";
        }
        allstr << all_fitted_energy(i) << " " 
		 << (s->status & StructureInfo::unknown ? "?" : slabel) << " " 
		 << (s->status & StructureInfo::busy    ? "b" : "") 
		 << (s->status & StructureInfo::error   ? "e" : "") 
		 << (s->status & StructureInfo::unknown ? "u" : "") 
		 << (problem(i) ? "g" : "") 
		 << endl;
          s++;
      }
    }
  }

  if (parameterbank(cv_best_position,number_of_parameters)>=0){
    pfitinfo->cluster.resize(nb_clusters);
    pfitinfo->multiplicity.resize(nb_clusters);
    pfitinfo->multiplicity(0)=1.;
    pfitinfo->cluster(0)=MultiCluster(0);
    int c=1;
    for (int m=0; m<choice_test.get_size(); m++) {
      pclusters(m)->reset();
      for (int i=0; i<choice_test(m); i++, (*pclusters(m))++, c++) {
        pfitinfo->cluster(c)=(*pclusters(m));
        pfitinfo->multiplicity(c)=(Real)calc_multiplicity(pfitinfo->cluster(c),parent_lattice.cell,spacegroup.point_op,spacegroup.trans);
        if(energy.get_size()>0){
          pfitinfo->eci(c)/=pfitinfo->multiplicity(c);
        }
      }
    }
    ofstream cvfile("cvscore.out",ios::app);
    cvfile << "cv score is " << best_cv <<  endl;
    cvfile << "parameters are ";
    for(int i=0;i<number_of_parameters;i++){
      cvfile << parameter_fit(i) << " ";
    }
    cvfile << endl;
  }
}

// uncomment if needed. You may copy in the code from the corresponding function in mrefine.c++ as a startiung point;
StructureInfo * bayesian_ClusterExpansion::find_best_structure(void) {
  Array2d<Real> Rold,R;
  Array<Real> E,sigma,Rline;
  double variance_old,variance_new,variation_red,max_possible_red;
  StructureInfo *p_best_str=NULL;
  calc_regression_matrices(&Rold,&E);
  int n=Rold.get_size()(1);
  int k=Rold.get_size()(0);
  if(k<minimal_structure) return NULL;
  cerr << "find best structure using variation reduction method" << endl;
  R.resize(k+1,n);
  compute_width_matrix(parameter_fit);
  sigma.resize(n);
  for(int i=0;i<n;i++){    
    sigma(i)=pow(width_use(i),2);
  } //sigma matrix is the same for every structure choice
  variance_old=compute_variance_bayesian(Rold,sigma);
  max_possible_red=compute_max_variance_reduction(Rold,sigma);   //compute the max possible variance reduction from eigenvalue
  //loop through all structures
  double variation_min=MAXFLOAT;
  Array<Real> eci;
  calc_eci(&eci,E,Rold,sigma);      //W and sigma are same matrix
  // find ground state line;
  Array<Array<Real> > concentration;
  calc_concentration(&concentration,Rold);    
  LinkedList<PolytopeFace> hull;
  Array<Array<Real> > conc_e;
  paste_col_vector(&conc_e,concentration,E);
  calc_convex_hull(&hull, conc_e, down_e);
  clip_hull(&hull,conc_e,conc_range);
  update_normals(&hull,conc_e);

  Array2d<Real> un_corr,raw_un_corr;
  Array<Real> un_fitted_energy;
  Array<Real> un_predictor_energy;
  calc_regression_matrices(&raw_un_corr,NULL, StructureInfo::unknown);
  calc_predictor_energy(&un_predictor_energy, StructureInfo::unknown);
  product(&un_fitted_energy, raw_un_corr,eci);
  
  Array<Array<Real> > un_concentration;
  calc_concentration(&un_concentration,raw_un_corr);
  Array<Array<Real> > un_conc_e;
  paste_col_vector(&un_conc_e,un_concentration,un_fitted_energy);
  Array<int> problem; 
  int best_structure_index=0;
  //search structures among possible ground states
  if (!ignore_gs && flag_outside_hull(&problem, &hull, un_conc_e,0)){
    cerr << "searching among ground states" << endl;
    LinkedList<PolytopeFace> new_gs;
    Array<Array<Real> > new_gs_conc_e;
    paste_col_vector(&new_gs_conc_e,un_concentration,un_fitted_energy);
    calc_convex_hull(&new_gs, new_gs_conc_e, down_e);
    clip_hull(&new_gs,new_gs_conc_e,conc_range);
    LinkedListIterator<PolytopeFace> i_new_gs(new_gs);
    int count=0;
    for (; i_new_gs; i_new_gs++) {
      for (int i=0; i<i_new_gs->pts.get_size(); i++) {
        problem(i_new_gs->pts(i))|=2; // structures that break the hull and are potential new ground states will be labelled 3;
        count++;
      }
    }
    printf("possible ground state size is %d\n",count);
    for (int istr=0; istr<problem.get_size(); istr++) {
      while (structures.get_current_structure().status != StructureInfo::unknown) {find_next_structure();}
      if (problem(istr)==3){
        if (variation_min<(max_possible_red)/structures.get_current_structure().cost){
          cerr << "variation reduction maximum reached" << endl;
          break;
        }
        make_correlation_array(&Rline,structures.get_current_structure().correlations);
        for (int i=0;i<k;i++){
          for (int j=0;j<n;j++){
            R(i,j)=Rold(i,j);
          }
        }
        for (int j=0;j<n;j++){
          R(k,j)=Rline(j);
        }
        if (rank_matrix(R)<R.get_size()(0)){
          variation_red=MAXFLOAT;
        }
        else{
          variance_new=compute_variance_bayesian(R,sigma);
          variation_red=(variance_new-variance_old)/structures.get_current_structure().cost;
        }
        if (variation_red<variation_min){
          variation_min=variation_red;
          p_best_str=&structures.get_current_structure();
          best_structure_index=structures.get_current_index();
        }
      }
      find_next_structure();
    }
  }
  else{
    cerr << "searching among all structures" << endl;
    while(1){
      if (structures.get_current_structure().status==StructureInfo::unknown) {
        if (variation_min<(max_possible_red)/structures.get_current_structure().cost){
          cerr << "variation reduction maximum reached" << endl;
          break;
        }
        make_correlation_array(&Rline,structures.get_current_structure().correlations);
        for (int i=0;i<k;i++){
          for (int j=0;j<n;j++){
            R(i,j)=Rold(i,j);
          }
        }
        for (int j=0;j<n;j++){
          R(k,j)=Rline(j);
        }
        if (rank_matrix(R)<R.get_size()(0)){
          variation_red=MAXFLOAT;
        }
        else{
          variance_new=compute_variance_bayesian(R,sigma);
          variation_red=(variance_new-variance_old)/structures.get_current_structure().cost;
        }
        if (variation_red<variation_min){
          variation_min=variation_red;
          p_best_str=&structures.get_current_structure();
          best_structure_index=structures.get_current_index();
        }
      }
      find_next_structure();
    }
  }
  cerr << "structure added is " << p_best_str->label << endl;
  cerr << "variation reduction method finished" << endl;
  return p_best_str;
}

StructureInfo * bayesian_ClusterExpansion::find_initial_structures(void) {
  //find a few smallest structures to start cluster expansion (never return NULL)
  cerr << "add a smallest structure" << endl;
  update_correlations(StructureInfo::anystatus);
  LinkedListIterator<StructureInfo> i(structures.get_structure_list());
  Array<ArrayReal> basis;
  int nb_in_basis=0;
  for (;i; i++) {
    if (i->status & (StructureInfo::calculated | StructureInfo::busy)) {
      Array<Real> cur_corr;
      make_correlation_array(&cur_corr,i->correlations);
      build_basis(&basis,&nb_in_basis,cur_corr);
    }
  }
  // loop through unknown structures in search of a non-coplanar correlation;
  reset_structure();
  while (1) {
    if (structures.get_current_structure().status==StructureInfo::unknown) {
      Array<Real> cur_corr;
      make_correlation_array(&cur_corr,structures.get_current_structure().correlations);
      Array<Real> c;
      calc_concentration(&c,cur_corr);
      if (is_point_in_hull(c,conc_range)) {
        if (build_basis(&basis,&nb_in_basis,cur_corr)) break;
      }
    }
    //break;
    //}
    find_next_structure();
  }
  Array <Real> Rline;
  make_correlation_array(&Rline,structures.get_current_structure().correlations);
  return &(structures.get_current_structure());
}

Real bayesian_ClusterExpansion::random_num(void){
  Real r;
  r=rand()/2147483647.0;
  return r;
}

Real bayesian_ClusterExpansion::random_num(double p,double q){
  Real r;
  if (p>q){
    r=q+random_num()*(p-q);
  }
  else{
    r=p+random_num()*(q-p);
  }
  return r;
}

StructureInfo * bayesian_ClusterExpansion::find_first_unknown_structure(void) {
  return NULL; //This function will return NULL as it will not be used in bayesian routine
}

Real bayesian_ClusterExpansion::compute_variance_bayesian(const Array2d<Real> &R,const Array<Real> sigma){
  Array2d<Real> P,RT,RRT,RRT1,RRR,RRRR,Psigma,PsigmaP,PT;
  int n;
  transpose_matrix(&RT,R);
  product(&RRT,R,RT);
  invert_matrix(&RRT1,RRT);
  product(&RRR,RT,RRT1);
  product(&RRRR,RRR,R);
  n=R.get_size()(1);
  P.resize(n,n);
  for(int i=0;i<n;i++){
    for(int j=0;j<n;j++){
      if(i==j){
        P(i,j)=1.0-RRRR(i,j);
      }
      else{
        P(i,j)=-RRRR(i,j);
      }
    }
  }
  transpose_matrix(&PT,P);
  product_diag(&Psigma,P,sigma);
  product(&PsigmaP,Psigma,PT);
  double variance=trace(PsigmaP);
  return variance;
}

Real bayesian_ClusterExpansion::compute_max_variance_reduction(const Array2d<Real> &R,const Array<Real> sigma){
  double maxeigen=0;
  Array2d<Real> P,RT,RRT,RRT1,RRR,RRRR,Psigma,PsigmaP,PT;
  Array<Real> D;
  int n;
  transpose_matrix(&RT,R);
  product(&RRT,R,RT);
  invert_matrix(&RRT1,RRT);
  product(&RRR,RT,RRT1);
  product(&RRRR,RRR,R);
  n=R.get_size()(1);
  P.resize(n,n);
  for(int i=0;i<n;i++){
    for(int j=0;j<n;j++){
      if(i==j){
        P(i,j)=1.0-RRRR(i,j);
      }
      else{
        P(i,j)=-RRRR(i,j);
      }
    }
  }
  transpose_matrix(&PT,P);
  product_diag(&Psigma,P,sigma);
  product(&PsigmaP,Psigma,PT);
  diagonalize_symmetric_matrix(&D,NULL,PsigmaP);
  n=D.get_size();
  for (int i=0;i<n;i++){
    if (D(i)>maxeigen) maxeigen=D(i);
  }
  maxeigen=-maxeigen;
  return maxeigen;
}

void bayesian_ClusterExpansion::calc_eci(Array<Real> *J, const Array<Real> &E, const Array2d<Real> &R, const Array<Real> &W){
  Array2d<Real> RT,RW,RWRT,RWRT1,RTRWRT,WRTRWRT;
  transpose_matrix(&RT,R);
  product_diag(&RW,R,W);
  product(&RWRT,RW,RT);
  invert_matrix(&RWRT1,RWRT);
  product(&RTRWRT,RT,RWRT1);
  product_diag(&WRTRWRT,W,RTRWRT);
  product(J,WRTRWRT,E);
}

void bayesian_ClusterExpansion::calc_eci2(Array<Real> *J, const Array<Real> &E, const Array2d<Real> &R, const Array<Real> &Whalf){
  Array2d<Real> Rwave,RT,A,B,RRR;
  Array<Real> Jwave;
  product_diag(&Rwave,R,Whalf);
  transpose_matrix(&RT,Rwave);
  outer_product(&A,Rwave,Rwave);
  invert_matrix(&B,A);
  product(&RRR,RT,B);
  product(&Jwave,RRR,E);
  J->resize(Whalf.get_size());
  for (int i=0;i<Whalf.get_size();i++){    
    (*J)(i)=Jwave(i)*Whalf(i);
  }
}

Real bayesian_ClusterExpansion::calc_perfect_fit_cv(const Array2d<Real> &R, const Array<Real> &E, const Array<Real> &Whalf){
  //E is the 1D energy matrix, R is n*k matrix and w is the k*k matrix that has 1/wa on the diagonal represented in 1D
  Array2d<Real> Rwave,A,B;
  Array<Real> BE;
  //R n*k Whalf diagonal matrix of k*k
  product_diag(&Rwave,R,Whalf);;
  outer_product(&A,Rwave,Rwave);
  invert_matrix(&B,A);
  Real CV=0.;
  Real diffE=0.;
  Real Ehat=0.;
  product(&BE,B,E);
  for(int i=0;i<A.get_size()(0);i++){
    diffE=-(BE(i))/(B(i,i));
    Ehat=diffE+E(i);
    CV+=pow(diffE,2);
  }
  return sqrt(CV/E.get_size());
}

/*void bayesian_ClusterExpansion::read_extension_parameters(void){
  cerr << "extension parameter is used -xo=" << ((const char *)extension_parameter) << endl;
  int extension_para2;
  AskStruct options[]={
    {"-k","k parameter for prior calculation",INTVAL,&extension_para2}
  };
  int len=strlen(extension_parameter);
  char *paras=new char[len+1];
  strcpy(paras,extension_parameter);
  char *ptr;
  char *eqleft=new char[20];
  char *eqright=new char[20];
  ptr=strtok(paras,",");
  while(ptr!=NULL){
    char *eq=new char[20];
    strcpy(eq,ptr);
    int i=0;
    while (eq[i]!='=' && i<20){
      i++;
      cerr << i << endl;
    }
    strncpy(eqleft,eq,i);
    eqleft[i]='\0';
    strncpy(eqright,eq+i+1,strlen(eq)-i-1);
    eqright[strlen(eq)-i-1]='\0';
    if (strcmp(eqleft,"k")==0){
      parameter_k=atoi(eqright);
    }
    ptr=strtok(NULL,",");
  }
}*/

void bayesian_ClusterExpansion::parse_extension_parameter(const char *extension_parameter){
  std::istringstream iss(extension_parameter);
  std::istream& str(iss);
  AskStruct options[]={
    {"-k","k parameter for prior calculation",INTVAL,&parameter_k},
  };
  get_values(str,countof(options),options,",");
}


///////////////////////////////////////// end ////////////////////////////////////////////////////////
