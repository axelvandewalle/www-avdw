#include <GL/glut.h>
#include <iostream>
#include <fstream>
#include <bits/stdc++.h>

#include "myglut.h"
#include <complex.h>
#include "tensor.h"
#include "normal.h"

// Simulation from the paper:
// Pilot-waves and copilot-particles: A novel approach to objective collapse
// Axel van de Walle
// https://arxiv.org/abs/2506.08168
// (2025)

// To compile this code:
// 0) make sure you have the glut library.
// 1) download ATAT from https://alum.mit.edu/www/avdw/atat and gunzip and untar it
// 2) copy the current file into the atat/src/ directory
// 3) go to the atat/    directory and type     make
// 4) go to the atat/src directory and type     make copilot

// to run: no command-line param needed. Everything is hard-coded for simplicity;


// uncomment if want standard Bohmian dynamics instead of that described in the paper;
//#define USEBOHM

// Wavefunction evolution according to modified schrodinger equation.
class ModSchrodinger {
public:
  // physical constants: defaults set in constuctor, read+write allowed
  Real hbar;
  Real mass;
  Real decay;      // kappa in the paper, set to zero to recover usual Schrodinger eqn
  Real decay_rad;  // sigma in the paper
  Real kTom;       // kBoltzmann T over mass: tau/mu in the paper;
private:
  // simulation parameters set through constructor
  Real dt;
  Real length; // physical length of first dimension of box
  Real dx;
public:
  // potential, set using access_pot(void) member function
  PeriodicTensor<Real> pot;
  // state variables: 3 copies kept in memory for leap-frog algorithm
  Array<PeriodicTensor<Complex> > all_psi; //wavefunction, set using access_psi(void)
  Array<Array<Real> > pos; // position of Bohmian particle, set using set_particle_pos(Array<Real>)
  Array<Array<Real> > vel; // and velocity, set internally
  int tmod;                // time step mod 3 (for leap-frog), set internally
public:
  // Constructor
  // size: array of grid points along each dimension
  // length: physical length associated with size(0) grid points
  // dt: time step
  ModSchrodinger(const Array<int> &size, Real _length, Real _dt): all_psi(3), pot(), pos(3), vel(3) {
    // defaults;
    hbar=1.05457266e-34; // in Js;
    mass=9.1093897e-31;  // in kg;
    decay=2e15;          // in s^-1
    decay_rad=0.2e-10;   // in m
    kTom=5.0e13;         // in m^2/s^2;

    dt=_dt;
    // set sampling grid geometry
    length=_length;
    dx=length/(Real)size(0);
    // create all simulation grids
    pot.resize(size);
    for (int t=0; t<2; t++) {
      all_psi(t).resize(size);
    }
    for (int t=0; t<2; t++) {
      pos(t).resize(size.get_size());
      vel(t).resize(size.get_size());
    }

    tmod=0;
  }

  // various setter and getter
  PeriodicTensor<Real> &access_pot(void) {return pot;}            // use these to init simulation after constructor
  PeriodicTensor<Complex> &access_psi(void) {return all_psi(0);}  //
  void set_particle_pos(const Array<Real> &_pos) {pos(0)=_pos;}   //
  Real get_dx(void) {return dx;} // get implied grid step (in m)

  // localization function (phi in the paper)
  Real kern(Real r,int dim) {
    return exp(-sqr(r)/2.)*pow(2.*M_PI,-(Real)dim/2.);
  }
  // use states from times told and t  to predict state at time tnew
  // curdt is the physical time between told and tnew
  // leap-frog algorithm used
  void propagate(int tnew, int t, int told, Real curdt) {
    // compute prefactors once in advance;
    Complex kine_prefac(0.,hbar*curdt/(2.*mass*sqr(dx)));
    Complex pot_prefac(0.,curdt/hbar);
    Complex vel_prefac(0.,-hbar*curdt/(mass*dx));
    Real force_prefac=kTom*curdt/dx;

    // calc position of particle in grid;
    int dim=pos(t).get_size();
    Array<Real> &rpos=pos(t);
    Array<int> ipos(dim);
    for (int j=0; j<dim; j++) {
      ipos(j)=(int)floor(rpos(j)/dx);
    }

    Array<int> i;
    PeriodicTensor<Complex> &psi=all_psi(t);
    // loop over all grid points;
    MultiDimIterator<Array<int> > it(psi.get_size());
    for (; it; it++) {
      i=(Array<int> &)it;
      Complex grad2psi(0.,0.); // calculate nabla^2 psi;
      for (int d=0; d<i.get_size(); d++) {
	grad2psi-=2.*psi(i);
	i(d)--;
	grad2psi+=psi(i);
	i(d)+=2;
	grad2psi+=psi(i);
	i(d)--;
      }
      // calc distance of grid point to particle;
      Real dr=0.;
      for (int j=0; j<dim; j++) {
	dr+=sqr((Real)(i(j))*dx-rpos(j));
      }
      dr=sqrt(dr);
      // modified Schrodinger equation (equation (1) in paper)
      all_psi(tnew)(i)=all_psi(told)(i)
	+kine_prefac*grad2psi
	+pot_prefac*pot(i)*psi(i)
	-decay*psi(i)*curdt
	+decay*psi(i)*curdt*kern(dr/decay_rad,dim)/(ipow(decay_rad,dim)*sqr(abs(psi(ipos))));
    }
#ifdef USEBOHM
    // calc grad psi for Bohmian dynamics
    Array<Complex> pvel(dim);
    for (int j=0; j<dim; j++) {
      ipos(j)++;
      pvel(j)=psi(ipos);
      ipos(j)--;
      pvel(j)-=psi(ipos);
      pvel(j)*=vel_prefac/psi(ipos);
    }
    // dr/dt=v ;
    for (int j=0; j<dim; j++) {
      Real l=dx*pot.get_size()(j); // needed for periodic boundary conditions;
      pos(tnew)(j)=fmod(pos(told)(j)+real(pvel(j))+l,l);
    }
#else
    // calc gradient of ln |psi| ;
    Array<Real> force(dim);
    for (int j=0; j<dim; j++) {
      ipos(j)++;
      force(j)=real(log(abs(psi(ipos))));
      ipos(j)--;
      force(j)-=real(log(abs(psi(ipos))));
      force(j)*=force_prefac;
    }
    // dv/dt= F/m ;
    for (int j=0; j<dim; j++) {
      vel(tnew)(j)=vel(told)(j)+force(j);
    }
    // dr/dt=v ;
    for (int j=0; j<dim; j++) {
      Real l=dx*pot.get_size()(j); // needed for periodic boundary conditions;
      Real w=0.5; // use a weighted average of leap-frog and 1st order, for stability;
      pos(tnew)(j)=fmod(pos(told)(j)+((1-w)*vel(told)(j)+w*vel(t)(j))*curdt+l,l);
    }    
#endif
  }
  // call this member once after initializing pos, pot and all_psi;
  void post_init(void) {
    zero_array(&vel(0));
#ifndef USEBOHM
    rndseed(1001); // for reproducibility;
    // set velocity to random draw from normal 
    Real vnorm=0.;
    for (int j=0; j<vel(0).get_size(); j++) {
      vel(0)(j)=normal01();
      vnorm+=sqrt(vel(0)(j));
    }
    vnorm/=(Real)(vel(0).get_size());
    vnorm=sqrt(kTom/vnorm);
    for (int j=0; j<vel(0).get_size(); j++) {
      vel(0)(j)*=vnorm;
    }
#endif
    for (int t=1; t<3; t++) {
      all_psi(t)=all_psi(0);
      pos(t)=pos(0);
      vel(t)=vel(0);
    }
    propagate(1,0,0,dt);
    tmod=0;
  }
  // standard one step ahead;
  void propagate(void) {
    propagate((tmod+2)%3,(tmod+1)%3,tmod,2.*dt);
    tmod=(tmod+1)%3;
  }
};

// convert magnitude and phase to intensity and hue;
rVector3d complex_to_rgb(const Complex &z) {
  Real m=abs(z);
  Complex u=z/m;
  Complex R(-0.5,sqrt(3.)/2.);
  rVector3d rgb;
  for (int i=0; i<3; i++) {
    rgb(i)=0.5*(1.+real(u))*sqr(m);
    u=R*u;
  }
  return rgb;
}

// save current view to file in .pam format (see netpbm library)
void dump_screen_shot(const char *filename) {
  int width=glutGet(GLUT_WINDOW_WIDTH);
  int height=glutGet(GLUT_WINDOW_HEIGHT);
  int bufsize=3 * width * height;
  int stepy=3*width;
  GLubyte *data = new GLubyte[bufsize];
  if( data ) {
    glReadPixels(0, 0, width, height, GL_RGB, GL_UNSIGNED_BYTE, data);
  }
  {
    ofstream dumpfile(filename);
    dumpfile << "P7" << endl;
    dumpfile << "WIDTH " << width << endl;
    dumpfile << "HEIGHT " << height << endl;
    dumpfile << "DEPTH 3" << endl;
    dumpfile << "MAXVAL 255" << endl;
    dumpfile << "TUPLTYPE RGB" << endl;
    dumpfile << "ENDHDR" << endl;
    for (int y=1; y<=height; y++) {
      dumpfile.write((char *)data+bufsize-y*stepy,stepy);
    }
  }
  delete data;
}

// View evolving wavefunction using GLUT
class SchrodingerViewer {
private:
  ModSchrodinger &mod_schro; // simulator engine;
  Real bnd;  // max psi magnitude (for plotting);
  int istep; // count steps for screen dumps;
public:
  static SchrodingerViewer *pcurrent_instance;
public:
  int dumpstep; // dump picture to file every this many steps (=0 to turn off) read+write
public:
  // redraw screen;
  VOID_MEMBER_CALLBACK(render_scene,(void),()) {
    // setup color mode;
    glClear(GL_COLOR_BUFFER_BIT);
    // setup coordinate system;
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    Array<int> size;
    size=mod_schro.access_pot().get_size();
    gluOrtho2D(0.,(Real)size(0),0.,(Real)size(1));
    
    PeriodicTensor<rVector3d> rgb(size);    // color map;
    MultiDimIterator<Array<int> > it(size); // to loop over grid points;
    Array<int> i;                           //
    PeriodicTensor<Complex> &psi=mod_schro.all_psi(mod_schro.tmod); // access current psi;
    // if not done yet, find bound on |psi|;
    if (bnd==0.) {
      bnd=0.;
      for ( ; it; it++) {
	bnd=max(bnd,abs(psi((Array<int> &)it)));
      }
    }
    // calc colors for each point;
    it.init(size);
    for ( ; it; it++) {
      i=(Array<int> &)it;
      rgb(i)=complex_to_rgb(psi(i)/bnd);
    }
    // draw pixels (rectangles);
    it.init(size);
    for ( ; it; it++) {
      i=(Array<int> &)it;
      glBegin(GL_QUADS);
      for (int c=0; c<4; c++) {
	glColor3f(rgb(i)(0),rgb(i)(1),rgb(i)(2));
	glVertex2f(i(0),i(1));
	i(c%2)+=(c>=2 ? -1:1); // go to next corner of square;
      }
      glEnd();
    }
    // draw the Bohmian particle;
    Real dx=mod_schro.get_dx(); // to convert coord to grid index;
    int isin[]={0,1,0,-1};
    Array<Real> &rpos=mod_schro.pos(mod_schro.tmod);
    glBegin(GL_QUADS);
    glColor3f(1.,1.,1.);
    for (int c=0; c<4; c++) {
      glVertex2f(rpos(0)/dx+isin[(c+1)%4],rpos(1)/dx+isin[c]);
    }
    glEnd();

    // to overlay potential;
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    glEnable(GL_BLEND);

    Real maxpot=max(mod_schro.pot.vectorize());

    // draw potential in grey scale;
    it.init(size);
    for ( ; it; it++) {
      i=(Array<int> &)it;
      glBegin(GL_QUADS);
      for (int c=0; c<4; c++) {
	glColor4f(1.,1.,1.,mod_schro.pot(i)/maxpot);
	glVertex2f(i(0),i(1));
	i(c%2)+=(c>=2 ? -1:1); // next corner of square;
      }
      glEnd();
    }

    // dump screen shot if requested;
    if (dumpstep>0) {
      if (istep % dumpstep == 0) {
	ostrstream filename;
	filename << "schro_" << setfill('0') << setw(4) << istep << ".pam" << "\0";
	dump_screen_shot(filename.str());
      }
    }
    istep++;

    glutSwapBuffers();

    mod_schro.propagate();
  }
  // Constructor: need to provide an initiallized ModSchrodinger;
  SchrodingerViewer(ModSchrodinger &_mod_schro): mod_schro(_mod_schro) {
    SchrodingerViewer::pcurrent_instance=this; // used for callbacks to member functions;
    // setup GLUT window params;
    glutInitDisplayMode(GLUT_DEPTH | GLUT_DOUBLE | GLUT_RGBA);
    glutInitWindowPosition(20,20);
    glutInitWindowSize(1000,1000);
    glutCreateWindow("Modified Schrodinger");
    glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
    bnd=0.; // will update after first step;
    istep=0;
    dumpstep=0;
    // callbacks;
    glutDisplayFunc(  &SchrodingerViewer::static_render_scene);
    glutIdleFunc(     &SchrodingerViewer::static_render_scene);
  }
};

SchrodingerViewer *SchrodingerViewer::pcurrent_instance=NULL;

int main(int argc, char *argv[]) {
  glutInit(&argc, argv);
  // setup a 2D grid, but the code can handle n-dimensions;
  Array<int> size(2); size(0)=100; size(1)=100; // sampling grid size;
  Real length=10e-10; // in m
  Real dt=0.2e-18;    // in s
  ModSchrodinger mod_schro(size,length,dt);
  mod_schro.mass=9.1093897e-31; // in kg;
  mod_schro.decay=2e15;         // in s^-1
  mod_schro.decay_rad=0.2e-10;  // in m
  mod_schro.kTom=5.0e13;        // in m^2/s^2; tau/mu in the paper;

  // init the potential and initial wavefunction;
  PeriodicTensor<Real> &pot=mod_schro.access_pot();       // access inner arrays
  PeriodicTensor<Complex> &allpsi=mod_schro.access_psi(); //
  MultiDimIterator<Array<int> > it(pot.get_size());
  Array<int> i;
  Real dx=mod_schro.get_dx();
  Real sum=0.;
  // loop over all grid points:
  for ( ; it; it++) {
    i=(Array<int> &)it;
    // wall with double slit potential:
    pot(i)=(abs(i(0)*dx-length*0.3)<length/60. ? 1. : 0.)*(abs(abs(i(1)*dx-length/2.)-length/12) > length/14 ? 1. : 0.)*4e-16;
    // gaussian wave packet as initial wavefunction
    Complex psi=exp(Complex(0.,10.*2.*M_PI*i(0)*dx/length))*Complex(exp(-(sqr(i(0)*dx-length/6)+sqr(i(1)*dx-length/2))/(2.*sqr(length/12.))),0.);
    allpsi(i)=psi;
    sum+=sqr(abs(psi)); // to normalize wavefunc;
  }
  sum*=pow(dx,(Real)pot.get_size().get_size());
  allpsi/=sqrt(sum); // normalize wavefunc;

  // set Bohmian particle initial pos;
  Array<Real> pos(2);
  pos(0)=length*(1./6.-0.03); pos(1)=length*0.58;
  mod_schro.set_particle_pos(pos);
  
  mod_schro.post_init(); // must call this after setup;
  
  SchrodingerViewer viewer(mod_schro); // create viewer;
  viewer.dumpstep=0; // set this to >0 to dump periodic screen shots
  glutMainLoop();
}
