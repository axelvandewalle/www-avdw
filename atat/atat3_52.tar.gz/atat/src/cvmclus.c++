#include <fstream>
#include "parse.h"
#include "getvalue.h"
#include "version.h"
#include "calccorr.h"

extern char *helpstring;

template<class T>
T sum(const Array<T> &a) {
  T s=0;
  for (int i=0; i<a.get_size(); i++) {s+=a(i);}
  return s;
}

ostream& operator << (ostream &s, const MultiCluster &multiclus) {
  s << multiclus.clus.get_size() << endl;
  for (int i=0; i<multiclus.clus.get_size(); i++) {
    s << multiclus.clus(i) << " " << multiclus.func(i) << " " << multiclus.site_type(i) << endl;
  }
  return s;
}

void find_subclusters(LinkedList<MultiCluster> *pcluslist, const MultiCluster &maxclus, const SpaceGroup &spacegroup) {
  Array<int> maxselect(maxclus.clus.get_size());
  for (int i=0; i<maxselect.get_size(); i++) {maxselect(i)=(maxclus.site_type(i)>1 ? 2:1);}
  MultiDimIterator<Array<int> > select(maxselect);
  for (; select; select++) {
    Array<int> &sel=(Array<int> &)select;
    int nbpt=sum(sel);
    MultiCluster *pclus=new MultiCluster(nbpt);
    int j=0;
    for (int i=0; i<maxselect.get_size(); i++) {
      if (sel(i)==1) {
	pclus->clus(j)=maxclus.clus(i);
	pclus->func(j)=0;
	pclus->site_type(j)=maxclus.site_type(i); //nb of species;
	j++;
      }
    }
    LinkedListIterator<MultiCluster> iclus(*pcluslist);
    for (; iclus; iclus++) {
      if (equivalent_by_symmetry(*pclus, *iclus, spacegroup.cell,spacegroup.point_op,spacegroup.trans)) {break;}
    }
    if (!iclus) {
      iclus.init(*pcluslist);
      for (; iclus; iclus++) {
	if (iclus->clus.get_size() > pclus->clus.get_size()) {
	  break;
	}
	else if (iclus->clus.get_size() == pclus->clus.get_size()) {
	  if (get_length_slow(iclus->clus) > get_length_slow(pclus->clus)) {
	    break;
	  }
	}
      }
      pcluslist->add(pclus,iclus);
    }
    else {
      delete pclus;
    }
  }
}

void generate_functions_on_clusters(LinkedList<MultiCluster> *pmulticluslist, const LinkedList<MultiCluster> &cluslist, const SpaceGroup &spacegroup) {
  LinkedListIterator<MultiCluster> begclus(*pmulticluslist);
  LinkedListIterator<MultiCluster> iclus(cluslist);
  for (; iclus; iclus++) {
    Array<int> occup(iclus->clus.get_size());
    for (int i=0; i<occup.get_size(); i++) {occup(i)=iclus->site_type(i)-1;}
    MultiDimIterator<Array<int> > conf(occup);
    for (; conf; conf++) {
      MultiCluster *pclus=new MultiCluster;
      pclus->clus=iclus->clus;
      pclus->func=conf;
      pclus->site_type.resize(occup.get_size());
      for (int i=0; i<occup.get_size(); i++) {pclus->site_type(i)=occup(i)-1;} // func type: 0=binary, 1=ternary;
      LinkedListIterator<MultiCluster> jclus(begclus);
      for (; jclus; jclus++) {
	if (equivalent_by_symmetry(*pclus,*jclus,spacegroup.cell,spacegroup.point_op,spacegroup.trans)) {break;}
      }
      if (jclus) {
	delete pclus;
      }
      else {
	(*pmulticluslist) << pclus;
      }
    }
    while (begclus) {begclus++;}
  }
}

void generate_config_on_clusters(LinkedList<LinkedList<MultiCluster> > *pconfiglistlist, LinkedList<LinkedList<Real> > *pmultlistlist,
				 const LinkedList<MultiCluster> &cluslist, const SpaceGroup &spacegroup) {
  LinkedListIterator<MultiCluster> iclus(cluslist);
  for (; iclus; iclus++) {
    LinkedList<MultiCluster> *pconfiglist=new LinkedList<MultiCluster>;
    LinkedList<Real> *pmultlist=new LinkedList<Real>;
    SpaceGroup subgroup;
    find_clusters_symmetry(&subgroup,*iclus,spacegroup);
    
    Array<int> occup(iclus->clus.get_size());
    for (int i=0; i<occup.get_size(); i++) {occup(i)=iclus->site_type(i);}
    MultiDimIterator<Array<int> > conf(occup);
    for (; conf; conf++) {
      MultiCluster *pclus=new MultiCluster;
      pclus->clus=iclus->clus;
      pclus->func=conf;
      pclus->site_type=occup; // nb of species;
      LinkedListIterator<MultiCluster> jclus(*pconfiglist);
      LinkedListIterator<Real> jmult(*pmultlist);
      for (; jclus; jclus++, jmult++) {
	if (equivalent_by_symmetry(*pclus,*jclus,subgroup.point_op,subgroup.trans)) {break;}
      }
      if (jclus) {
	(*jmult)+=1.;
	delete pclus;
      }
      else {
	(*pconfiglist) << pclus;
	(*pmultlist) << new Real(1.);
      }
    }
    (*pconfiglistlist) << pconfiglist;
    (*pmultlistlist) << pmultlist;
  }
}

void calc_v_matrix(LinkedList<Array2d<Real> > *pvmatlist,
		   const LinkedList<LinkedList<MultiCluster> > &configlistlist, const LinkedList<LinkedList<Real> > &configmultlistlist,
		   const LinkedList<MultiCluster> &multicluslist,
		   const SpaceGroup &spacegroup, const CorrFuncTable &corrfunc) {
  LinkedListIterator<LinkedList<MultiCluster> > iconfiglist(configlistlist);
  LinkedListIterator<LinkedList<Real> > iconfigmultlist(configmultlistlist);//
  
  for (; iconfiglist; iconfiglist++,iconfigmultlist++) {
    Array2d<Real> *pvmat=new Array2d<Real>(iconfiglist->get_size(),multicluslist.get_size());
    Array2d<Real> ximat(multicluslist.get_size(),iconfiglist->get_size());// debug
    
    LinkedListIterator<MultiCluster> iclus(multicluslist);
    for (int j=0; iclus; iclus++, j++) {
      Real prefac=1.;
      {
	LinkedListIterator<MultiCluster> iconf(*iconfiglist);
	for (int p=0; p<iconf->site_type.get_size(); p++) {
	  int at=which_atom(iclus->clus,iconf->clus(p));
	  if (at==-1) {
	    prefac*=(Real)(iconf->site_type(p));
	  }
	  else {
	    Real sum2=0.;
	    for (int q=0; q<corrfunc(iclus->site_type(at))(iclus->func(at)).get_size(); q++) {
	      sum2+=sqr(corrfunc(iclus->site_type(at))(iclus->func(at))(q));
	    }
	    prefac*=sum2;
	  }
	}
      }
      //cout << prefac << " ";

      Array<MultiCluster> equiv_clusters;
      find_equivalent_clusters(&equiv_clusters, *iclus,spacegroup.cell,spacegroup.point_op,spacegroup.trans);
      LinkedListIterator<MultiCluster> iconf(*iconfiglist);
      LinkedListIterator<Real> iconfigmult(*iconfigmultlist);//debug
      for (int i=0; iconf; iconf++, i++, iconfigmult++) {
	int mult;
	Real corrmult=calc_correlation_atomcluster(iconf->clus,iconf->func,equiv_clusters,spacegroup.cell,corrfunc,&mult);
	(*pvmat)(i,j)=corrmult/prefac;
	ximat(j,i)=(mult==0?0:corrmult/(Real)mult)*(*iconfigmult); //debug
      }
    }
    /*
    Array2d<Real> tmp;
    product(&tmp,ximat,*pvmat);
    cout << tmp;
    */
    (*pvmatlist) << pvmat;
  }
  /*
  LinkedListIterator<LinkedList<MultiCluster> > iconfiglist(configlistlist);
  for (; iconfiglist; iconfiglist++) {
    Array2d<Real> *pvmat=new Array2d<Real>(iconfiglist->get_size(),multicluslist.get_size());
    
    Real prefac=1.;
    {
      LinkedListIterator<MultiCluster> iconf(*iconfiglist);
      for (int p=0; p<iconf->site_type.get_size(); p++) {prefac*=(Real)(iconf->site_type(p));}
    }
    LinkedListIterator<MultiCluster> iclus(multicluslist);
    for (int j=0; iclus; iclus++, j++) {
      Array<MultiCluster> equiv_clusters;
      find_equivalent_clusters(&equiv_clusters, *iclus,spacegroup.cell,spacegroup.point_op,spacegroup.trans);
      LinkedListIterator<MultiCluster> iconf(*iconfiglist);
      for (int i=0; iconf; iconf++, i++) {
	int mult;
	Real corrmult=calc_correlation_atomcluster(iconf->clus,iconf->func,equiv_clusters,spacegroup.cell,corrfunc,&mult);
	(*pvmat)(i,j)=corrmult/prefac;
      }
    }
  }
  */
  /*
  LinkedListIterator<LinkedList<MultiCluster> > iconfiglist(configlistlist);
  LinkedListIterator<LinkedList<Real> > iconfigmultlist(configmultlistlist);
  for (; iconfiglist; iconfiglist++,iconfigmultlist++) {
    Array2d<Real> ximat(multicluslist.get_size(),iconfiglist->get_size());
    
    LinkedListIterator<MultiCluster> iclus(multicluslist);
    for (int j=0; iclus; iclus++, j++) {
      Array<MultiCluster> equiv_clusters;
      find_equivalent_clusters(&equiv_clusters, *iclus,spacegroup.cell,spacegroup.point_op,spacegroup.trans);
      LinkedListIterator<MultiCluster> iconf(*iconfiglist);
      for (int i=0; iconf; iconf++, i++) {
	int mult;
	Real corrmult=calc_correlation_atomcluster(iconf->clus,iconf->func,equiv_clusters,spacegroup.cell,corrfunc,&mult);
	ximat(j,i)=(mult==0 ? 0. : corrmult/(Real)mult);
	cout << mult << " ";
      }
      cout << endl;
    }
    cout << ximat << endl;
    iVector2d sz=ximat.get_size();
    LinkedList<int> keeprow;
    for (int i=0; i<sz(0); i++) {
      Real sum2=0.;
      for (int j=0; j<sz(1); j++) {sum2+=sqr(ximat(i,j));}
      if (sum2>sqr(zero_tolerance)) {
	keeprow << new int(i);
      }
    }
    //cerr << keeprow << endl;
    Array2d<Real> smlximat(keeprow.get_size(),sz(1));
    //cerr << smlximat << endl;
    {
      LinkedListIterator<int> ii(keeprow);
      for (int i=0; ii; i++,ii++) {
	for (int j=0; j<sz(1); j++) {smlximat(i,j)=ximat(*ii,j);}
      }
    }
    //cout << smlximat << endl;
    Array2d<Real> invsmlximat;
    invert_matrix_wide(&invsmlximat,smlximat);
    cout << invsmlximat << endl;
    Array2d<Real> *pvmat=new Array2d<Real>(sz(1),sz(0));
    zero_array(pvmat);
    //cerr << *pvmat << endl;
    {
      LinkedListIterator<int> ii(keeprow);
      for (int i=0; ii; i++,ii++) {
	LinkedListIterator<Real> iconfigmult(*iconfigmultlist);
	for (int j=0; j<sz(1); j++,iconfigmult++) {(*pvmat)(j,*ii)=invsmlximat(j,i)/(*iconfigmult);}
      }
    }
    cout << *pvmat << endl;
    //cerr << ximat << endl;
    //invert_matrix_tall(pvmat,ximat);
    Array2d<Real> tmp;
    //product(&tmp,invsmlximat,smlximat);
    //cout << tmp << endl;
    //product(&tmp,ximat,*pvmat);
    //cout << tmp << endl;
    (*pvmatlist) << pvmat;
  }
  */
}

void calc_kikuchi_barker(Array<Real> *pkbcoef, const LinkedList<MultiCluster> &cluslist, const SpaceGroup &spacegroup) {
  Array<Real> &kbcoef=*pkbcoef;
  kbcoef.resize(cluslist.get_size());
  kbcoef(0)=0.;
  for (int curclus=kbcoef.get_size()-1; curclus>0; curclus--) {
    kbcoef(curclus)=1.;
    LinkedListIterator<MultiCluster> iclus=LinkedListIterator<MultiCluster>(cluslist)+curclus;
    Array<MultiCluster> candi_clus;
    Array<int> which_clus;
    find_clusters_overlapping_site(&candi_clus,&which_clus,iclus->clus(0),spacegroup,cluslist);
    for (int c=0; c<candi_clus.get_size(); c++) {
      if (candi_clus(c).clus.get_size() > iclus->clus.get_size()) {
	int i;
	for(i=0; i<iclus->clus.get_size(); i++) {
	  if (which_atom(candi_clus(c).clus,iclus->clus(i))==-1) break;
	}
	if (i==iclus->clus.get_size()) {
	  kbcoef(curclus)-=kbcoef(which_clus(c));
	}
      }
    }
  }
}

int main(int argc, char *argv[]) {
  // parsing command line. See getvalue.hh for details;
  char *latfilename="lat.in";
  char *maxclusfilename="maxclus.in";
  int sigdig=5;
  char *corrfunc_label="trigo";
  int dohelp=0;
  int dummy=0;
  AskStruct options[]={
    {"","Cluster Variation Method CLUSter generator " MAPS_VERSION ", by Axel van de Walle",TITLEVAL,NULL},
    {"-h","Display more help",BOOLVAL,&dohelp},
    {"-l","Input file defining the lattice (Default: lat.in)",STRINGVAL,&latfilename},
    {"-m","Maximal cluster (Default: maxclus.in)",STRINGVAL,&maxclusfilename},
    {"-sig","Number of significant digits printed (Default: 5)",INTVAL,&sigdig},
    {"-crf","Select correlation functions (default: trigo)",STRINGVAL,&corrfunc_label},
    {"-d","Use all default values",BOOLVAL,&dummy}
  };
  if (!get_values(argc,argv,countof(options),options)) {
    display_help(countof(options),options);
    return 1;
  }
  if (dohelp) {
    cout << helpstring;
    return 1;
  }
  
  cout.setf(ios::fixed);
  cout.precision(sigdig);
  
  // parsing lattice and structure files. See parse.hh for detail;
  Structure lat;
  Array<Arrayint> labellookup;
  Array<AutoString> label;
  rMatrix3d axes;
  {
    ifstream latfile(latfilename);
    if (!latfile) ERRORQUIT("Unable to open lattice file");
    parse_lattice_file(&lat.cell, &lat.atom_pos, &lat.atom_type, &labellookup, &label, latfile, &axes);
    wrap_inside_cell(&lat.atom_pos,lat.atom_pos,lat.cell);
  }
  rMatrix3d icell=!lat.cell;
  SpaceGroup spacegroup;
  spacegroup.cell=lat.cell;
  find_spacegroup(&spacegroup.point_op,&spacegroup.trans,lat.cell,lat.atom_pos,lat.atom_type);

  LinkedList<MultiCluster> cluslist;

  {
    ifstream maxclusfile(maxclusfilename);
    if (!maxclusfile) ERRORQUIT("Unable to open maximal cluster file");
    while (1) {
      LinkedList<rVector3d> maxcluslist;
      while (1) {
	rVector3d v(MAXFLOAT,MAXFLOAT,MAXFLOAT);
	maxclusfile >> v;
	if (maxclusfile.eof() || v(0) == MAXFLOAT || !maxclusfile) {break;}
	maxcluslist << new rVector3d(axes*v);
      }
      skip_to_next_structure(maxclusfile);
      MultiCluster maxclus;
      LinkedList_to_Array(&maxclus.clus,maxcluslist);
      if (maxclus.clus.get_size()==0) {break;}
      maxclus.site_type.resize(maxclus.clus.get_size());
      for (int i=0; i<maxclus.clus.get_size(); i++) {
	maxclus.site_type(i)=labellookup(lat.atom_type(which_atom(lat.atom_pos,maxclus.clus(i),icell))).get_size();
      }
      find_subclusters(&cluslist, maxclus,spacegroup);
    }
  }
  
  LinkedList<MultiCluster> multicluslist;
  generate_functions_on_clusters(&multicluslist, cluslist,spacegroup);

  {
    ofstream clusterfile("clusters.out");
    clusterfile.setf(ios::fixed);
    clusterfile.precision(sigdig);
    LinkedListIterator<MultiCluster> icluster(multicluslist);
    for ( ; icluster; icluster++) {
      int mult=calc_multiplicity(*icluster, spacegroup.cell, spacegroup.point_op, spacegroup.trans);
      clusterfile << mult << endl;
      clusterfile << get_length_slow(icluster->clus) << endl;
      clusterfile << icluster->clus.get_size() << endl;
      for (int i=0; i<icluster->clus.get_size(); i++) {
	clusterfile << ((!axes)*(icluster->clus(i))) << " " << icluster->site_type(i) << " " << icluster->func(i) <<  endl;
      }
      clusterfile << endl;
    }
  }
  {
    ofstream clusmultfile("clusmult.out");
    clusmultfile << multicluslist.get_size() << endl;
    LinkedListIterator<MultiCluster> icluster(multicluslist);
    for ( ; icluster; icluster++) {
      int mult=calc_multiplicity(*icluster, spacegroup.cell, spacegroup.point_op, spacegroup.trans);
      clusmultfile << mult << endl;
    }
  }
  
  LinkedList<LinkedList<MultiCluster> > configlistlist;
  LinkedList<LinkedList<Real> > multlistlist;
  generate_config_on_clusters(&configlistlist,&multlistlist, cluslist,spacegroup);
  {
    ofstream configfile("config.out");
    configfile.setf(ios::fixed);
    configfile.precision(sigdig);
    configfile << configlistlist;
  }
  {
    ofstream configmultfile("configmult.out");
    configmultfile.setf(ios::fixed);
    configmultfile.precision(sigdig);
    configmultfile << multlistlist;
  }

  
  if (!check_plug_in(CorrFuncTable(),corrfunc_label)) {ERRORQUIT("Aborting");}
  CorrFuncTable *pcorrfunc=GenericPlugIn<CorrFuncTable>::create(corrfunc_label);
  pcorrfunc->init_from_site_type_list(labellookup);
  //cerr << *pcorrfunc << endl;

  LinkedList<Array2d<Real> > vmatlist;
  calc_v_matrix(&vmatlist,configlistlist,multlistlist,multicluslist,spacegroup,*pcorrfunc);
  {
    ofstream vmatfile("vmat.out");
    vmatfile.setf(ios::fixed);
    vmatfile.precision(sigdig);
    vmatfile << vmatlist;
  }
    
  Array<Real> kbcoef;
  calc_kikuchi_barker(&kbcoef, cluslist,spacegroup);
  {
    ofstream configkbfile("configkb.out");
    configkbfile.setf(ios::fixed);
    configkbfile.precision(sigdig);
    configkbfile << kbcoef;
  }
}
