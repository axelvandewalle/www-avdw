#include <fstream.h>
#include "getvalue.h"
#include "version.h"
#include "integer.h"
#include "linalg.h"
#include "lstsqr.h"
#include "meshutil.h"
#include "tensor.h"
#include "meshcalc.h"
#include "mpiinterf.h"

char *helpstring="Insert more help here";

int main(int argc, char *argv[]) {
  // parsing command line. See getvalue.hh for details;
  char *tabfilename="tab.in";
  //  Real maxd=0.;
  Real color=0;
  Array<Real> rgb;
  Real rmax=0.1;
  Real rmin=1e-3;
  int sigdig=5;
  char *exporter_label="vtk";
  int doline=0;
  int dotie=0;
  Real tiewidth=0.01;
  int nofixnormal=0;
  int backface=0;
  int docut=0;
  char *cutfilename="cut.in";
  int dohelp=0;
  int dummy=0;
  AskStruct options[]={
    {"","Simplexize " MAPS_VERSION ", by Axel van de Walle",TITLEVAL,NULL},
    {"-t","Input table file",STRINGVAL,&tabfilename},
    //{"-md","Max distance between points of the same surface",REALVAL,&maxd},
    {"-col","Color",REALVAL,&color},
    {"-rgb","RGB Color",ARRAYRVAL,&rgb},
    {"-rmax","Maximum radius of curvature",REALVAL,&rmax},
    {"-rmin","Minimum distance between points kept",REALVAL,&rmin},
    {"-l","Plot lines",BOOLVAL,&doline},
    {"-tie","Plot tie lines",BOOLVAL,&dotie},
    {"-tiew","Tie line width",REALVAL,&tiewidth},
    //{"-nfn","do Not fix Normal vector",BOOLVAL,&nofixnormal},
    //{"-bf","generate back face",BOOLVAL,&backface},
    {"-sig","Number of significant digits printed (default: 5)",INTVAL,&sigdig},
    {"-ef","Export format (default: vtk)",STRINGVAL,&exporter_label},
    {"-cs","Cross-Section",BOOLVAL,&docut},
    {"-cf","Cross section input File",STRINGVAL,&cutfilename},
    {"-h","Display more help",BOOLVAL,&dohelp},
    {"-d","Use all default values",BOOLVAL,&dummy}
  };
  if (!get_values(argc,argv,countof(options),options)) {
    display_help(countof(options),options);
    return 1;
  }
  if (dohelp) {
    cout << helpstring;
    return 1;
  }

  if (!check_plug_in(MeshExporter(),exporter_label)) {
    // cerr << exporter_label << endl;
    ERRORQUIT("Unknown export format");
  }
  MeshExporter *pexporter=GenericPlugIn<MeshExporter>::create(exporter_label);


  Array<Array<Real> > rawpts;
#ifdef ATAT_MPI
  MyMPIobj.init(argc,argv);
  if (MyMPIobj.is_root()) {
    cerr << "Num proc= " << MyMPIobj.numproc << endl;
#endif
  if (strcmp(tabfilename,"-")==0) {
    read_table(&rawpts,cin,1);
  }
  else {
    ifstream tabfile(tabfilename);
    if (!tabfile) ERRORQUIT("Unable to open table file");
    read_table(&rawpts,tabfile,1);
  }
#ifdef ATAT_MPI
  }
  //cerr << MyMPIobj.id << ": reading done?\n";
  MyMPI_BcastStream(&rawpts);
  //cerr << MyMPIobj.id << ": bcast done?\n";
#endif
  /*
  {
    PointGridIndex grid_index(rawpts);
    Array<Real> center(rawpts(0));
    PointFromCenterIteratorGridIndex i(rawpts,grid_index,center);
    for (; i; i++) {
      Array<Real> v;
      diff(&v,rawpts(i()),center);
      cout << rawpts(i())(0) << " " << rawpts(i())(1) << " " << rawpts(i())(2) << " " << norm(v) << endl;
    }
    return(0);
  }
  */
  
  // cerr << rawpts << endl;

  // Array<Array<Real> > allpts;
  //LinkedList<rVector3d> listpts3;
  LinkedList<Array<Real> > listpts;
  LinkedList<Array<int> > allpoly;

  if (doline) {
    int idx=0;
    for (int begi=0; begi<rawpts.get_size(); begi++) {
      int endi=begi;
      int reali=idx;
      while (endi<rawpts.get_size() && rawpts(endi).get_size()>0) endi++;
      for (int i=begi; i<endi; i++) {
	//rVector3d *pv=new rVector3d();
	//Array_to_FixedVector(pv,rawpts(i));
	//listpts3 << pv;
	listpts << new Array<Real>(rawpts(i));
	idx++;
      }
      int numi=endi-begi;
      for (int i=0; i<numi; i++) {
	for (int j=i+1; j<numi; j++) {
	  Array<int> *pline=new  Array<int>(2);
	  (*pline)(0)=reali+i;
	  (*pline)(1)=reali+j;
	  allpoly << pline;
	}
      }
      begi=endi;
    }
  }
  else if (dotie) {
    int idx=0;
    for (int begi=0; begi<rawpts.get_size(); begi++) {
      int endi=begi;
      int bidx=idx;
      while (endi<rawpts.get_size() && rawpts(endi).get_size()>0) endi++;
      if (endi-begi==2) {
	Array<Array<Real> > splx;
	{
	  make_simplex(&splx,rawpts(begi).get_size()-1);
	  Array<Real> mid(splx(0));
	  for (int i=1; i<splx.get_size(); i++) {sum(&mid,mid,splx(i));}
	  product(&mid,mid,1./(Real)(splx.get_size()));
	  for (int i=0; i<splx.get_size(); i++) {diff(&splx(i),splx(i),mid);}
	}
	Array<Real> dir;
	diff(&dir,rawpts(begi+1),rawpts(begi));
	normalize(&dir);
	Array<Array<Real> > basis;
	build_ortho_basis(&basis,NULL,dir);
	for(int i=0; i<dir.get_size(); i++) {
	  Array<Real> tryv(dir.get_size());
	  zero_array(&tryv);
	  tryv(i)=1.;
	  build_ortho_basis(&basis,NULL,tryv);
	}
	Array2d<Real> rot;
	ArrayArray_to_Array2d(&rot,basis,1);
	product(&rot,rot,tiewidth);
	Array<Real> mid;
	sum(&mid,rawpts(begi+1),rawpts(begi));
	product(&mid,mid,0.5);
	for (int p=0; p<splx.get_size(); p++) {
	  Array<Real> pt(mid.get_size());
	  pt(0)=0.;
	  extract_elements(&pt,1,splx(p),0,splx(p).get_size());
	  Array<Real> tpt;
	  product(&tpt,rot,pt);
	  sum(&tpt,tpt,mid);
	  listpts << new Array<Real>(tpt);
	  idx++;
	}
	listpts << new Array<Real>(rawpts(begi));
	listpts << new Array<Real>(rawpts(begi+1));
	idx+=2;
	for (int p=0; p<splx.get_size(); p++) {
	  for (int dir=0; dir<2; dir++) {
	    Array<int> *ppoly=new  Array<int>(mid.get_size());
	    int i=0;
	    for (int j=0; ; j++,i++) {
	      if (j==p) {j++;}
	      if (j>=splx.get_size()) {break;}
	      (*ppoly)(i)=bidx+j;
	    }
	    (*ppoly)(i)=bidx+splx.get_size()+dir;
	    allpoly << ppoly;
	  }
	}
      }
      begi=endi;
    }
  }
  else {
    int surfbeg=0;
    while (surfbeg<rawpts.get_size()) {
      int surfend=surfbeg;
      while (surfend<rawpts.get_size() && rawpts(surfend).get_size()>0) surfend++;
      Array<Array<Real> > pts;
      extract_elements(&pts, rawpts,surfbeg,surfend);
      
      cerr << "begin remove_nearby\n";
      remove_nearby(&pts, pts,rmin);
      cerr << "done remove_nearby\n";
      LinkedList<Array<int> > poly;
      create_mesh(&poly, pts,0,rmax);

      if (docut) {
	Array<Real> org;
	Array<Array<Real> > axes;
	{
	  ifstream cutfile(cutfilename);
	  if (!cutfile) ERRORQUIT("Unable to open input file for cross section.");
	  Array<Array<Real> > rawcut;
	  read_table(&rawcut,cutfile,0);
	  org=rawcut(0);
	  axes.resize(rawcut.get_size()-1);
	  for (int j=0; j<axes.get_size(); j++) {
	    diff(&(axes(j)),rawcut(j+1),org);
	  }
	}

	// cerr << poly << endl;

	Array<Array<Real> > cutpts;
	LinkedList<Array<int> > cutpoly;
	cross_section_simplexes(&cutpts,&cutpoly, axes,org,pts,poly);
	// cerr << cutpts << endl;
	if (cutpts.get_size()==0) ERRORQUIT("No intersection!");
	int ddim=3;
	if (cutpts(0).get_size()<ddim) {
	  Array<Array<Real> > copycutpts(cutpts);
	  for (int i=0; i<copycutpts.get_size(); i++) {
	    cutpts(i).resize(ddim);
	    int j;
	    for (j=0; j<copycutpts(i).get_size(); j++) {
	      cutpts(i)(j)=copycutpts(i)(j);
	    }
	    for (; j<ddim; j++) {
	      cutpts(i)(j)=0.;
	    }
	  }
	}

	//Array<rVector3d> pts3;
	//ArrayArray_to_ArrayFixedVector(&pts3,cutpts);
	//combine_mesh(&listpts3,&allpoly, pts3,cutpoly);
	combine_mesh(&listpts,&allpoly, pts,cutpoly);
	//exit(1);
      }
      else {
	//Array<rVector3d> pts3;
	//ArrayArray_to_ArrayFixedVector(&pts3,pts);
	//combine_mesh(&listpts3,&allpoly, pts3,poly);
	combine_mesh(&listpts,&allpoly, pts,poly);
	// cerr << "surfend= " << surfend << endl;
	// cerr << "meshptssize= " << listpts3.get_size() << endl;
	// cerr << "meshpolysize= " << allpoly.get_size() << endl;
      }
      surfbeg=surfend+1;
    }
  }
  Array<Array<Real> > colors(1);
  if (rgb.get_size()>0) {
    colors(0)=rgb;
  }
  else {
    colors(0).resize(1);
    colors(0)(0)=color;
  }

  //Array<rVector3d> allpts3;
  //LinkedList_to_Array(&allpts3,listpts3);
  //pexporter->write(cout,allpts3,allpoly,colors);
  Array<Array<Real> > allpts;
  LinkedList_to_Array(&allpts,listpts);
#ifdef ATAT_MPI
  if (MyMPIobj.is_root()) {
#endif
  cout.setf(ios::fixed);
  cout.precision(sigdig);
  pexporter->write(cout,allpts,allpoly,colors);
#ifdef ATAT_MPI
  }
#endif
}
