#include "linalg.h"

#define ATATPOINTERIZE

void transpose_matrix(Array2d<Real> *trans,const Array2d<Real> &a) {
  int maxi=a.get_size()(1);
  int maxj=a.get_size()(0);
  trans->resize(maxi,maxj);
  for (int i=0; i<maxi; i++) {
    for (int j=0; j<maxj; j++) {
      (*trans)(i,j)=a(j,i);
    }
  }
}


void diff(Array<Real> *result, const Array<Real> &a, const Array<Real> &b) {
#ifdef DEBUG
  if (a.get_size()!=b.get_size()) ERRORQUITDUMP("Matrices not conformable");
#endif
#ifdef ATATPOINTERIZE
  int sz=a.get_size();
  result->resize(sz);
  Real *pr=result->get_buf();
  Real *pre=pr+sz;
  const Real *pa=a.get_buf_c();
  const Real *pb=b.get_buf_c();
  for (; pr<pre; pr++, pa++, pb++) {
    *pr=*pa-*pb;
  }
#else
  result->resize(a.get_size());
  for (int i=0; i<a.get_size(); i++) {
    (*result)(i)=a(i)-b(i);
  }
#endif
}

void diff(Array2d<Real> *result, const Array2d<Real> &a, const Array2d<Real> &b) {
#ifdef DEBUG
  if (a.get_size()!=b.get_size()) ERRORQUITDUMP("Matrices not conformable");
#endif
  result->resize(a.get_size());
  for (int i=0; i<a.get_size()(0); i++) {
    for (int j=0; j<a.get_size()(1); j++) {
      (*result)(i,j)=a(i,j)-b(i,j);
    }
  }
}

void diff(Array<int> *result, const Array<int> &a, const Array<int> &b) {
#ifdef DEBUG
  if (a.get_size()!=b.get_size()) ERRORQUITDUMP("Matrices not conformable");
#endif
  result->resize(a.get_size());
  for (int i=0; i<a.get_size(); i++) {
    (*result)(i)=a(i)-b(i);
  }
}

void sum(Array<Real> *result, const Array<Real> &a, const Array<Real> &b) {
#ifdef DEBUG
  if (a.get_size()!=b.get_size()) ERRORQUITDUMP("Matrices not conformable");
#endif
#ifdef ATATPOINTERIZE
  int sz=a.get_size();
  result->resize(sz);
  Real *pr=result->get_buf();
  Real *pre=pr+sz;
  const Real *pa=a.get_buf_c();
  const Real *pb=b.get_buf_c();
  for (; pr<pre; pr++, pa++, pb++) {
    *pr=*pa+*pb;
  }
#else
  result->resize(a.get_size());
  for (int i=0; i<a.get_size(); i++) {
    (*result)(i)=a(i)+b(i);
  }
#endif
}

Real mean(const Array<Real> &a) {
    Real m=0.;
    for (int i=0; i<a.get_size(); i++) {
	m+=a(i);
    }
    return (m/(Real)(a.get_size()));
}

void sum(Array2d<Real> *result, const Array2d<Real> &a, const Array2d<Real> &b) {
#ifdef DEBUG
  if (a.get_size()!=b.get_size()) ERRORQUITDUMP("Matrices not conformable");
#endif
  result->resize(a.get_size());
  for (int i=0; i<a.get_size()(0); i++) {
    for (int j=0; j<a.get_size()(1); j++) {
      (*result)(i,j)=a(i,j)+b(i,j);
    }
  }
}

void sum(Array2d<Complex> *result, const Array2d<Complex> &a, const Array2d<Complex> &b) {
#ifdef DEBUG
  if (a.get_size()!=b.get_size()) ERRORQUITDUMP("Matrices not conformable");
#endif
  result->resize(a.get_size());
  for (int i=0; i<a.get_size()(0); i++) {
    for (int j=0; j<a.get_size()(1); j++) {
      (*result)(i,j)=a(i,j)+b(i,j);
    }
  }
}

void product(Array2d<Real> *result, const Array2d<Real> &a, const Array2d<Real> &b) {
#ifdef DEBUG
  if (a.get_size()(1)!=b.get_size()(0)) ERRORQUITDUMP("Matrices not conformable");
#endif
  result->resize(iVector2d(a.get_size()(0),b.get_size()(1)));
  zero_array(result);
  for (int i=0; i<a.get_size()(0); i++) {
    for (int j=0; j<b.get_size()(1); j++) {
      for (int k=0; k<a.get_size()(1); k++) {
        (*result)(i,j)+=a(i,k)*b(k,j);
      }
    }
  }
}

void product_diag(Array2d<Real> *result, const Array<Real> &diag, const Array2d<Real> &b) {
#ifdef DEBUG
  if (diag.get_size()!=b.get_size()(0)) ERRORQUITDUMP("Matrices not conformable");
#endif
  result->resize(b.get_size());
  for (int i=0; i<b.get_size()(0); i++) {
    for (int j=0; j<b.get_size()(1); j++) {
      (*result)(i,j)=diag(i)*b(i,j);
    }
  }
}

void product_diag(Array2d<Real> *result, const Array2d<Real> &b, const Array<Real> &diag) {
#ifdef DEBUG
  if (diag.get_size()!=b.get_size()(1)) ERRORQUITDUMP("Matrices not conformable");
#endif
  result->resize(b.get_size());
  for (int i=0; i<b.get_size()(0); i++) {
    for (int j=0; j<b.get_size()(1); j++) {
      (*result)(i,j)=b(i,j)*diag(j);
    }
  }
}

void product_diag(Array<Real> *result, const Array<Real> &diag, const Array<Real> &b) {
#ifdef DEBUG
  if (diag.get_size()!=b.get_size()) ERRORQUITDUMP("Matrices not conformable");
#endif
  result->resize(b.get_size());
  for (int i=0; i<b.get_size(); i++) {
    (*result)(i)=diag(i)*b(i);
  }
}

void product(Array<Real> *result, const Array2d<Real> &a, const Array<Real> &b) {
#ifdef DEBUG
  if (a.get_size()(1)!=b.get_size()) ERRORQUITDUMP("Matrices not conformable");
#endif
  result->resize(a.get_size()(0));
  zero_array(result);
  for (int i=0; i<a.get_size()(0); i++) {
    for (int k=0; k<a.get_size()(1); k++) {
      (*result)(i)+=a(i,k)*b(k);
    }
  }
}

void product(Array<Real> *result, const Array<Real> &a, const Array2d<Real> &b) {
#ifdef DEBUG
  if (a.get_size()!=b.get_size()(0)) ERRORQUITDUMP("Matrices not conformable");
#endif
  result->resize(b.get_size()(1));
  zero_array(result);
  for (int i=0; i<b.get_size()(1); i++) {
    for (int k=0; k<a.get_size(); k++) {
      (*result)(i)+=a(k)*b(k,i);
    }
  }
}

void product(Array2d<Real> *result, const Array2d<Real> &a, Real b) {
  result->resize(a.get_size());
  for (int i=0; i<a.get_size()(0); i++) {
    for (int j=0; j<a.get_size()(1); j++) {
      (*result)(i,j)=a(i,j)*b;
    }
  }
}

void product(Array<Real> *result, const Array<Real> &a, Real b) {
  result->resize(a.get_size());
  for (int i=0; i<a.get_size(); i++) {
    (*result)(i)=a(i)*b;
  }
}

Real inner_product(const Array<Real> &a, const Array<Real> &b) {
  Real sum=0;
#ifdef DEBUG
  if (a.get_size()!=b.get_size()) ERRORQUITDUMP("Matrices not conformable");
#endif
  for (int i=0; i<a.get_size(); i++) {
    sum+=a(i)*b(i);
  }
  return sum;  
}

#ifdef ATATUSELAPACK

#include "mkl.h"

void inner_product(Array2d<Real> *result, const Array2d<Real> &a, const Array2d<Real> &b) {
#ifdef DEBUG
  if (a.get_size()(0)!=b.get_size()(0)) ERRORQUITDUMP("Matrices not conformable");
#endif
  int m=a.get_size()(1);
  int n=b.get_size()(1);
  int k=a.get_size()(0);
  result->resize(iVector2d(m,n));
  cblas_dgemm(CblasColMajor,CblasTrans,CblasNoTrans,m,n,k,1.,a.get_buf_c(),k,b.get_buf_c(),k,0.,result->get_buf(),m);
}

#else

void inner_product(Array2d<Real> *result, const Array2d<Real> &a, const Array2d<Real> &b) {
#ifdef DEBUG
  if (a.get_size()(0)!=b.get_size()(0)) ERRORQUITDUMP("Matrices not conformable");
#endif
  result->resize(iVector2d(a.get_size()(1),b.get_size()(1)));
  zero_array(result);
  int nk=a.get_size()(0);
  for (int i=0; i<a.get_size()(1); i++) {
    for (int j=0; j<b.get_size()(1); j++) {
      Real s=0.;
      for (int k=0; k<nk; k++) {
        s+=a(k,i)*b(k,j);
      }
      (*result)(i,j)=s;
    }
  }
}
#endif

void inner_product(Array<Real> *result, const Array2d<Real> &a, const Array<Real> &b) {
#ifdef DEBUG
  if (a.get_size()(0)!=b.get_size()) ERRORQUITDUMP("Matrices not conformable");
#endif
  result->resize(a.get_size()(1));
  zero_array(result);
  for (int i=0; i<a.get_size()(1); i++) {
    for (int k=0; k<a.get_size()(0); k++) {
      (*result)(i)+=a(k,i)*b(k);
    }
  }
}

Real normalize(Array<Real> *a) {
  Real l=sqrt(inner_product(*a,*a));
  product(a,*a,1./l);
  return l;
}

void outer_product(Array2d<Real> *result, const Array2d<Real> &a, const Array2d<Real> &b) {
#ifdef DEBUG
  if (a.get_size()(1)!=b.get_size()(1)) ERRORQUITDUMP("Matrices not conformable");
#endif
  result->resize(iVector2d(a.get_size()(0),b.get_size()(0)));
  zero_array(result);
  for (int i=0; i<a.get_size()(0); i++) {
    for (int j=0; j<b.get_size()(0); j++) {
      for (int k=0; k<a.get_size()(1); k++) {
        (*result)(i,j)+=a(i,k)*b(j,k);
      }
    }
  }
}

void outer_product(Array2d<Real> *result, const Array<Real> &a, const Array<Real> &b) {
  result->resize(iVector2d(a.get_size(),b.get_size()));
  for (int i=0; i<a.get_size(); i++) {
    for (int j=0; j<b.get_size(); j++) {
      (*result)(i,j)=a(i)*b(j);
    }
  }
}

void outer_product_diag(Array<Real> *result, const Array2d<Real> &a, const Array2d<Real> &b) {
#ifdef DEBUG
  if (a.get_size()(1)!=b.get_size()(1)) ERRORQUITDUMP("Matrices not conformable");
  if (a.get_size()(0)!=b.get_size()(0)) ERRORQUITDUMP("Matrix is not square");
#endif
  result->resize(a.get_size()(0));
  zero_array(result);
  for (int i=0; i<a.get_size()(0); i++) {
    for (int k=0; k<a.get_size()(1); k++) {
      (*result)(i)+=a(i,k)*b(i,k);
    }
  }
}

Real quadratic_form(const Array2d<Real> &a, const Array<Real> &x) {
#ifdef DEBUG
  if (a.get_size()(0)!=a.get_size()(1)) ERRORQUITDUMP("Matrix is not square");
  if (a.get_size()(0)!=x.get_size())    ERRORQUITDUMP("Matrices not conformable");
#endif
  Real result=0.;
  for (int i=0; i<x.get_size(); i++) {
    for (int j=0; j<x.get_size(); j++) {
      result+=a(i,j)*x(i)*x(j);
    }
  }
  return result;
}

Real quadratic_form(const Array2d<Complex> &a, const Array<Complex> &x) {
#ifdef DEBUG
  if (a.get_size()(0)!=a.get_size()(1)) ERRORQUITDUMP("Matrix is not square");
  if (a.get_size()(0)!=x.get_size())    ERRORQUITDUMP("Matrices not conformable");
#endif
  Real result=0.;
  for (int i=0; i<x.get_size(); i++) {
    for (int j=0; j<x.get_size(); j++) {
      result+=real((a(i,j)*conj(x(i))*x(j)));
    }
  }
  return result;
}

Real trace(const Array2d<Real> &a) {
#ifdef DEBUG
  if (a.get_size()(0)!=a.get_size()(1)) ERRORQUITDUMP("Cannot take trace of nonsquare matrix");
#endif
  Real tr=0;
  for (int i=0; i<a.get_size()(0); i++) {
    tr+=a(i,i);
  }
  return tr;
}

void set_identity(Array2d<Real> *result, int n) {
  result->resize(iVector2d(n,n));
  zero_array(result);
  for (int i=0; i<n; i++) {
    (*result)(i,i)=1.;
  }
}

Real max_norm(const Array<Real> &v) {
  Real m=0.;
  for (int i=0; i<v.get_size(); i++) {
    m=MAX(m,fabs(v(i)));
  }
  return m;
}

Real norm(const Array<Real> &v) {
  return sqrt(inner_product(v,v));
}

Real norm2(const Array<Real> &v) {
  return inner_product(v,v);
}

void invert_matrix_tall(Array2d<Real> *inv, const Array2d<Real> &a) {
  Array2d<Real> ata,iata;
  inner_product(&ata,a,a);
  invert_matrix(&iata,ata);
  outer_product(inv,iata,a);
}

void invert_matrix_wide(Array2d<Real> *inv, const Array2d<Real> &a) {
  Array2d<Real> aat,iaat;
  outer_product(&aat,a,a);
  invert_matrix(&iaat,aat);
  inner_product(inv,a,iaat);
}

void pow(rMatrix3d *pMr, const rMatrix3d &M, Real r) {
  Array2d<Real> m;
  convert_matrix(&m,M);
  Array<Real> lambda;
  Array2d<Real> vect;
  diagonalize_symmetric_matrix(&lambda,&vect, m);
  for (int i=0; i<3; i++) {
    lambda(i)=pow(lambda(i),r);
  }
  Array2d<Real> tmp,ivect,a;
  invert_matrix(&ivect,vect);
  product_diag(&tmp,lambda,ivect);
  product(&a,vect,tmp);
  convert_matrix(pMr,a);
}

void swap_row(Array2d<Real> *pA,int p,int q) {
  Array2d <Real> pq;
  int n=pA->get_size()(1);
  pq.resize(2,n);
  for (int i=0;i<n;i++){
    pq(0,i)=(*pA)(p,i);
    pq(1,i)=(*pA)(q,i);
  }
  for (int i=0;i<n;i++){
    (*pA)(p,i)=pq(1,i);
    (*pA)(q,i)=pq(0,i);
  }
}

void swap_column(Array2d<Real> *pA,int p,int q) {
  Array2d <Real> pq;
  int m=pA->get_size()(0);
  pq.resize(m,2);
  for (int i=0;i<m;i++){
    pq(i,0)=(*pA)(i,p);
    pq(i,1)=(*pA)(i,q);
  }
  for (int i=0;i<m;i++){
    (*pA)(i,p)=pq(i,1);
    (*pA)(i,q)=pq(i,0);
  }
}

void delete_row(Array2d<Real> *B,const Array2d<Real> &A,int p){
  int m=A.get_size()(0);
  int n=A.get_size()(1);
  (*B).resize(m-1,n);
  
  for (int i=0;i<m;i++){
    for (int j=0;j<n;j++){
      if (i<p){
        (*B)(i,j)=A(i,j);
      }
      else if (i>p){
        (*B)(i-1,j)=A(i,j);
      }
    }
  }
}

int rank_matrix(Array2d<Real> A){
  double zero=1.0e-7;
  int m=A.get_size()(0);
  int n=A.get_size()(1);
  int current=0;
  int non_empty_column=n-1;
  while(current!=m and current!=non_empty_column+1){
    if (abs(A(current,current))>zero){
      for (int i=current+1;i<m;i++){
        double ratio;
        if (abs(A(i,current))>zero){
          ratio=A(i,current)/A(current,current);
          for (int j=current;j<n;j++){
            A(i,j)-=ratio*A(current,j);
          }
        }
      }
      current++;
      //cerr << "current is " << current << endl;
    }
    else{
      int swap=0;
      for (int i=current+1;i<m;i++){
        if(abs(A(i,current))>zero){
          swap_row(&A,current,i);
          swap=1;
          //cerr << "i=" << i << endl;
          break;
        }
      }
      if (!swap) {
        swap_column(&A,current,non_empty_column);
        non_empty_column--;
        //cerr << "non_empty_column is " << non_empty_column << endl;
      }
    }
  }
  return current;
}

int detect_linear_dependence(Array<Real> *dependent_list,const Array2d<Real> &A){
  int m=A.get_size()(0);
  int count=0;
  (*dependent_list).resize(m);
  for (int i=0;i<m;i++) (*dependent_list)(i)=0;
  int rank=rank_matrix(A);
  if (rank<m){
    Array2d<Real> B;
    for (int i=0;i<m;i++){
      delete_row(&B,A,i);
      if (rank_matrix(B)==rank){   //deleted a linearly dependent line
        (*dependent_list)(i)=1;
      }
    }
  }
  return count;
}
