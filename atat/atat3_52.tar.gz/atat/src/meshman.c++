#include <fstream.h>
#include "getvalue.h"
#include "version.h"
#include "integer.h"
#include "linalg.h"
#include "lstsqr.h"
#include "meshutil.h"
#include "tensor.h"
#include "meshcalc.h"
#include "mpiinterf.h"

char *helpstring="Insert more help here";

int main(int argc, char *argv[]) {
  // parsing command line. See getvalue.hh for details;
  Array<Real> rgb;
  int poly2tri=0;
  Real scale=1.;
  Array<Real> shift;
  Array<Real> mat;
  int sigdig=5;
  char *exporter_label="vtk";
  int dohelp=0;
  int dummy=0;
  AskStruct options[]={
    {"","MESH MANipulator " MAPS_VERSION ", by Axel van de Walle",TITLEVAL,NULL},
    {"-rgb","RGB Color",ARRAYRVAL,&rgb},
    {"-p2t","Convert Polygons with more than this number of sides to Triangles",INTVAL,&poly2tri},
    {"-sc","Scale",REALVAL,&scale},
    {"-sh","Shift",ARRAYRVAL,&shift},
    {"-mat","Transformation Matrix",ARRAYRVAL,&mat},
    {"-sig","Number of significant digits printed (default: 5)",INTVAL,&sigdig},
    {"-ef","Export format (default: vtk)",STRINGVAL,&exporter_label},
    {"-h","Display more help",BOOLVAL,&dohelp},
    {"-d","Use all default values",BOOLVAL,&dummy}
  };
  if (!get_values(argc,argv,countof(options),options)) {
    display_help(countof(options),options);
    return 1;
  }
  if (dohelp) {
    cout << helpstring;
    return 1;
  }

  if (!check_plug_in(MeshExporter(),exporter_label)) {
    // cerr << exporter_label << endl;
    ERRORQUIT("Unknown export format");
  }
  MeshExporter *pexporter=GenericPlugIn<MeshExporter>::create(exporter_label);

  Array<Array<Real> > pts;
  LinkedList<Array<int> > polys;
  Array<Array<Real> > colors;

  cin >> pts;
  cin >> polys;
  cin >> colors;

  if (poly2tri) {
    LinkedListIterator<Array<int> > it(polys);
    while (it) {
      if (it->get_size()>=poly2tri) {
	Array<int> save=*it;
	delete polys.detach(it);
	for (int f=0; f<save.get_size()-2; f++) {
	  Array<int> *pnewtri=new Array<int>(3);
	  (*pnewtri)(0)=save(0);
	  (*pnewtri)(1)=save(1+f);
	  (*pnewtri)(2)=save(2+f);
	  polys.add(pnewtri,it);
	  it++;
	}
      }
      else {it++;}
      /*
      if (it->get_size()==4) {
	Array<int> save=*it;
	it->resize(3);
	for (int i=0; i<3; i++) {(*it)(i)=save((i+2)%4);}
	Array<int> *pnewtri=new Array<int>(3);
	for (int i=0; i<3; i++) {(*pnewtri)(i)=save(i);}
	polys.add(pnewtri,it);
	it++;
      }
      */
    }
  }

  if (scale!=1.) {
    for (int i=0; i<pts.get_size(); i++) {
      for (int j=0; j<pts(i).get_size(); j++) {
	pts(i)(j)*=scale;
      }
    }
  }
  if (mat.get_size()>0) {
    int dim=(int)sqrt((Real)mat.get_size());
    for (int i=0; i<pts.get_size(); i++) {
      Array<Real> tpts(dim);
      zero_array(&tpts);
      for (int j=0; j<dim; j++) {
	for (int k=0; k<dim; k++) {
	  tpts(j)+=mat(dim*j+k)*pts(i)(k);
	}
      }
      pts(i)=tpts;
    }
  }
  
  if (shift.get_size()>0) {
    for (int i=0; i<pts.get_size(); i++) {
      for (int j=0; j<pts(i).get_size(); j++) {
	pts(i)(j)+=shift(j);
      }
    }
  }
  
  if (rgb.get_size()>0) {
    colors.resize(1);
    colors(0)=rgb;
  }

  cout.setf(ios::fixed);
  cout.precision(sigdig);
  pexporter->write(cout,pts,polys,colors);
}
