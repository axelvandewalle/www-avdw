#ifndef _ARRAYLIST_H_
#define _ARRAYLIST_H_

#include "array.h"
#include "linklist.h"

template<class T,class S>
inline LinkedList<T>& operator <<(LinkedList<T>& list, const Array<S> &a) {
  for (int i=0; i<a.get_size(); i++) {
    list << new T(a(i));
  }
  return list;
}

template<class T,class S>
void LinkedList_to_Array(Array<T> *a, const LinkedList<S> &l) {
  if (a) {
    int size=l.get_size();
    a->resize(size);
    LinkedListIterator<S> it(l);
    for (int i=0; i<size; i++) {
      (*a)(i)=(T)(*it);
      it++;
    }
  }
}

template<class T,class S>
void LinkedList_to_Array1(Array<T> *a, const LinkedList<S> &l) {
  if (a) {
    int size=l.get_size();
    a->resize(size+1);
    LinkedListIterator<S> it(l);
    for (int i=1; i<=size; i++) {
      (*a)(i)=(T)(*it);
      it++;
    }
  }
}

template<class T,class S>
void ArrayArray_to_Array2d(Array2d<T> *pmat, const Array<Array<S> > &a) {
  if (a.get_size()==0) {
    pmat->resize(0,0);
  }
  else {
    int h=a(0).get_size();
    pmat->resize(a.get_size(),h);
    for (int i=0; i<a.get_size(); i++) {
      for (int j=0; j<h; j++) {
        (*pmat)(i,j)=(T)(a(i)(j));
      }
    }
  }
}

template<class T,class S>
void LinkedListArray_to_Array2d(Array2d<T> *a, const LinkedList<Array<S> > &l) {
  if (a) {
    LinkedListIterator<S> it(l);
    iVector2d size(l.get_size(),it->get_size());
    a->resize(size);
    for (int i=0; i<size(0); i++) {
      for (int j=0; j<size(1); j++) {
	(*a)(i,j)=(T)((*it)(j));
      }
      it++;
    }
  }
}

template<class T, int D>
void Array_to_FixedVector(FixedVector<T,D> *pv, const Array<T> &a) {
  for (int i=0; i<D; i++) {
    (*pv)(i)=a(i);
  }
}

template<class T, int D>
void FixedVector_to_Array(Array<T> *pa, const FixedVector<T,D> &v) {
  pa->resize(D);
  for (int i=0; i<D; i++) {
    (*pa)(i)=v(i);
  }
}

/*
template<class T, int D>
void ArrayArray_to_ArrayFixedVector(Array<FixedVector<T,D> > *paf, const Array<Array<T> > &aa) {
  paf->resize(aa.get_size());
  for (int i=0; i<aa.get_size(); i++) {
    Array_to_FixedVector(&((*paf)(i)),aa(i));
  }
}

template<class T, int D>
void LinkedListFixedVector_to_LinkedListArray(LinkedList<Array<T> > *pla, const LinkedList<FixedVector<T,D> > &lf) {
  LinkedListIterator<FixedVector<T,D> > it(lf);
  for (;it; it++) {
    Array<T> *pa=new Array<T>();
    FixedVector_to_Array(pa,*it);
    (*pla) << pa;
  }
}

template<class T>
void LinkedListFixedVector_to_LinkedListArray(LinkedList<Array<T> > *pla, const LinkedList<Vector3d<T> > &lf) {
  LinkedListIterator<Vector3d<T> > it(lf);
  for (;it; it++) {
    Array<T> *pa=new Array<T>();
    FixedVector_to_Array(pa,*it);
    (*pla) << pa;
  }
}
*/

template<class T>
class TrivEqual {
 public:
  int operator () (const T& a, const T& b) const {
    return (a==b);
  }
};

template<class T, class C>
inline int add_unique(LinkedList<T> *l, T *pobject, const C &isequal) {
  LinkedListIterator<T> i(*l);
  for ( ; i; i++) {
    if (isequal(*i,*pobject)) break;
  }
  if (!i) {
    (*l) << pobject;
    return 1;
  }
  else {
    return 0;
  }
}

template<class T, class C>
inline int add_unique(LinkedList<T> *l, const T &object, const C &isequal) {
  T *pobject=new T(object);
  if (add_unique(l,pobject,isequal)) {
    return 1;
  }
  else {
    delete pobject;
    return 0;
  }
}

template<class T, class C>
inline void add_sorted(LinkedList<T> *l, T *pobject, const C &less_equal) {
  LinkedListIterator<T> i(*l);
  for ( ; i; i++) {
    if (!less_equal(*i,pobject)) break;
  }
  l->add(pobject,i);
}

template<class T, class C>
inline void add_sorted(LinkedList<T> *l, const T &object, const C &comparator) {
  add_unique_sorted(l,new T(object),comparator);
}

template<class T>
class TrivLessThan {
 public:
  int operator () (const T& a, const T& b) const {
    return (a<b);
  }
};

template<class T>
T *is_in_list(const LinkedList<T> &list, const T &val) {
  LinkedListIterator<T> i(list);
  for (; i; i++) {
    if (*i==val) break;
  }
  return i;
}

template<class T, class C>
inline void sort_array(Array<T> *pa, const C &comparator) {
  //cerr << "bs-" << pa->get_size() << "-" << flush;
  for (int i=1; i<pa->get_size(); i++) {
    for (int j=0; j<pa->get_size()-i; j++) {
      if (comparator((*pa)(j+1),(*pa)(j))) {
	swap(&((*pa)(j+1)),&((*pa)(j)));
      }
    }
  }
  //cerr << "es\n";
}

template<class T>
class MultiDimIterator {
  T current;
  T max;
  T min;
  int valid;
 public:
  MultiDimIterator(): current(), min(), max() {valid=0;}
  ~MultiDimIterator() {}
  MultiDimIterator(const T &_min, const T &_max): current(), min(), max() {
    init(_min,_max);
  }
  MultiDimIterator(const T &_max): current(), min(), max() {
    init(_max);
  }
  void init(const T &_min, const T &_max) {
    min=_min;
    max=_max;
    valid=1;
    current=_min;
  }
  void init(const T &_max) {
    min=_max;
    max=_max;
    for (int i=0; i<min.get_size(); i++) {
      min(i)=0;
      max(i)=max(i)-1;
    }
    valid=1;
    current=min;
  }
  operator const T& (void) {return current;}
  //  operator void * () {return (void *)valid;}
  operator void * () {return ((int *)NULL+valid);}
  const T& operator++(int);
  void bump_up(int level);  
};

template<class T>
inline const T& MultiDimIterator<T>::operator++(int) {
  int i=0;
  while (i<max.get_size()) {
    if (current(i)<max(i)) break;
    current(i)=min(i);
    i++;
  }
  if (i==max.get_size()) {
    valid=0;
  }
  else {
    current(i)++;
  }
  return current;
}

template<class T>
inline void MultiDimIterator<T>::bump_up(int level) {
  current(level)=min(level);
  int i=level+1;
  while (i<max.get_size() && current(i)>=max(i)) {
    current(i)=min(i);
    i++;
  }
  if (i==max.get_size()) {
    valid=0;
  }
  else {
    current(i)++;
  }
}

class MultipletIterator {
 public:
  enum Style {all,nopermute,norepeat};
 private:
  Array<int> current;
  int min;
  int max;
  int valid;
  Style style;
 public:
  MultipletIterator(): current() {}
  MultipletIterator(int dim, int _min, int _max, Style _style=all): current() {
    init(dim,_min,_max,_style);
  }
  void init(int dim, int _min, int _max, Style _style=all) {
    min=_min;
    max=_max;
    valid=1;
    style=_style;
    current.resize(dim);
    for (int i=0; i<current.get_size(); i++) {
      switch (style) {
        case norepeat:
          current(i)=min+i;
          break;
        default:
          current(i)=min;
          break;
      }
    }
  }
  operator const Array<int>& (void) {return current;}
  operator int () {return valid;}
  const Array<int>& operator++(int);
};

inline const Array<int>&  MultipletIterator::operator++(int) {
  int i;
  switch (style) {
    case MultipletIterator::all:
      i=0;
      while (current(i)>=max && i<current.get_size()) {
        current(i)=min;
        i++;
      }
      if (i==current.get_size()) {valid=0;}
      current(i)++;
      break;
    case MultipletIterator::nopermute:
      i=0;
      while (current(i)==max && i<current.get_size()) i++;
      if (i==current.get_size()) {valid=0; return current;}
      current(i)++;
      { for (int j=i-1; j>=0; j--) {current(j)=current(i);} }
      break;
    case MultipletIterator::norepeat:
      current(i)=min;
      i=0;
      while (current(i)==max && i<current.get_size()-1) i++;
      current(i)++;
      for (int j=i-1; j>=0; j--) {
        current(j)=current(i)+(i-j);
        if (current(j)>max) {valid=0; return current;}
      }
      break;
  }
  return current;
}

class NTupleIterator {
  Array<int> current;
  int nb;
  int outof;
  int valid;
public:
  NTupleIterator(int _nb, int _outof): current(0) {
    init(_nb,_outof);
  }
  void init(int _nb, int _outof) {
    nb=_nb;
    outof=_outof;
    valid=1;
    current.resize(nb);
    for (int i=0; i<nb; i++) {
      current(i)=nb-1-i;
    }
  }
  operator void * () {return ((int *)NULL+valid);}
  operator const Array<int>& (void) {return current;}
  const Array<int> &operator++(int) {
    int i;
    for (i=0; i<current.get_size(); i++) {
      if (current(i)<outof-1-i) {
	current(i)++;
	break;
      }
    }
    if (i==current.get_size()) {
      valid=0;
    }
    else {
      i--;
      for ( ; i>=0; i--) {
	current(i)=current(i+1)+1;
      }
    }
    return current;
  }
};

template<class T>
class BoundingHypercube {
private:
  int ready;
public:
  T min,max;
public:
  BoundingHypercube(void): min(), max() {ready=0;}
  void update(const T &v) {
    if (!ready) {
      min=v;
      max=v;
      ready=1;
    }
    else {
      for (int i=0; i<v.get_size(); i++) {
	if (v(i)<min(i)) min(i)=v(i);
	if (v(i)>max(i)) max(i)=v(i);
      }
    }
  }
};

template<class T>
void extract_columns(Array2d<T> *pa, const Array2d<T> &b, const LinkedList<int> &cols_list, int nb_cols) {
  Array<int> cols;
  LinkedList_to_Array(&cols,cols_list);
  extract_columns(pa,b,cols,nb_cols);
}

#endif
