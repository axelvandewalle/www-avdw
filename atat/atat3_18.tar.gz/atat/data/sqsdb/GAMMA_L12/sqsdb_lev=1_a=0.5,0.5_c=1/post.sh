#!/bin/bash
cp bestsqs.out rndstr.in post
cd post
corrdump -l=rndstr.in -ro -noe -nop -2=13 -3=7 -4=7 -s=bestsqs.out
corrdump -l=rndstr.in -ro -noe -nop -2=13 -3=7 -4=7 -s=bestsqs.out -rnd
cd ..
