#ifndef __MYGLUT_H__
#define __MYGLUT_H__

#define PASTETWO(A,B) A##B

#define MEMBER_CALLBACK(RETTYPE,MEMBER,ARGTYPE,ARGNAME)			\
  static RETTYPE PASTETWO(static_,MEMBER) ARGTYPE {			\
    return pcurrent_instance-> MEMBER ARGNAME;				\
  }									\
  RETTYPE MEMBER ARGTYPE

#define VOID_MEMBER_CALLBACK(MEMBER,ARGTYPE,ARGNAME)			\
  static void PASTETWO(static_,MEMBER) ARGTYPE {			\
    pcurrent_instance-> MEMBER ARGNAME;					\
  }									\
  void MEMBER ARGTYPE

#endif
