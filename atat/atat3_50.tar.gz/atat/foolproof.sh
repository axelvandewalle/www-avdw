#!/bin/sh
if [ ! -e /bin/csh ]; then
    echo /bin/csh cannot be found.
    if [ ! -e /bin/tcsh ]; then
	echo Please install csh or tcsh .
    else
	echo Create a symbolic link from /bin/csh to /bin/tcsh .
	echo Alternatively, you can run ./patchcsh
    fi
    exit 1
fi
./foolproof $*
