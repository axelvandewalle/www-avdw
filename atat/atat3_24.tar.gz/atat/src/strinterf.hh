#ifndef __STRINTERF_H__
#define __STRINTERF_H__

#include <fstream.h>
#include "stringo.h"
#include "xtalutil.h"
#include "opti.h"

int num_strain_dim(int n);

void Array6_to_Matrix3d(rMatrix3d *pm, const Array<Real> &x, int dimstrain);

void Matrix3d_to_Array6(Array<Real> *px, const rMatrix3d &m, int dimstrain);

class OptimizedStructure: public FunctionWithGrad {
  Real val;
  Array<Real> grad;
  rVector3d sumpos;
  Real stressscale;
  Real strainscale;
  int dimstrain;
public:
  rMatrix3d axes;
  Structure str;
  Array<AutoString> atom_label;
  int sleeptime;
public:
  OptimizedStructure(void);
  ~OptimizedStructure(void);
  void init(Array<Real> *px, const rMatrix3d &_axes, const Structure &_str, const Array<AutoString> &_atom_label, Real forcefact=1., int _dimstrain=3);
  void vect_to_str(Structure *pstr, const Array<Real> &x);
  void set_arg(const Array<Real> &x);
  Real get_val(void) const {return val;}
  void get_grad(Array<Real> *pgrad) const {*pgrad=grad;}  
};


#endif
