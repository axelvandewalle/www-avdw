#!/usr/bin/perl
print system("grep FCC_A1 sgte_phases.tdb"),"\n";
print system("grep nothing sgte_phases.tdb"),"\n";
